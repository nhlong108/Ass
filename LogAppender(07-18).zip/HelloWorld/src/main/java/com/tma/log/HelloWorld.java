package com.tma.log;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;
import org.fluentd.logger.FluentLogger;

public class HelloWorld extends AppenderSkeleton {
	private static Logger m_log = Logger.getLogger(HelloWorld.class.getName());
	private FluentLogger m_fluentLogger;
	protected String m_tag = "log4j-appender";
	protected String m_host = "localhost";
	protected String m_label = "label";
	protected int m_port = 9200;

	public void activateOptions() {
		try {
			m_fluentLogger = FluentLogger.getLogger(m_tag, m_host, m_port);
		} catch (Exception e) {
			m_log.error("Catched exception: ", e);
		}
		super.activateOptions();
	}
	
	@Override
	public void close() {
		try {
			m_fluentLogger.flush();
		} catch (IOException e) {
			m_log.error("Something went wrong ", e);
		}
	}
	
	@Override
	public boolean requiresLayout() {
		return false;
	}
	
	@Override
	protected void append(LoggingEvent event) {
		Map<String, Object> messages = new HashMap<String, Object>();
		messages.put("level", event.getLevel());
		messages.put("loogerName", event.getLoggerName());
		messages.put("thread", event.getLoggerName());
		messages.put("message", event.getMessage());
		m_fluentLogger.log(m_label, messages, event.getTimeStamp());
	}
	
	public void sendContext(String parameter) {
		if (m_log.isDebugEnabled()) {
			m_log.debug("This is debug: " + parameter);
		}
		if (m_log.isInfoEnabled()) {
			m_log.info("This is info: " + parameter);
		}
		
		m_log.warn("This is warn: " + parameter);
		m_log.error("This is error: " + parameter);
		m_log.fatal("This is fatal: " + parameter);
		
	}
	
	public static void main(String[] args) {
		BasicConfigurator.configure();
		HelloWorld obj = new HelloWorld();
		obj.sendContext("nhlong@tma.com.vn");
	}
}

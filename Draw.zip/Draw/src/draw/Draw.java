package draw;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javafx.application.Application;
import javafx.beans.binding.ObjectBinding;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Line;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

public class Draw extends Application {

    private Path path;
    private Group lineGroup;
    private static final Double DEFAULTSTROKE = 3.0;
    private static final Double MAXSTROKE = 30.0;
    private static final Double MINSTROKE = 1.0;
    private static final Integer DEFAULTRED = 0;
    private static final Integer DEFAULTGREEN = 0;
    private static final Integer DEFAULTBLUE = 255;
    private static final Integer MAXRGB = 255;
    private static final Integer MINRGB = 0;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Simple Painter");
        final Group root = new Group();

        Scene scene = new Scene(root, 700, 600);
        scene.setFill(Color.ALICEBLUE);

        // A group to hold all the drawn path elements
        lineGroup = new Group();


        // Build the slider, label, and button and their VBox layout container 
        Button btnClear = new Button();
        btnClear.setText("Clear");           
        Button btnOpen = new Button();
        btnOpen.setText("Open");       
        Button btnErase = new Button();
        btnErase.setText("Erase");           
        
        
        HBox btnBox = new HBox(10);
        btnBox.setAlignment(Pos.TOP_LEFT);
        btnBox.getChildren().addAll(btnOpen,btnErase,btnClear);
        
        Button btnLine = new Button();
        btnLine.setText("     Line    ");                    
        Button btnRectangle = new Button();
        btnRectangle.setText("Rectangle");
        VBox btnShape = new VBox(10);
        btnShape.setAlignment(Pos.TOP_RIGHT);
        btnShape.getChildren().addAll(btnLine,btnRectangle);
        
        Slider strokeSlider = new Slider(MINSTROKE, MAXSTROKE, DEFAULTSTROKE);
        Label labelStroke = new Label("Line Size");
        VBox utilBox = new VBox(10);
        utilBox.setAlignment(Pos.TOP_RIGHT);
        utilBox.getChildren().addAll(labelStroke, strokeSlider);

        // Build the RGB sliders, labels, and HBox containers
        final Slider redSlider = new Slider(MINRGB, MAXRGB, DEFAULTRED);
        Label labelRed = new Label("R");
        HBox rhbox = new HBox(5);
        rhbox.getChildren().addAll(labelRed, redSlider);
        final Slider greenSlider = new Slider(MINRGB, MAXRGB, DEFAULTGREEN);
        Label labelGreen = new Label("G");
        HBox ghbox = new HBox(5);
        ghbox.getChildren().addAll(labelGreen, greenSlider);
        final Slider blueSlider = new Slider(MINRGB, MAXRGB, DEFAULTBLUE);
        Label labelBlue = new Label("B");
        HBox bhbox = new HBox(5);
        bhbox.getChildren().addAll(labelBlue, blueSlider);

        // Build the VBox container for all the slider containers        
        VBox colorBox = new VBox(10);
        colorBox.setAlignment(Pos.TOP_CENTER);
        colorBox.getChildren().addAll(rhbox, ghbox, bhbox);

        // Put all controls in one HBox
        HBox toolBox = new HBox(10);
        toolBox.setAlignment(Pos.TOP_CENTER);
        toolBox.getChildren().addAll(btnBox, utilBox, colorBox, btnShape);

        // Build a Binding object to compute a Paint object from the sliders
        ObjectBinding<Paint> colorBinding = new ObjectBinding<Paint>() {

            {
                super.bind(redSlider.valueProperty(), greenSlider.valueProperty(),
                        blueSlider.valueProperty());
            }

            @Override
            protected Paint computeValue() {
                return Color.rgb(redSlider.valueProperty().intValue(),
                        greenSlider.valueProperty().intValue(),
                        blueSlider.valueProperty().intValue());
            }
        };

        // Build the sample line and its layout container
        final Line sampleLine = new Line(0, 0, 140, 0);
        sampleLine.strokeWidthProperty().bind(strokeSlider.valueProperty());
        StackPane stackpane = new StackPane();
        stackpane.setPrefHeight(MAXSTROKE);
        stackpane.getChildren().add(sampleLine);
        // Bind to the Paint Binding object
        sampleLine.strokeProperty().bind(colorBinding);
    

        // Build the canvas
        final Rectangle canvas = new Rectangle(scene.getWidth() - 20, scene.getHeight() - 200);        
        canvas.setCursor(Cursor.CROSSHAIR);
        canvas.setFill(Color.LIGHTGOLDENRODYELLOW);     
        
        canvas.setOnMousePressed(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent me) {

                path = new Path();
                path.setMouseTransparent(true);
                path.setStrokeWidth(sampleLine.getStrokeWidth());                
                path.setStroke(sampleLine.getStroke());                
                lineGroup.getChildren().add(path);
                path.getElements().add(new MoveTo(me.getSceneX(), me.getSceneY()));
            }
        });

        canvas.setOnMouseReleased(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent me) {
                path = null;

            }
        });

        canvas.setOnMouseDragged(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent me) {

                // keep lines within rectangle

                if (canvas.getBoundsInLocal().contains(me.getX(), me.getY())) {
                    path.getElements().add(new LineTo(me.getSceneX(), me.getSceneY()));
                }

            }
        });
        
        //set Action for Line Button
        btnLine.setOnAction(new EventHandler<ActionEvent>() {                       

            @Override
            public void handle(ActionEvent event) {            
            canvas.setCursor(Cursor.CROSSHAIR);
            
            canvas.setOnMousePressed(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent me) {

                path = new Path();
                path.setMouseTransparent(true);
                path.setStrokeWidth(sampleLine.getStrokeWidth());                
                path.setStroke(sampleLine.getStroke());
                lineGroup.getChildren().add(path);
                path.getElements().add(new MoveTo(me.getSceneX(), me.getSceneY()));
            }
        });

        canvas.setOnMouseReleased(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent me) {
                path = null;

            }
        });

        canvas.setOnMouseDragged(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent me) {

                // keep lines within rectangle

                if (canvas.getBoundsInLocal().contains(me.getX(), me.getY())) {
                    path.getElements().add(new LineTo(me.getSceneX(), me.getSceneY()));
                }

            }
        });                                
            }
        });                        

        //set Action for Erase Button
        btnErase.setOnAction(new EventHandler<ActionEvent>() {                       

            @Override
            public void handle(ActionEvent event) {            
            canvas.setCursor(Cursor.OPEN_HAND);
            
            canvas.setOnMousePressed(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent me) {

                path = new Path();
                path.setMouseTransparent(true);
                path.setStrokeWidth(sampleLine.getStrokeWidth());                
                path.setStroke(Color.LIGHTGOLDENRODYELLOW);
                lineGroup.getChildren().add(path);
                path.getElements().add(new MoveTo(me.getSceneX(), me.getSceneY()));
            }
        });

        canvas.setOnMouseReleased(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent me) {
                path = null;

            }
        });

        canvas.setOnMouseDragged(new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent me) {

                // keep lines within rectangle

                if (canvas.getBoundsInLocal().contains(me.getX(), me.getY())) {
                    path.getElements().add(new LineTo(me.getSceneX(), me.getSceneY()));
                }

            }
        });                                
            }
        });  
        
        //set Action for Rectangle Button
        btnRectangle.setOnAction(new EventHandler<ActionEvent>(){                 
            double starting_point_x, starting_point_y ;           
            Rectangle new_rectangle = null ;
            boolean new_rectangle_is_being_drawn = false ;
            Color[] rectangle_colors = { Color.TEAL,   Color.TOMATO,  Color.TURQUOISE,
                                Color.VIOLET, Color.YELLOWGREEN, Color.GOLD } ;
            int color_index = 0 ;
            
            void adjust_rectangle_properties( double starting_point_x,
                                     double starting_point_y,
                                     double ending_point_x,
                                     double ending_point_y,
                                     Rectangle given_rectangle )
            {
                given_rectangle.setX( starting_point_x ) ;
                given_rectangle.setY( starting_point_y ) ;
                given_rectangle.setWidth( ending_point_x - starting_point_x ) ;
                given_rectangle.setHeight( ending_point_y - starting_point_y ) ;

                if ( given_rectangle.getWidth() < 0 )
                {
                   given_rectangle.setWidth( - given_rectangle.getWidth() ) ;
                   given_rectangle.setX( given_rectangle.getX() - given_rectangle.getWidth() ) ;
                }

                if ( given_rectangle.getHeight() < 0 )
                {
                   given_rectangle.setHeight( - given_rectangle.getHeight() ) ;
                   given_rectangle.setY( given_rectangle.getY() - given_rectangle.getHeight() ) ;
                }
            }
            
            @Override            
            public void handle(ActionEvent event) { 
                canvas.setCursor(Cursor.CROSSHAIR);
                canvas.setOnMousePressed(new EventHandler<MouseEvent>(){
                    @Override
                    public void handle(MouseEvent event) {                    
                        if ( new_rectangle_is_being_drawn == false )                        
                        {
                           starting_point_x = event.getSceneX() ;
                           starting_point_y = event.getSceneY() ;

                           new_rectangle = new Rectangle() ;

                           // A non-finished rectangle has always the same color.
                           new_rectangle.setFill( Color.SNOW) ; // almost white color
                           new_rectangle.setStroke( Color.BLACK ) ;
                           
                           

                           //group_for_rectangles.getChildren().add( new_rectangle ) ;

                           lineGroup.getChildren().add(new_rectangle);
                           new_rectangle_is_being_drawn = true ;
                        }                                          
                    }                
                });

                canvas.setOnMouseDragged(new EventHandler<MouseEvent>(){

                    @Override
                    public void handle(MouseEvent event) {

                        if ( new_rectangle_is_being_drawn == true )
                        {
                           double current_ending_point_x = event.getSceneX() ;
                           double current_ending_point_y = event.getSceneY() ;

                           adjust_rectangle_properties( starting_point_x,
                                                        starting_point_y,
                                                        current_ending_point_x,
                                                        current_ending_point_y,
                                                        new_rectangle ) ;
                        }                    
                    }                
                });

                canvas.setOnMouseReleased(new EventHandler<MouseEvent>(){
                    @Override
                    public void handle(MouseEvent event) {
                        if ( new_rectangle_is_being_drawn == true )
                        {
                           // Now the drawing of the new rectangle is finished.
                           // Let's set the final color for the rectangle.

                           new_rectangle.setFill( rectangle_colors[ color_index ] ) ;                                                        

                           color_index ++ ;  // Index for the next color to use.

                           // If all colors have been used we'll start re-using colors from the
                           // beginning of the array.

                           if ( color_index >= rectangle_colors.length )
                           {
                              color_index = 0 ;
                           }

                           new_rectangle = null ;
                           new_rectangle_is_being_drawn = false ;
                        }                   
                    }

                });                
            }
        });
        
        //set Action for Open Button
        btnOpen.setOnAction(new EventHandler<ActionEvent>() {

            public void handle(ActionEvent event) {
                FileChooser fileChooser = new FileChooser();

                //Set extension filter
                FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("JPG files (*.jpg)", "*.JPG");
                FileChooser.ExtensionFilter extFilterPNG = new FileChooser.ExtensionFilter("PNG files (*.png)", "*.PNG");
                fileChooser.getExtensionFilters().addAll(extFilterJPG, extFilterPNG);

                //Show open file dialog
                File file = fileChooser.showOpenDialog(null);

                try { 
                    ImageView myImage = new ImageView();
                    BufferedImage bufferedImage = ImageIO.read(file);
                    WritableImage image = SwingFXUtils.toFXImage(bufferedImage, null);
                    myImage.setImage(image);
                    ImagePattern imp=new ImagePattern(image);
                    canvas.setFill(imp);
                } catch (IOException ex) {                
                }
                }            
        });
        
        //set Action for Clear Button
        btnClear.setOnAction(new EventHandler<ActionEvent>() {

            public void handle(ActionEvent event) {
                lineGroup.getChildren().removeAll(lineGroup.getChildren()); 
                canvas.setFill(Color.LIGHTGOLDENRODYELLOW);  
            }
        });
        
        // Build the VBox container for the toolBox, sampleline, and canvas
        VBox vb = new VBox(20);
        vb.setPrefWidth(scene.getWidth() - 20);
        vb.setLayoutY(20);
        vb.setLayoutX(10);
        vb.getChildren().addAll(toolBox, stackpane, canvas);
        root.getChildren().addAll(vb, lineGroup);
        primaryStage.setScene(scene);
        primaryStage.show();        
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GaraMrTam
{
    public partial class frmMain : Form
    {

        #region Constructor, form Load

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            pnlContent.Hide();
            pnlHome.Show();
            pnlHome.Dock = DockStyle.Fill;
            pnlHome.BringToFront();
        }

        #endregion

        #region Đăng nhập

        private void btnLogin_Click(object sender, EventArgs e)
        {
            login();
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                login();
        }

        private void login()
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            DataTable tb = new DataTable();
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            tb = QT.IDNguoiDung(username, password);
            if (tb.Rows.Count != 0)
            {
                pnlHome.Hide();
                pnlContent.Show();
                pnlContent.Dock = DockStyle.Fill;
                pnlContent.BringToFront();
                showQuanLy();
                pnlTiepNhan.Show();
                pnlTiepNhan.Dock = DockStyle.Fill;
                pnlTiepNhan.BringToFront();
                SETcbo_ListHieuXe();
            }
            else
                MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng");
        }

        #endregion

        #region Quản lý

        private void showQuanLy()
        {
            pnlQuanTri.Hide();
            //pnlThongKe.Hide();
            pnlQuanLy.Show();
            pnlQuanLy.Dock = DockStyle.Fill;
            pnlQuanLy.BringToFront();
        }

        /// <summary> Panel phiếu sửa
        /// 
        /// </summary>
        private void cboPhieuSua_NoiDung_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            if (!cb.Focused)
            {
                return;
            }
            DataControl.Data data = new DataControl.Data();
            DataTable tb = new DataTable();
            tb = data.TienCong(cboPhieuSua_NoiDung.SelectedValue.ToString());
            txtTienCong.Text = tb.Rows[0][0].ToString();
        }

        private void cboPhieuSua_PhuTung_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            if (!cb.Focused)
            {
                return;
            }
            DataControl.Data data = new DataControl.Data();
            DataTable tb = new DataTable();
            tb = data.GiaPhuTung(cboPhieuSua_PhuTung.SelectedValue.ToString());
            txtDonGia.Text = tb.Rows[0][0].ToString();
        }

        private void cboPhieuSua_BienSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            if (!cb.Focused)
            {
                return;
            }
            DataTable tb = new DataTable();
            DataControl.Data data = new DataControl.Data();
            int n = Convert.ToInt32(cboPhieuSua_BienSo.SelectedValue.ToString());
            tb = data.NgayNhan(n);
            DataRow row = tb.Rows[0];
            string d = row[0].ToString();
            DateTime day = Convert.ToDateTime(d);
            txtPhieuSua_NgayNhan.Text = day.ToString("dd-MM-yyyy");
        }

        private void txtSoLuong_TextChanged(object sender, EventArgs e)
        {
            SETTB_ThanhTien();
        }

        private void txtTienCong_TextChanged(object sender, EventArgs e)
        {
            SETTB_ThanhTien();
        }

        private void SETcbo_ListTienCong()
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            QT.ListTienCong();
            cboPhieuSua_NoiDung.DataSource = QT._TB;
            cboPhieuSua_NoiDung.DisplayMember = "TenCong";
            cboPhieuSua_NoiDung.ValueMember = "MaCong";
        }

        private void SETcbo_ListPhuTung()
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            QT.ListPhuTung();
            cboPhieuSua_PhuTung.DataSource = QT._TB;
            cboPhieuSua_PhuTung.DisplayMember = "TenPhuTung";
            cboPhieuSua_PhuTung.ValueMember = "MaPhuTung";
        }

        private void SETcbo_ListBienSo()
        {
            DataControl.Data data = new DataControl.Data();
            data.IDPhieuNhan();
            cboPhieuSua_BienSo.DataSource = data.TABLE;
            cboPhieuSua_BienSo.DisplayMember = "BienSo";
            cboPhieuSua_BienSo.ValueMember = "MaPhieuNhan";
        }

        private void SETTB_ThanhTien()
        {
            float DonGia = float.Parse(txtDonGia.Text);
            float TienCong = float.Parse(txtTienCong.Text);
            float ThanhTien;
            try
            {
                int SL = Convert.ToInt32(txtSoLuong.Text);
                ThanhTien = SL * DonGia + TienCong;
            }
            catch
            {
                ThanhTien = TienCong;
            }
            txtThanhTien.Text = ThanhTien.ToString();
        }

        private void SETdgvChiTietPhieuSua()
        {
            DataControl.Data data = new DataControl.Data();
            dgvChiTietPhieuSua.DataSource = data.dgvPhieuTam();
            dgvChiTietPhieuSua.Columns[0].HeaderText = "Nội dung";
            dgvChiTietPhieuSua.Columns[1].HeaderText = "Phụ tùng";
            dgvChiTietPhieuSua.Columns[2].HeaderText = "Số lượng";
            dgvChiTietPhieuSua.Columns[3].HeaderText = "Đơn giá";
            dgvChiTietPhieuSua.Columns[4].HeaderText = "Tiền công";
            dgvChiTietPhieuSua.Columns[5].HeaderText = "Tiền phụ tùng";
            dgvChiTietPhieuSua.Columns[6].HeaderText = "Thành tiền";
            for (int i = 2; i < 6; i++ )
            {
                dgvChiTietPhieuSua.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }    
        }

        private void dgvChiTietPhieuSua_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        //
        // Các button phiếu sửa và method liên quan
        //
        private void btnAdd_Click(object sender, EventArgs e) //Button thêm công - phụ tùng
        {
            DataControl.Data data = new DataControl.Data();
            string MaCong = cboPhieuSua_NoiDung.SelectedValue.ToString();
            string TenCong = cboPhieuSua_NoiDung.Text;
            string MaPhuTung = cboPhieuSua_PhuTung.SelectedValue.ToString();
            string TenPhuTung = cboPhieuSua_PhuTung.Text;
            int SoLuong;
            try
            {
                SoLuong = Convert.ToInt32(txtSoLuong.Text);
            }
            catch
            {
                SoLuong = 0;
            }
            float DonGia = float.Parse(txtDonGia.Text);
            float TienCong = float.Parse(txtTienCong.Text);
            float TienPhuTung = SoLuong * DonGia;
            float ThanhTien = float.Parse(txtThanhTien.Text);
            if (KiemTraPhieuTam(MaCong) == false)
            {
                int n = data.insertPhieuTam(MaCong, TenCong, MaPhuTung, TenPhuTung, SoLuong, DonGia, TienCong, TienPhuTung, ThanhTien);
                if (n == 0)
                    MessageBox.Show("Đã có lỗi xảy ra!\nVui lòng kiểm tra lại");
            }
            else
            {
                DialogResult OK;
                OK = MessageBox.Show("Nội dung đã có!\nChọn 'Yes' để sửa! Chọn 'No' để xóa!", "Thông báo", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (OK == DialogResult.Yes)
                {
                    int n = data.updatePhieuTam(MaCong, MaPhuTung, TenPhuTung, SoLuong, DonGia, TienPhuTung, ThanhTien);
                    if (n == 0)
                        MessageBox.Show("(1) Đã có lỗi xảy ra!\nVui lòng kiểm tra lại");
                }
                if (OK == DialogResult.No)
                {
                    int m = data.deletePhieuTam(MaCong);
                    if (m == 0)
                        MessageBox.Show("(2) Lỗi kết nối!");
                }
            }
            SETdgvChiTietPhieuSua();
            SetTongTien();
        }

        private void btnHTvsTT_Click(object sender, EventArgs e) // Button hoàn tất - thanh toán
        {
            DataControl.Data data = new DataControl.Data();
            DataTable tb = new DataTable();
            if (txtPhieuSua_NgayNhan.TextLength == 0)
                MessageBox.Show("Vui lòng chọn xe!");
            else
            {
                string BienSo = cboPhieuSua_BienSo.Text;
                float TongTien = float.Parse(txtThanhToan.Text);
                string NgaySua = DateTime.Now.ToString("yyyy-MM-dd");
                //Lấy Id phiếu nhận
                int MaPhieuNhan = GetIDPhieuNhan(BienSo);
                if (MaPhieuNhan == 0)
                    MessageBox.Show("(1) Lỗi");
                //Ghi phiếu sửa
                int x = data.insertPhieuSua(MaPhieuNhan, NgaySua, TongTien);
                if (x == 0)
                    MessageBox.Show("Lỗi ghi phiếu sửa");
                else
                    data.updateTienNo(BienSo, TongTien);
                //Lấy ID phiếu sửa
                int MaPhieuSua = GetIDPhieuSua();
                if (MaPhieuSua == 0)
                    MessageBox.Show("(2) Lỗi");
                else
                    data.updateTienNo(BienSo, TongTien);
                //Lấy chi tiết phiếu sửa
                tb = data.PhieuTam();
                //Ghi chi tiết phiếu sửa
                if (tb.Rows.Count != 0)
                {
                    for (int i = 0; i < tb.Rows.Count; i++)
                    {
                        DataRow row = tb.Rows[i];
                        string MaCong = row[0].ToString();
                        string MaPT = row[2].ToString();
                        int SL = Convert.ToInt32(row[4].ToString());
                        float DonGia = float.Parse(row[5].ToString());
                        float TienCong = float.Parse(row[6].ToString());
                        float TienPT = float.Parse(row[7].ToString());
                        float ThanhTien = float.Parse(row[8].ToString());
                        int n = data.insertChiTietPhieuSua(MaPhieuSua, MaCong, MaPT, DonGia, SL, TienCong, TienPT, ThanhTien);
                        if (n == 0)
                            MessageBox.Show("(3) Lỗi");
                        else
                            data.resetPhieuTam();
                    }
                }
                else
                    MessageBox.Show("Xe chưa sửa xong hoặc xem hộ");
                SETdgvChiTietPhieuSua();
                SETcbo_ListBienSo();
            }
        }

        private int GetIDPhieuNhan(string BienSo) // Hàm lấy mã phiếu nhận để ghi vào phiếu sửa
        {
            DataControl.Data data = new DataControl.Data();
            DataTable tb = new DataTable();
            tb = data.MaPhieuNhan(BienSo);
            if (tb.Rows.Count != 0)
            {
                int n = Convert.ToInt32(tb.Rows[0][0].ToString());
                return n;
            }
            else
                return 0;
        }

        private int GetIDPhieuSua() // Hàm lấy mã phiếu sửa vừa tạo để ghi vào chi tiết
        {
            DataControl.Data data = new DataControl.Data();
            DataTable tb = new DataTable();
            tb = data.IDPhieuSua();
            if (tb.Rows.Count != 0)
            {
                int n = Convert.ToInt32(tb.Rows[0][0].ToString());
                return n;
            }
            else
                return 0;
        }

        private void SetTongTien()
        {
            DataControl.Data data = new DataControl.Data();
            DataTable tb = new DataTable();
            tb = data.TongTien();
            DataRow row = tb.Rows[0];
            float TongTien = float.Parse(row[0].ToString());
            txtThanhToan.Text = TongTien.ToString();
        }

        private bool KiemTraPhieuTam(string MaCong) // Kiểm tra nội dung công đã được ghi vào bảng tạm chưa
        {
            DataTable tb = new DataTable();
            DataControl.Data data = new DataControl.Data();
            tb = data.IDPhieuTam(MaCong);
            if (tb.Rows.Count != 0)
                return true;
            else
                return false;
        }

        /// <summary> Panel Tiếp nhận xe
        /// 
        /// </summary>
        private bool TestTiepNhan() // Kiểm tra các ô đã được nhập đủ chưa
        {
            if (txtTenKH.TextLength != 0 && txtBienSo.TextLength != 0 && txtDiaChi.TextLength != 0 && txtSDT.TextLength != 0)
                return true;
            else
                return false;
        }

        private void SETcbo_ListHieuXe()
        {
            DataControl.QuanTri HX = new DataControl.QuanTri();
            HX.ListHieuXe();
            cboListHX.DataSource = HX._TB;
            cboListHX.DisplayMember = "MaHieuXe";
            cboListHX.ValueMember = "TenHieuXe";
        }

        //Button Tiếp nhận

        private void btnTiepNhan_Click(object sender, EventArgs e)
        {
            int SoXe = GetSoXeNhan();
            int ThamSo = GetThamSo();
            if (SoXe == ThamSo)
                MessageBox.Show("Số xe nhận đã đạt tối đa");
            else
            {
                if (TestTiepNhan() == true)
                {
                    DataControl.Data data = new DataControl.Data();
                    string BienSo = txtBienSo.Text;
                    string ChuXe = txtTenKH.Text;
                    string HieuXe = cboListHX.Text;
                    string DiaChi = txtDiaChi.Text;
                    int SDT = Convert.ToInt32(txtSDT.Text);
                    DataTable tb = new DataTable();
                    tb = data.IDXe(BienSo);
                    bool x;

                    //Kiểm tra biển số, nếu xe đã có, update thông tin
                    if (tb.Rows.Count != 0)
                    {
                        int n = data.updateXe(BienSo, ChuXe, DiaChi, SDT);
                        if (n == 0)
                        {
                            MessageBox.Show("Vui lòng kiểm tra lại thông tin!");
                            x = false;
                        }
                        else
                            x = true;
                    }
                    //Nếu xe chưa có thì tạo mới thông tin
                    else
                    {
                        int m = data.insertXe(BienSo, ChuXe, HieuXe, DiaChi, SDT, 0);
                        if (m == 0)
                        {
                            MessageBox.Show("Vui lòng kiểm tra lại thông tin!");
                            x = false;
                        }
                        else
                            x = true;
                    }
                    //Bước ghi phiếu nhận
                    if (x == true)
                    {
                        if (KiemTraBienSo() == true) //Kiểm tra xe có đang sửa hay không
                            MessageBox.Show("Xe đang sửa");
                        else
                        {
                            int y = data.insertPhieuNhan(BienSo, DateTime.Now);
                            if (y == 0)
                                MessageBox.Show("Lỗi ghi phiếu");
                            else
                            {
                                MessageBox.Show("ok");
                                txtBienSo.Clear();
                                txtTenKH.Clear();
                                txtDiaChi.Clear();
                                txtSDT.Clear();
                            }
                        }
                    }
                }
                else
                    MessageBox.Show("Vui lòng nhập đầy đủ dữ liệu");
            }
        }

        private bool KiemTraBienSo() // hàm kiểm tra biển số hợp lệ hay không
        {
            string BienSo = txtBienSo.Text;
            DataTable tb = new DataTable();
            DataControl.Data data = new DataControl.Data();
            tb = data.KiemTraBienSo(BienSo);
            if (tb.Rows.Count != 0)
                return true;
            else
                return false;
        }

        private int GetSoXeNhan()
        {
            string now = DateTime.Now.ToString("MM/dd/yyyy");
            DataControl.Data data = new DataControl.Data();
            DataTable tb = new DataTable();
            tb = data.SoXeNhan(now);
            if(tb.Rows.Count != 0)
            {
                DataRow row = tb.Rows[0];
                int n = Convert.ToInt32(row[0].ToString());
                return n;
            }
            else
                return 0;
        }

        private int GetThamSo()
        {
            DataControl.Data data = new DataControl.Data();
            DataTable tb = new DataTable();
            tb = data.ThamSo();
            if (tb.Rows.Count != 0)
            {
                DataRow row = tb.Rows[0];
                int n = Convert.ToInt32(row[0].ToString());
                return n;
            }
            else
                return 0;
        }

        //
        // Button Menu Quản lý
        //
        private void TiepNhanXeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showQuanLy();
            pnlPhieuSua.Hide();
            pnlTiepNhan.Show();
            pnlTiepNhan.Dock = DockStyle.Fill;
            pnlTiepNhan.BringToFront();
            SETcbo_ListHieuXe();
        }

        private void PhieuSuaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showQuanLy();
            pnlTiepNhan.Hide();
            pnlPhieuSua.Show();
            pnlPhieuSua.Dock = DockStyle.Fill;
            pnlPhieuSua.BringToFront();
            SETcbo_ListPhuTung();
            SETcbo_ListTienCong();
            SETcbo_ListBienSo();
            SETdgvChiTietPhieuSua();
        }
        //
        //Button Logout
        //
        private void LogoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary> Panel phiếu thu tiền
        /// 
        /// </summary>
        private void PhieuThuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showQuanLy();
            pnlTiepNhan.Hide();
            pnlPhieuSua.Hide();
            pnlPhieuThuTien.Show();
            pnlPhieuThuTien.Dock = DockStyle.Fill;
            pnlPhieuThuTien.BringToFront();
            string NgayThu = DateTime.Now.ToString("dd/MM/yyyy");
            txtPT_NgayThu.Text = NgayThu;
            SetPhieuThu();
        }

        private void btnThuTien_Click(object sender, EventArgs e)
        {
            float TienThu = float.Parse(txtPT_SoTienThu.Text);
            float NoMoi = float.Parse(txtPT_NoMoi.Text);
            if (NoMoi < 0)
                MessageBox.Show("Nhập số tiền thu không lớn hơn nợ cũ");
            string BienSo = cboPT_BienSo.SelectedValue.ToString();
            string Email = txtPT_Email.Text;
            string NgayLap = DateTime.Now.ToString("MM/dd/yyyy");
            DataControl.Data data = new DataControl.Data();
            int x = data.insertPhieuThu(BienSo, Email, TienThu, NgayLap);
            if (x == 0)
                MessageBox.Show("Lỗi ghi phiếu thu");
            else
                data.TienNo(BienSo, NoMoi); // update nợ mới
            ResetPhieuThu();
        }

        private void btnHuyThu_Click(object sender, EventArgs e)
        {
            ResetPhieuThu();
        }

        private void SetPhieuThu()
        {
            DataControl.Data data = new DataControl.Data();
            DataTable tb = new DataTable();
            tb = data.ListXe();
            cboPT_BienSo.DataSource = tb;
            cboPT_BienSo.DisplayMember = "BienSo";
            cboPT_BienSo.ValueMember = "BienSo";
        }

        private void ResetPhieuThu()
        {
            txtPT_ChuXe.Text = "";
            txtPT_DienThoai.Text = "";
            txtPT_NoMoi.Text = "0";
            txtPT_TienNo.Text = "0";
            txtPT_SoTienThu.Text = "0";
            txtPT_Email.Text = "";
        }

        private void txtPT_SoTienThu_TextChanged(object sender, EventArgs e)
        {
            try
            {
                float TienNo = float.Parse(txtPT_TienNo.Text);
                float TienThu = float.Parse(txtPT_SoTienThu.Text);
                float NoMoi = TienNo - TienThu;
                txtPT_NoMoi.Text = NoMoi.ToString();
            }
            catch
            {
                return;
            }
        }

        private void cboPT_BienSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            if (!cb.Focused)
            {
                return;
            }
            string bienso = cboPT_BienSo.SelectedValue.ToString();
            DataControl.Data data = new DataControl.Data();
            DataTable tb = new DataTable();
            tb = data.IDXe(bienso);
            if(tb.Rows.Count !=0 )
            {
                DataRow row = tb.Rows[0];
                txtPT_ChuXe.Text = row[2].ToString();
                txtPT_DienThoai.Text = row[4].ToString();
                txtPT_TienNo.Text = row[5].ToString();
            }
        }

        private bool TestPhieuThu()
        {
            if (txtPT_ChuXe.TextLength != 0 && txtPT_SoTienThu.TextLength != 0)
                return true;
            else
                return false;
        }
        /// <summary>
        /// 
        /// </summary>
        
        #endregion

        #region Tra cứu

        private void ShowTracuu()
        {
            pnlQuanTri.Show();
            pnlThongKe.Hide();
            pnlQuanLy.Hide();
            pnlQuanTri.Show();
            pnlQuanTri.Dock = DockStyle.Fill;
            pnlQuanTri.BringToFront();
        }

        private void DSXeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowTracuu();
            pnlQT_TienCong.Hide();
            pnlQT_PhuTung.Hide();
            pnlQT_Hieuxe.Hide();
            pnlTC_Xe.Show();
            pnlTC_Xe.Dock = DockStyle.Fill;
            pnlTC_Xe.BringToFront();
            SETDGV_DSXe();
            SETcboTC_BienSo();
        }

        private void SETDGV_DSXe()
        {
            DataControl.Data data = new DataControl.Data();
            dgvDSXe.DataSource = null;
            dgvDSXe.DataSource = data.ListXe();
            dgvDSXe.Columns[0].HeaderText = "Biển số";
            dgvDSXe.Columns[1].HeaderText = "Hiệu xe";
            dgvDSXe.Columns[2].HeaderText = "Chủ xe";
            dgvDSXe.Columns[3].HeaderText = "Địa chỉ";
            dgvDSXe.Columns[4].HeaderText = "Điện thoại";
            dgvDSXe.Columns[5].HeaderText = "Tiền nợ";
            dgvDSXe.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDSXe.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private void dgvDSXe_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            txtTC_BienSo.Text = dgvDSXe.SelectedRows[0].Cells[0].Value.ToString();
            txtTC_HieuXe.Text = dgvDSXe.SelectedRows[0].Cells[1].Value.ToString();
            txtTC_ChuXe.Text = dgvDSXe.SelectedRows[0].Cells[2].Value.ToString();
            txtTC_TienNo.Text = dgvDSXe.SelectedRows[0].Cells[5].Value.ToString();
            txtTC_DiaChi.Text = dgvDSXe.SelectedRows[0].Cells[3].Value.ToString();
            txtTC_SDT.Text = dgvDSXe.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void cboTC_BienSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            int a = cboTC_BienSo.SelectedIndex;
            dgvDSXe.Rows[a].Selected = true;
            dgvDSXe.FirstDisplayedScrollingRowIndex = a;
        }

        private void SETcboTC_BienSo()
        {
            DataControl.Data data = new DataControl.Data();
            cboTC_BienSo.DataSource = data.ListXe();
            cboTC_BienSo.DisplayMember = "BienSo";
            cboTC_BienSo.ValueMember = "BienSo";
        }

        #endregion

        #region Thống kê

        private void showThongke()
        {
            pnlQuanTri.Hide();
            pnlQuanLy.Hide();
            pnlTonKho.Hide();
            pnlThongKe.Show();
            pnlThongKe.Dock = DockStyle.Fill;
            pnlThongKe.BringToFront();
            int nam = DateTime.Now.Year;
            this.cboNam.Items.AddRange(new object[] {
            nam, nam-1, nam-2});
            cboNam.SelectedIndex = 0;
            cboThang.SelectedIndex = 0;
        }

        /// <summary> Thống kê doanh thu
        /// 
        /// </summary>
        private void DoanhThuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showThongke();
            //SetDgvDoanhThu();
        }

        //button In báo cáo
        private void btnIn_Click(object sender, EventArgs e)
        {
            int thang = Convert.ToInt32(cboThang.Text);
            int nam = Convert.ToInt32(cboNam.Text);
            DataControl.QuanTri qt = new DataControl.QuanTri();
            qt.resetDoanhThu();
            for(int i =0; i<dgvDoanhThu.Rows.Count; i++)
            {
                string hieuxe = dgvDoanhThu.Rows[i].Cells[0].Value.ToString();
                int luotsua = Convert.ToInt32(dgvDoanhThu.Rows[i].Cells[1].Value.ToString());
                float TongTien = float.Parse(dgvDoanhThu.Rows[i].Cells[2].Value.ToString());
                float Tile = float.Parse(dgvDoanhThu.Rows[i].Cells[3].Value.ToString());
                qt.insertDoanhThu(thang, nam, hieuxe, luotsua, TongTien, Tile);
            }
            frmDoanhThu frm = new frmDoanhThu();
            frm.ShowDialog();
        }

        private DateTime GetEndDay(int thang, int nam)
        {
            if (thang == 12)
            {
                DateTime x = new DateTime(nam + 1, 1, 1);
                return x;
            }
            else
            {
                DateTime x = new DateTime(nam, thang + 1, 1);
                return x;
            }
        }

        private void btnKetqua_Click(object sender, EventArgs e)
        {
            SetDgvDoanhThu();
        }

        private void SetDgvDoanhThu()
        {
            int thang = Convert.ToInt32(cboThang.Text);
            int nam = Convert.ToInt32(cboNam.Text);
            DateTime start = new DateTime(nam, thang, 1);
            DateTime end = GetEndDay(thang, nam);
            dgvDoanhThu.Columns.Clear();
            DataControl.QuanTri qt = new DataControl.QuanTri();
            DataTable tb = new DataTable();
            tb = qt.DoanhThu(start, end);
            int n = tb.Rows.Count;
            dgvDoanhThu.DataSource = tb;
            dgvDoanhThu.Columns.Add("Column", "Tỉ lệ");
            dgvDoanhThu.Columns[0].HeaderText = "Hiệu xe";
            dgvDoanhThu.Columns[1].HeaderText = "Số lượt sửa";
            dgvDoanhThu.Columns[2].HeaderText = "Tổng tiền (%)";
            for (int i = 1; i < 3; i++)
            {
                dgvDoanhThu.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvDoanhThu.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            dgvDoanhThu.Columns[0].SortMode = DataGridViewColumnSortMode.NotSortable;
            float sum = 0;
            for (int i = 0; i < tb.Rows.Count; i++)
            {
                DataRow row = tb.Rows[i];
                sum += float.Parse(row[2].ToString());
            }
            for (int i = 0; i < tb.Rows.Count; i++)
            {
                float x = float.Parse(dgvDoanhThu.Rows[i].Cells[2].Value.ToString());
                string z;
                if(sum !=0)
                {
                    float y = x * 100 / sum;
                    z = string.Format("{0:0.00}", y);
                }
                else
                {
                    z = "0";
                }
                dgvDoanhThu.Rows[i].Cells[3].Value = z;
            }
            txtDoanhThu.Text = sum.ToString();
        }

        /// <summary> Thống kê tồn kho
        /// 
        /// </summary>
        private void TonKhoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showThongke();
            pnlTonKho.Show();
            pnlTonKho.Dock = DockStyle.Fill;
            pnlTonKho.BringToFront();
            int nam = DateTime.Now.Year;
            this.cboTK_Nam.Items.AddRange(new object[] {
            nam, nam-1, nam-2});
            cboTK_Nam.SelectedIndex = 0;
            cboTK_Thang.SelectedIndex = 0;
        }

        private void btnXemTK_Click(object sender, EventArgs e)
        {
            SetDgvTonKho();
        }

        //button In báo cáo
        private void btnInTK_Click(object sender, EventArgs e)
        {
            int thang = Convert.ToInt32(cboThang.Text);
            int nam = Convert.ToInt32(cboNam.Text);
            DataControl.QuanTri qt = new DataControl.QuanTri();
            qt.resetTonKho();
            for (int i = 0; i < dgvTonKho.Rows.Count; i++)
            {
                string MaPhuTung = dgvTonKho.Rows[i].Cells[0].Value.ToString();
                int TonDau = Convert.ToInt32(dgvTonKho.Rows[i].Cells[2].Value.ToString());
                int PhatSinh = Convert.ToInt32(dgvTonKho.Rows[i].Cells[3].Value.ToString());
                int TonCuoi = Convert.ToInt32(dgvTonKho.Rows[i].Cells[3].Value.ToString());
                qt.insertTonKho(thang, nam, MaPhuTung, TonDau, PhatSinh, TonCuoi);
            }
            frmTonKho frm = new frmTonKho();
            frm.ShowDialog();
        }
        
        private void SetDgvTonKho()
        {
            int thang = Convert.ToInt32(cboTK_Thang.Text);
            int nam = Convert.ToInt32(cboTK_Nam.Text);
            DateTime start = new DateTime(nam, thang, 1);
            DateTime end = GetEndDay(thang, nam);
            dgvDoanhThu.Columns.Clear();
            DataControl.QuanTri qt = new DataControl.QuanTri();
            DataTable tb = new DataTable();
            tb = qt.TonKho(start, end);
            int n = tb.Rows.Count;
            dgvTonKho.DataSource = tb;
            dgvTonKho.Columns.Add("Column", "Tồn cuối");
            dgvTonKho.Columns[0].HeaderText = "Mã Phụ tùng";
            dgvTonKho.Columns[1].HeaderText = "Tên phụ tùng";
            dgvTonKho.Columns[1].Width = 200;
            dgvTonKho.Columns[2].HeaderText = "Tồn đầu";
            dgvTonKho.Columns[2].Width = 90;
            dgvTonKho.Columns[3].HeaderText = "Phát sinh";
            dgvTonKho.Columns[3].Width = 90;
            dgvTonKho.Columns[4].HeaderText = "Tồn cuối";
            dgvTonKho.Columns[4].Width = 90;
            for (int i = 2; i <= 4; i++)
            {
                dgvTonKho.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvTonKho.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            dgvTonKho.Columns[0].SortMode = DataGridViewColumnSortMode.NotSortable;
            dgvTonKho.Columns[1].SortMode = DataGridViewColumnSortMode.NotSortable;
            float toncuoi = 0;
            for (int i = 0; i < tb.Rows.Count; i++)
            {
                DataRow row = tb.Rows[i];
                toncuoi = float.Parse(row[2].ToString()) - float.Parse(row[3].ToString());
                dgvTonKho.Rows[i].Cells[4].Value = toncuoi;
            }
        }

        #endregion

        #region Quản trị
        //
        // Quản trị hiệu xe
        //
        private void HieuXeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowTracuu();
            pnlQT_TienCong.Hide();
            pnlQT_PhuTung.Hide();
            pnlTC_Xe.Hide();
            pnlQT_Hieuxe.Show();
            pnlQT_Hieuxe.Dock = DockStyle.Fill;
            pnlQT_Hieuxe.BringToFront();
            SETdgvQT_HieuXe();
            SETcboQT_HieuXe();
        }

        private void btnHX_Them_Click(object sender, EventArgs e) // Button Thêm
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            if (TestHieuXe() == true)
            {
                string MaHieuXe = txtHX_MaHX.Text;
                string TenHieuXe = txtHX_TenHX.Text;
                int n = QT.insertHieuXe(MaHieuXe, TenHieuXe);
                if (n == 1)
                {
                    MessageBox.Show("Thêm thành công");
                    txtHX_MaHX.Clear();
                    txtHX_TenHX.Clear();
                    SETdgvQT_HieuXe();
                    SETcboQT_HieuXe();
                }
                else
                    MessageBox.Show("Không thể thêm công này!\nVui lòng kiểm tra lại!");
            }
            else
                MessageBox.Show("Vui lòng nhập đầy đủ dữ liệu");
        }

        private void btnHX_Sua_Click(object sender, EventArgs e) // Button Sửa
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            if (TestHieuXe() == true)
            {
                string MaHieuXe = txtHX_MaHX.Text;
                string TenHieuXe = txtHX_TenHX.Text;
                int n = QT.updateHieuXe(MaHieuXe, TenHieuXe);
                if (n == 1)
                {
                    MessageBox.Show("Sửa thành công");
                    txtHX_MaHX.Clear();
                    txtHX_TenHX.Clear();
                    SETdgvQT_HieuXe();
                    SETcboQT_HieuXe();
                }
                else
                    MessageBox.Show("Đã có lỗi xảy ra!\nVui lòng kiểm tra lại!");
            }
            else
                MessageBox.Show("Vui lòng nhập đầy đủ dữ liệu");
        }

        private void btnHX_Xoa_Click(object sender, EventArgs e) // Button xóa
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            if (txtHX_MaHX.Text != "")
            {
                string MaHieuXe = txtHX_MaHX.Text;
                int n = QT.deleteHieuXe(MaHieuXe);
                if (n == 1)
                {
                    MessageBox.Show("Xóa thành công");
                    txtHX_MaHX.Clear();
                    txtHX_TenHX.Clear();
                    SETdgvQT_HieuXe();
                    SETcboQT_HieuXe();
                }
                else
                    MessageBox.Show("Đã xảy ra lỗi!\nVui lòng kiểm tra lại!");
            }
            else
                MessageBox.Show("Vui lòng chọn hiệu xe để xóa");
        }

        private void dgvHieuXe_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            txtHX_MaHX.Text = dgvHieuXe.SelectedRows[0].Cells[0].Value.ToString();
            txtHX_TenHX.Text = dgvHieuXe.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void SETdgvQT_HieuXe()
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            QT.ListHieuXe();
            dgvHieuXe.DataSource = QT._TB;
            dgvHieuXe.Columns[0].HeaderText = "Mã hiệu xe";
            dgvHieuXe.Columns[1].HeaderText = "Tên hiệu xe";
        }

        private void SETcboQT_HieuXe()
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            QT.ListHieuXe();
            cboQT_HieuXe.DataSource = QT._TB;
            cboQT_HieuXe.DisplayMember = "MaHieuXe";
            cboQT_HieuXe.ValueMember = "TenHieuXe";
        }

        private void cboQT_HieuXe_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            if (!cb.Focused)
            {
                return;
            }
            int n = cboQT_HieuXe.SelectedIndex;
            dgvHieuXe.Rows[n].Selected = true;
            dgvHieuXe.FirstDisplayedScrollingRowIndex = n;
        }

        private bool TestHieuXe() // hàm kiểm tra nhập vào các textbox chưa
        {
            if (txtHX_MaHX.TextLength != 0 && txtHX_TenHX.TextLength != 0)
                return true;
            else
                return false;
        }

        //
        // Quản trị phụ tùng
        //
        private void PhuTungToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowTracuu();
            pnlQT_Hieuxe.Hide();
            pnlTC_Xe.Hide();
            pnlQT_TienCong.Hide();
            pnlQT_PhuTung.Show();
            pnlQT_PhuTung.Dock = DockStyle.Fill;
            pnlQT_PhuTung.BringToFront();
            SETcboQT_PhuTung();
            SETdgvQT_PhuTung();
        }

        private void btnPT_Them_Click(object sender, EventArgs e)
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            if (TestPhuTung() == true)
            {
                string MaPT = txtPT_MaPT.Text;
                string TenPT = txtPT_TenPT.Text;
                int SL = Convert.ToInt32(txtPT_SoLuong.Text);
                float DonGia = float.Parse(txtPT_DonGia.Text);
                int n = QT.insertPhuTung(MaPT, TenPT, SL, DonGia);
                if (n == 1)
                {
                    MessageBox.Show("Thêm thành công");
                    txtPT_MaPT.Clear();
                    txtPT_TenPT.Clear();
                    txtPT_SoLuong.Clear();
                    txtPT_DonGia.Clear();
                    SETdgvQT_PhuTung();
                    SETcboQT_PhuTung();
                }
                else
                    MessageBox.Show("Đã có lỗi xảy ra!\nVui lòng kiểm tra lại!");
            }
            else
                MessageBox.Show("Vui lòng nhập đầy đủ dữ liệu");
        }

        private void btnPT_Sua_Click(object sender, EventArgs e)
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            if (TestPhuTung() == true)
            {
                string MaPT = txtPT_MaPT.Text;
                string TenPT = txtPT_TenPT.Text;
                int SL = Convert.ToInt32(txtPT_SoLuong.Text);
                float DonGia = float.Parse(txtPT_DonGia.Text);
                int n = QT.updatePhuTung(MaPT, TenPT, SL, DonGia);
                if (n == 1)
                {
                    MessageBox.Show("Sửa thành công");
                    txtPT_MaPT.Clear();
                    txtPT_TenPT.Clear();
                    txtPT_SoLuong.Clear();
                    txtPT_DonGia.Clear();
                    SETdgvQT_PhuTung();
                    SETcboQT_PhuTung();
                }
                else
                    MessageBox.Show("Đã có lỗi xảy ra!\nVui lòng kiểm tra lại!");
            }
            else
                MessageBox.Show("Vui lòng nhập đầy đủ dữ liệu");
        }

        private void btnPT_Xoa_Click(object sender, EventArgs e)
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            if (txtPT_MaPT.Text != "")
            {
                string MaPT = txtPT_MaPT.Text;
                int n = QT.deletePhuTung(MaPT);
                if (n == 1)
                {
                    MessageBox.Show("Xóa thành công");
                    txtPT_MaPT.Clear();
                    txtPT_TenPT.Clear();
                    txtPT_SoLuong.Clear();
                    txtPT_DonGia.Clear();
                    SETdgvQT_PhuTung();
                    SETcboQT_PhuTung();
                }
                else
                    MessageBox.Show("Đã xảy ra lỗi!\nVui lòng kiểm tra lại!");
            }
            else
                MessageBox.Show("Vui lòng chọn loại công để xóa");
        }

        private void cboQT_PhuTung_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            if (!cb.Focused)
            {
                return;
            }
            int n = cboQT_TienCong.SelectedIndex;
            dgvPhuTung.Rows[n].Selected = true;
            dgvPhuTung.FirstDisplayedScrollingRowIndex = n;
        }

        private void dgvPhuTung_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            txtPT_MaPT.Text = dgvPhuTung.SelectedRows[0].Cells[0].Value.ToString();
            txtPT_TenPT.Text = dgvPhuTung.SelectedRows[0].Cells[1].Value.ToString();
            txtPT_SoLuong.Text = dgvPhuTung.SelectedRows[0].Cells[2].Value.ToString();
            txtPT_DonGia.Text = dgvPhuTung.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void SETdgvQT_PhuTung()
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            QT.ListPhuTung();
            dgvPhuTung.DataSource = QT._TB;
            dgvPhuTung.Columns[0].HeaderText = "Mã phụ tùng";
            dgvPhuTung.Columns[1].HeaderText = "Tên phụ tùng";
            dgvPhuTung.Columns[2].HeaderText = "Số lượng";
            dgvPhuTung.Columns[3].HeaderText = "Đơn giá";
            dgvPhuTung.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvPhuTung.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private void SETcboQT_PhuTung()
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            QT.ListPhuTung();
            cboQT_PhuTung.DataSource = QT._TB;
            cboQT_PhuTung.DisplayMember = "MaPhuTung";
            cboQT_PhuTung.ValueMember = "TenPhuTung";
        }

        private bool TestPhuTung() // hàm kiểm tra nhập vào các textbox chưa
        {
            if (txtPT_MaPT.TextLength != 0 && txtPT_TenPT.TextLength != 0 && txtPT_SoLuong.TextLength != 0 && txtPT_DonGia.TextLength !=0)
                return true;
            else
                return false;
        }
        //
        // Quản trị tiền công
        //
        private void TienCongToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowTracuu();
            pnlQT_Hieuxe.Hide();
            pnlTC_Xe.Hide();
            pnlQT_PhuTung.Hide();
            pnlQT_TienCong.Show();
            pnlQT_TienCong.Dock = DockStyle.Fill;
            pnlQT_TienCong.BringToFront();
            SETdgvQT_TienCong();
            SETcboQT_TienCong();
        }

        private void SETdgvQT_TienCong()
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            QT.ListTienCong();
            dgvQT_TienCong.DataSource = QT._TB;
            dgvQT_TienCong.Columns[0].HeaderText = "Mã loại công";
            dgvQT_TienCong.Columns[1].HeaderText = "Tên loại công";
            dgvQT_TienCong.Columns[2].HeaderText = "Tiền công";
            dgvQT_TienCong.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private void SETcboQT_TienCong()
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            QT.ListTienCong();
            cboQT_TienCong.DataSource = QT._TB;
            cboQT_TienCong.DisplayMember = "MaCong";
            cboQT_TienCong.ValueMember = "TenCong";
        }

        private void cboQT_TienCong_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            if (!cb.Focused)
            {
                return;
            }
            int n = cboQT_TienCong.SelectedIndex;
            dgvQT_TienCong.Rows[n].Selected = true;
            dgvQT_TienCong.FirstDisplayedScrollingRowIndex = n;
        }

        private void dgvQT_TienCong_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            txtQT_MaTC.Text = dgvQT_TienCong.SelectedRows[0].Cells[0].Value.ToString();
            txtQT_TenTC.Text = dgvQT_TienCong.SelectedRows[0].Cells[1].Value.ToString();
            txtQT_TienCong.Text = dgvQT_TienCong.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void btnTC_Them_Click(object sender, EventArgs e) // Button thêm
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            if (TestTienCong() == true)
            {
                string MaCong = txtQT_MaTC.Text;
                string TenCong = txtQT_TenTC.Text;
                float TienCong = float.Parse(txtQT_TienCong.Text);
                int n = QT.insertTienCong(MaCong, TenCong, TienCong);
                if (n == 1)
                {
                    MessageBox.Show("Thêm thành công");
                    txtQT_MaTC.Clear();
                    txtQT_TenTC.Clear();
                    txtQT_TienCong.Clear();
                    SETdgvQT_TienCong();
                    SETcboQT_TienCong();
                }
                else
                    MessageBox.Show("Không thể thêm công này!\nVui lòng kiểm tra lại!");
            }
            else
                MessageBox.Show("Vui lòng nhập đầy đủ dữ liệu");
        }

        private void btnTC_Sua_Click(object sender, EventArgs e) // Button sửa
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            if (TestTienCong() == true)
            {
                string MaCong = txtQT_MaTC.Text;
                string TenCong = txtQT_TenTC.Text;
                float TienCong = float.Parse(txtQT_TienCong.Text);
                int n = QT.updateTienCong(MaCong, TenCong, TienCong);
                if (n == 1)
                {
                    MessageBox.Show("Sửa thành công");
                    txtQT_MaTC.Clear();
                    txtQT_TenTC.Clear();
                    txtQT_TienCong.Clear();
                    SETdgvQT_TienCong();
                    SETcboQT_TienCong();
                }
                else
                    MessageBox.Show("Đã có lỗi xảy ra!\nVui lòng kiểm tra lại!");
            }
            else
                MessageBox.Show("Vui lòng nhập đầy đủ dữ liệu");
        }

        private void btnTC_Xoa_Click(object sender, EventArgs e) // Button xóa
        {
            DataControl.QuanTri QT = new DataControl.QuanTri();
            if (txtQT_MaTC.Text != "")
            {
                string MaCong = txtQT_MaTC.Text;
                int n = QT.deleteTienCong(MaCong);
                if (n == 1)
                {
                    MessageBox.Show("Xóa thành công");
                    txtQT_MaTC.Clear();
                    txtQT_TenTC.Clear();
                    txtQT_TienCong.Clear();
                    SETdgvQT_TienCong();
                    SETcboQT_TienCong();
                }
                else
                    MessageBox.Show("Đã xảy ra lỗi!\nVui lòng kiểm tra lại!");
            }
            else
                MessageBox.Show("Vui lòng chọn loại công để xóa");
        }

        private void btnReloadTC_Click(object sender, EventArgs e)
        {
            SETdgvQT_TienCong();
            SETcboQT_TienCong();
        }

        private bool TestTienCong() // hàm kiểm tra nhập vào các textbox chưa
        {
            if (txtQT_MaTC.TextLength != 0 && txtQT_TenTC.TextLength != 0 && txtQT_TienCong.TextLength != 0)
                return true;
            else
                return false;
        }

        private void MaxNhanXeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmThamSo frm = new frmThamSo();
            frm.ShowDialog();
        }

        #endregion

        #region OtherFunction

        private bool nonNumberEntered;

        private void txtPT_SoTienThu_KeyDown(object sender, KeyEventArgs e)
        {
            SetEventKD(sender, e);
        }

        private void txtPT_SoTienThu_KeyPress(object sender, KeyPressEventArgs e)
        {
            SetEventKP(sender, e);
        }

        private void txtSDT_KeyDown(object sender, KeyEventArgs e)
        {
            SetEventKD(sender, e);
        }

        private void txtSDT_KeyPress(object sender, KeyPressEventArgs e)
        {
            SetEventKP(sender, e);
        }

        private void txtSoLuong_KeyDown(object sender, KeyEventArgs e)
        {
            SetEventKD(sender, e);
        }

        private void txtSoLuong_KeyPress(object sender, KeyPressEventArgs e)
        {
            SetEventKP(sender, e);
        }

        private void txtQT_TienCong_KeyDown(object sender, KeyEventArgs e)
        {
            SetEventKD(sender, e);
        }

        private void txtQT_TienCong_KeyPress(object sender, KeyPressEventArgs e)
        {
            SetEventKP(sender, e);
        }

        private void txtPT_SoLuong_KeyDown(object sender, KeyEventArgs e)
        {
            SetEventKD(sender, e);
        }

        private void txtPT_SoLuong_KeyPress(object sender, KeyPressEventArgs e)
        {
            SetEventKP(sender, e);
        }

        private void txtPT_DonGia_KeyDown(object sender, KeyEventArgs e)
        {
            SetEventKD(sender, e);
        }

        private void txtPT_DonGia_KeyPress(object sender, KeyPressEventArgs e)
        {
            SetEventKP(sender, e);
        }


        private void SetEventKD(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if (e.KeyCode != Keys.Back)
                    {
                        nonNumberEntered = true;
                    }
                }
            }
            if (Control.ModifierKeys == Keys.Shift)
            {
                nonNumberEntered = true;
            }
        }

        private void SetEventKP(object sender, KeyPressEventArgs e)
        {
            if (nonNumberEntered == true)
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        #endregion
    }
}

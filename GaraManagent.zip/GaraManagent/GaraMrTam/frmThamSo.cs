﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaraMrTam
{
    public partial class frmThamSo : Form
    {
        public frmThamSo()
        {
            InitializeComponent();
        }

        private void frmThamSo_Load(object sender, EventArgs e)
        {

        }

        private bool nonNumberEntered;

        private void txtThamSo_KeyDown(object sender, KeyEventArgs e)
        {
            SetEventKD(sender, e);
            if(e.KeyCode == Keys.Enter)
            {
                int n = Convert.ToInt32(txtThamSo.Text);
                DataControl.QuanTri qt = new DataControl.QuanTri();
                qt.ThamSo(n);
                this.Close();
            }
        }

        private void SetEventKD(object sender, KeyEventArgs e)
        {
            nonNumberEntered = false;
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    if (e.KeyCode != Keys.Back)
                    {
                        nonNumberEntered = true;
                    }
                }
            }
            if (Control.ModifierKeys == Keys.Shift)
            {
                nonNumberEntered = true;
            }
        }

        private void txtThamSo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (nonNumberEntered == true)
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }
    }
}

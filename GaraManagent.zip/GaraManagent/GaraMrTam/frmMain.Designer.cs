﻿namespace GaraMrTam
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuChinh = new System.Windows.Forms.MenuStrip();
            this.QuanLyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TiepNhanXeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PhieuSuaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PhieuThuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LogoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TraCuuToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.DSXeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ThongKeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.DoanhThuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TonKhoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.QuanTriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HieuXeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PhuTungToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TienCongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MaxNhanXeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlContent = new System.Windows.Forms.Panel();
            this.pnlTonKho = new System.Windows.Forms.Panel();
            this.btnXemTK = new System.Windows.Forms.Button();
            this.btnInTK = new System.Windows.Forms.Button();
            this.cboTK_Nam = new System.Windows.Forms.ComboBox();
            this.cboTK_Thang = new System.Windows.Forms.ComboBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.dgvTonKho = new System.Windows.Forms.DataGridView();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.pnlThongKe = new System.Windows.Forms.Panel();
            this.btnKetqua = new System.Windows.Forms.Button();
            this.txtDoanhThu = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.btnIn = new System.Windows.Forms.Button();
            this.cboNam = new System.Windows.Forms.ComboBox();
            this.cboThang = new System.Windows.Forms.ComboBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.dgvDoanhThu = new System.Windows.Forms.DataGridView();
            this.label51 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.pnlQuanTri = new System.Windows.Forms.Panel();
            this.pnlTC_Xe = new System.Windows.Forms.Panel();
            this.txtTC_SDT = new System.Windows.Forms.TextBox();
            this.txtTC_DiaChi = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.cboTC_BienSo = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtTC_TienNo = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtTC_ChuXe = new System.Windows.Forms.TextBox();
            this.txtTC_HieuXe = new System.Windows.Forms.TextBox();
            this.txtTC_BienSo = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.dgvDSXe = new System.Windows.Forms.DataGridView();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.pnlQT_TienCong = new System.Windows.Forms.Panel();
            this.cboQT_TienCong = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.btnTC_Xoa = new System.Windows.Forms.Button();
            this.btnTC_Sua = new System.Windows.Forms.Button();
            this.btnTC_Them = new System.Windows.Forms.Button();
            this.txtQT_TienCong = new System.Windows.Forms.TextBox();
            this.txtQT_TenTC = new System.Windows.Forms.TextBox();
            this.txtQT_MaTC = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.dgvQT_TienCong = new System.Windows.Forms.DataGridView();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.pnlQT_PhuTung = new System.Windows.Forms.Panel();
            this.cboQT_PhuTung = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.btnPT_Xoa = new System.Windows.Forms.Button();
            this.btnPT_Sua = new System.Windows.Forms.Button();
            this.btnPT_Them = new System.Windows.Forms.Button();
            this.txtPT_DonGia = new System.Windows.Forms.TextBox();
            this.txtPT_SoLuong = new System.Windows.Forms.TextBox();
            this.txtPT_TenPT = new System.Windows.Forms.TextBox();
            this.txtPT_MaPT = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dgvPhuTung = new System.Windows.Forms.DataGridView();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pnlQT_Hieuxe = new System.Windows.Forms.Panel();
            this.cboQT_HieuXe = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnHX_Xoa = new System.Windows.Forms.Button();
            this.btnHX_Sua = new System.Windows.Forms.Button();
            this.btnHX_Them = new System.Windows.Forms.Button();
            this.txtHX_TenHX = new System.Windows.Forms.TextBox();
            this.txtHX_MaHX = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dgvHieuXe = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.lblTCQT = new System.Windows.Forms.Label();
            this.pnlQuanLy = new System.Windows.Forms.Panel();
            this.pnlPhieuThuTien = new System.Windows.Forms.Panel();
            this.txtPT_DienThoai = new System.Windows.Forms.TextBox();
            this.txtPT_NgayThu = new System.Windows.Forms.TextBox();
            this.txtPT_SoTienThu = new System.Windows.Forms.TextBox();
            this.txtPT_Email = new System.Windows.Forms.TextBox();
            this.txtPT_TienNo = new System.Windows.Forms.TextBox();
            this.txtPT_NoMoi = new System.Windows.Forms.TextBox();
            this.txtPT_ChuXe = new System.Windows.Forms.TextBox();
            this.cboPT_BienSo = new System.Windows.Forms.ComboBox();
            this.btnHuyThu = new System.Windows.Forms.Button();
            this.btnThuTien = new System.Windows.Forms.Button();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.pnlPhieuSua = new System.Windows.Forms.Panel();
            this.cboPhieuSua_BienSo = new System.Windows.Forms.ComboBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnHTvsTT = new System.Windows.Forms.Button();
            this.txtThanhToan = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.dgvChiTietPhieuSua = new System.Windows.Forms.DataGridView();
            this.label28 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.txtTienCong = new System.Windows.Forms.TextBox();
            this.cboPhieuSua_PhuTung = new System.Windows.Forms.ComboBox();
            this.cboPhieuSua_NoiDung = new System.Windows.Forms.ComboBox();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.txtPhieuSua_NgayNhan = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.pnlTiepNhan = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.btnTiepNhan = new System.Windows.Forms.Button();
            this.cboListHX = new System.Windows.Forms.ComboBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtBienSo = new System.Windows.Forms.TextBox();
            this.txtTenKH = new System.Windows.Forms.TextBox();
            this.lblSDT = new System.Windows.Forms.Label();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.lblHieuXe = new System.Windows.Forms.Label();
            this.lblBienSo = new System.Windows.Forms.Label();
            this.lblTenKH = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pnlHome = new System.Windows.Forms.Panel();
            this.btnLogin = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mnuChinh.SuspendLayout();
            this.pnlContent.SuspendLayout();
            this.pnlTonKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTonKho)).BeginInit();
            this.pnlThongKe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoanhThu)).BeginInit();
            this.pnlQuanTri.SuspendLayout();
            this.pnlTC_Xe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSXe)).BeginInit();
            this.pnlQT_TienCong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQT_TienCong)).BeginInit();
            this.pnlQT_PhuTung.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhuTung)).BeginInit();
            this.pnlQT_Hieuxe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHieuXe)).BeginInit();
            this.pnlQuanLy.SuspendLayout();
            this.pnlPhieuThuTien.SuspendLayout();
            this.pnlPhieuSua.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuSua)).BeginInit();
            this.pnlTiepNhan.SuspendLayout();
            this.pnlHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuChinh
            // 
            this.mnuChinh.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.QuanLyToolStripMenuItem,
            this.TraCuuToolStripMenuItem1,
            this.ThongKeToolStripMenuItem1,
            this.QuanTriToolStripMenuItem});
            this.mnuChinh.Location = new System.Drawing.Point(0, 0);
            this.mnuChinh.Name = "mnuChinh";
            this.mnuChinh.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.mnuChinh.Size = new System.Drawing.Size(863, 24);
            this.mnuChinh.TabIndex = 1;
            this.mnuChinh.Text = "Menu";
            // 
            // QuanLyToolStripMenuItem
            // 
            this.QuanLyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TiepNhanXeToolStripMenuItem,
            this.PhieuSuaToolStripMenuItem,
            this.PhieuThuToolStripMenuItem,
            this.LogoutToolStripMenuItem});
            this.QuanLyToolStripMenuItem.Name = "QuanLyToolStripMenuItem";
            this.QuanLyToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.QuanLyToolStripMenuItem.Text = "Quản lý";
            // 
            // TiepNhanXeToolStripMenuItem
            // 
            this.TiepNhanXeToolStripMenuItem.Name = "TiepNhanXeToolStripMenuItem";
            this.TiepNhanXeToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.TiepNhanXeToolStripMenuItem.Text = "Tiếp nhận xe";
            this.TiepNhanXeToolStripMenuItem.Click += new System.EventHandler(this.TiepNhanXeToolStripMenuItem_Click);
            // 
            // PhieuSuaToolStripMenuItem
            // 
            this.PhieuSuaToolStripMenuItem.Name = "PhieuSuaToolStripMenuItem";
            this.PhieuSuaToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.PhieuSuaToolStripMenuItem.Text = "Phiếu sửa";
            this.PhieuSuaToolStripMenuItem.Click += new System.EventHandler(this.PhieuSuaToolStripMenuItem_Click);
            // 
            // PhieuThuToolStripMenuItem
            // 
            this.PhieuThuToolStripMenuItem.Name = "PhieuThuToolStripMenuItem";
            this.PhieuThuToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.PhieuThuToolStripMenuItem.Text = "Phiếu thu";
            this.PhieuThuToolStripMenuItem.Click += new System.EventHandler(this.PhieuThuToolStripMenuItem_Click);
            // 
            // LogoutToolStripMenuItem
            // 
            this.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem";
            this.LogoutToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.LogoutToolStripMenuItem.Text = "Đăng xuất";
            this.LogoutToolStripMenuItem.Click += new System.EventHandler(this.LogoutToolStripMenuItem_Click);
            // 
            // TraCuuToolStripMenuItem1
            // 
            this.TraCuuToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DSXeToolStripMenuItem});
            this.TraCuuToolStripMenuItem1.Name = "TraCuuToolStripMenuItem1";
            this.TraCuuToolStripMenuItem1.Size = new System.Drawing.Size(59, 20);
            this.TraCuuToolStripMenuItem1.Text = "Tra cứu";
            // 
            // DSXeToolStripMenuItem
            // 
            this.DSXeToolStripMenuItem.Name = "DSXeToolStripMenuItem";
            this.DSXeToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.DSXeToolStripMenuItem.Text = "Danh sách xe";
            this.DSXeToolStripMenuItem.Click += new System.EventHandler(this.DSXeToolStripMenuItem_Click);
            // 
            // ThongKeToolStripMenuItem1
            // 
            this.ThongKeToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DoanhThuToolStripMenuItem,
            this.TonKhoToolStripMenuItem});
            this.ThongKeToolStripMenuItem1.Name = "ThongKeToolStripMenuItem1";
            this.ThongKeToolStripMenuItem1.Size = new System.Drawing.Size(69, 20);
            this.ThongKeToolStripMenuItem1.Text = "Thống kê";
            // 
            // DoanhThuToolStripMenuItem
            // 
            this.DoanhThuToolStripMenuItem.Name = "DoanhThuToolStripMenuItem";
            this.DoanhThuToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.DoanhThuToolStripMenuItem.Text = "Doanh thu";
            this.DoanhThuToolStripMenuItem.Click += new System.EventHandler(this.DoanhThuToolStripMenuItem_Click);
            // 
            // TonKhoToolStripMenuItem
            // 
            this.TonKhoToolStripMenuItem.Name = "TonKhoToolStripMenuItem";
            this.TonKhoToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.TonKhoToolStripMenuItem.Text = "Tồn kho";
            this.TonKhoToolStripMenuItem.Click += new System.EventHandler(this.TonKhoToolStripMenuItem_Click);
            // 
            // QuanTriToolStripMenuItem
            // 
            this.QuanTriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.HieuXeToolStripMenuItem,
            this.PhuTungToolStripMenuItem,
            this.TienCongToolStripMenuItem,
            this.MaxNhanXeToolStripMenuItem});
            this.QuanTriToolStripMenuItem.Name = "QuanTriToolStripMenuItem";
            this.QuanTriToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.QuanTriToolStripMenuItem.Text = "Quản trị";
            // 
            // HieuXeToolStripMenuItem
            // 
            this.HieuXeToolStripMenuItem.Name = "HieuXeToolStripMenuItem";
            this.HieuXeToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.HieuXeToolStripMenuItem.Text = "Hiệu xe";
            this.HieuXeToolStripMenuItem.Click += new System.EventHandler(this.HieuXeToolStripMenuItem_Click);
            // 
            // PhuTungToolStripMenuItem
            // 
            this.PhuTungToolStripMenuItem.Name = "PhuTungToolStripMenuItem";
            this.PhuTungToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.PhuTungToolStripMenuItem.Text = "Phụ tùng";
            this.PhuTungToolStripMenuItem.Click += new System.EventHandler(this.PhuTungToolStripMenuItem_Click);
            // 
            // TienCongToolStripMenuItem
            // 
            this.TienCongToolStripMenuItem.Name = "TienCongToolStripMenuItem";
            this.TienCongToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.TienCongToolStripMenuItem.Text = "Tiền công";
            this.TienCongToolStripMenuItem.Click += new System.EventHandler(this.TienCongToolStripMenuItem_Click);
            // 
            // MaxNhanXeToolStripMenuItem
            // 
            this.MaxNhanXeToolStripMenuItem.Name = "MaxNhanXeToolStripMenuItem";
            this.MaxNhanXeToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.MaxNhanXeToolStripMenuItem.Text = "Số xe nhận mỗi ngày";
            this.MaxNhanXeToolStripMenuItem.Click += new System.EventHandler(this.MaxNhanXeToolStripMenuItem_Click);
            // 
            // pnlContent
            // 
            this.pnlContent.BackColor = System.Drawing.Color.White;
            this.pnlContent.Controls.Add(this.pnlTonKho);
            this.pnlContent.Controls.Add(this.pnlThongKe);
            this.pnlContent.Controls.Add(this.pnlQuanTri);
            this.pnlContent.Controls.Add(this.pnlQuanLy);
            this.pnlContent.Controls.Add(this.mnuChinh);
            this.pnlContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContent.Location = new System.Drawing.Point(0, 0);
            this.pnlContent.Name = "pnlContent";
            this.pnlContent.Size = new System.Drawing.Size(863, 521);
            this.pnlContent.TabIndex = 2;
            // 
            // pnlTonKho
            // 
            this.pnlTonKho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(189)))), ((int)(((byte)(207)))));
            this.pnlTonKho.Controls.Add(this.btnXemTK);
            this.pnlTonKho.Controls.Add(this.btnInTK);
            this.pnlTonKho.Controls.Add(this.cboTK_Nam);
            this.pnlTonKho.Controls.Add(this.cboTK_Thang);
            this.pnlTonKho.Controls.Add(this.label65);
            this.pnlTonKho.Controls.Add(this.label66);
            this.pnlTonKho.Controls.Add(this.label67);
            this.pnlTonKho.Controls.Add(this.dgvTonKho);
            this.pnlTonKho.Controls.Add(this.label68);
            this.pnlTonKho.Controls.Add(this.label69);
            this.pnlTonKho.Location = new System.Drawing.Point(498, 35);
            this.pnlTonKho.Name = "pnlTonKho";
            this.pnlTonKho.Size = new System.Drawing.Size(189, 69);
            this.pnlTonKho.TabIndex = 13;
            // 
            // btnXemTK
            // 
            this.btnXemTK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnXemTK.Location = new System.Drawing.Point(414, 88);
            this.btnXemTK.Name = "btnXemTK";
            this.btnXemTK.Size = new System.Drawing.Size(97, 33);
            this.btnXemTK.TabIndex = 12;
            this.btnXemTK.Text = "Xem";
            this.btnXemTK.UseVisualStyleBackColor = true;
            this.btnXemTK.Click += new System.EventHandler(this.btnXemTK_Click);
            // 
            // btnInTK
            // 
            this.btnInTK.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnInTK.Location = new System.Drawing.Point(379, 437);
            this.btnInTK.Name = "btnInTK";
            this.btnInTK.Size = new System.Drawing.Size(126, 36);
            this.btnInTK.TabIndex = 10;
            this.btnInTK.Text = "In Báo cáo";
            this.btnInTK.UseVisualStyleBackColor = true;
            this.btnInTK.Click += new System.EventHandler(this.btnInTK_Click);
            // 
            // cboTK_Nam
            // 
            this.cboTK_Nam.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboTK_Nam.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboTK_Nam.FormattingEnabled = true;
            this.cboTK_Nam.Location = new System.Drawing.Point(299, 91);
            this.cboTK_Nam.Name = "cboTK_Nam";
            this.cboTK_Nam.Size = new System.Drawing.Size(74, 21);
            this.cboTK_Nam.TabIndex = 2;
            // 
            // cboTK_Thang
            // 
            this.cboTK_Thang.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboTK_Thang.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboTK_Thang.FormattingEnabled = true;
            this.cboTK_Thang.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cboTK_Thang.Location = new System.Drawing.Point(185, 91);
            this.cboTK_Thang.Name = "cboTK_Thang";
            this.cboTK_Thang.Size = new System.Drawing.Size(70, 21);
            this.cboTK_Thang.TabIndex = 1;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label65.Location = new System.Drawing.Point(259, 94);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(41, 19);
            this.label65.TabIndex = 7;
            this.label65.Text = "Năm";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label66.Location = new System.Drawing.Point(126, 94);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(51, 19);
            this.label66.TabIndex = 6;
            this.label66.Text = "Tháng";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label67.Location = new System.Drawing.Point(109, 125);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(124, 19);
            this.label67.TabIndex = 5;
            this.label67.Text = "Kết quả thống kê";
            // 
            // dgvTonKho
            // 
            this.dgvTonKho.AllowUserToAddRows = false;
            this.dgvTonKho.AllowUserToDeleteRows = false;
            this.dgvTonKho.AllowUserToOrderColumns = true;
            this.dgvTonKho.BackgroundColor = System.Drawing.Color.White;
            this.dgvTonKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTonKho.Location = new System.Drawing.Point(112, 159);
            this.dgvTonKho.MultiSelect = false;
            this.dgvTonKho.Name = "dgvTonKho";
            this.dgvTonKho.ReadOnly = true;
            this.dgvTonKho.Size = new System.Drawing.Size(637, 250);
            this.dgvTonKho.TabIndex = 3;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label68.Location = new System.Drawing.Point(109, 69);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(106, 19);
            this.label68.TabIndex = 3;
            this.label68.Text = "Chọn thời gian";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(189)))), ((int)(((byte)(207)))));
            this.label69.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label69.ForeColor = System.Drawing.Color.Green;
            this.label69.Location = new System.Drawing.Point(341, 36);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(165, 24);
            this.label69.TabIndex = 1;
            this.label69.Text = "Thống kê tồn kho";
            // 
            // pnlThongKe
            // 
            this.pnlThongKe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(189)))), ((int)(((byte)(207)))));
            this.pnlThongKe.Controls.Add(this.btnKetqua);
            this.pnlThongKe.Controls.Add(this.txtDoanhThu);
            this.pnlThongKe.Controls.Add(this.label54);
            this.pnlThongKe.Controls.Add(this.btnIn);
            this.pnlThongKe.Controls.Add(this.cboNam);
            this.pnlThongKe.Controls.Add(this.cboThang);
            this.pnlThongKe.Controls.Add(this.label53);
            this.pnlThongKe.Controls.Add(this.label52);
            this.pnlThongKe.Controls.Add(this.label50);
            this.pnlThongKe.Controls.Add(this.dgvDoanhThu);
            this.pnlThongKe.Controls.Add(this.label51);
            this.pnlThongKe.Controls.Add(this.label49);
            this.pnlThongKe.Location = new System.Drawing.Point(0, 24);
            this.pnlThongKe.Name = "pnlThongKe";
            this.pnlThongKe.Size = new System.Drawing.Size(124, 80);
            this.pnlThongKe.TabIndex = 4;
            // 
            // btnKetqua
            // 
            this.btnKetqua.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnKetqua.Location = new System.Drawing.Point(414, 88);
            this.btnKetqua.Name = "btnKetqua";
            this.btnKetqua.Size = new System.Drawing.Size(97, 33);
            this.btnKetqua.TabIndex = 12;
            this.btnKetqua.Text = "Xem";
            this.btnKetqua.UseVisualStyleBackColor = true;
            this.btnKetqua.Click += new System.EventHandler(this.btnKetqua_Click);
            // 
            // txtDoanhThu
            // 
            this.txtDoanhThu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtDoanhThu.Location = new System.Drawing.Point(618, 199);
            this.txtDoanhThu.Name = "txtDoanhThu";
            this.txtDoanhThu.Size = new System.Drawing.Size(100, 26);
            this.txtDoanhThu.TabIndex = 4;
            this.txtDoanhThu.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label54.Location = new System.Drawing.Point(615, 165);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(112, 19);
            this.label54.TabIndex = 11;
            this.label54.Text = "Tổng doanh thu";
            // 
            // btnIn
            // 
            this.btnIn.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnIn.Location = new System.Drawing.Point(385, 437);
            this.btnIn.Name = "btnIn";
            this.btnIn.Size = new System.Drawing.Size(126, 36);
            this.btnIn.TabIndex = 10;
            this.btnIn.Text = "In Báo cáo";
            this.btnIn.UseVisualStyleBackColor = true;
            this.btnIn.Click += new System.EventHandler(this.btnIn_Click);
            // 
            // cboNam
            // 
            this.cboNam.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboNam.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboNam.FormattingEnabled = true;
            this.cboNam.Location = new System.Drawing.Point(299, 91);
            this.cboNam.Name = "cboNam";
            this.cboNam.Size = new System.Drawing.Size(74, 21);
            this.cboNam.TabIndex = 2;
            // 
            // cboThang
            // 
            this.cboThang.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboThang.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboThang.FormattingEnabled = true;
            this.cboThang.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cboThang.Location = new System.Drawing.Point(185, 91);
            this.cboThang.Name = "cboThang";
            this.cboThang.Size = new System.Drawing.Size(70, 21);
            this.cboThang.TabIndex = 1;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label53.Location = new System.Drawing.Point(259, 94);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(41, 19);
            this.label53.TabIndex = 7;
            this.label53.Text = "Năm";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label52.Location = new System.Drawing.Point(126, 94);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(51, 19);
            this.label52.TabIndex = 6;
            this.label52.Text = "Tháng";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label50.Location = new System.Drawing.Point(109, 125);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(124, 19);
            this.label50.TabIndex = 5;
            this.label50.Text = "Kết quả thống kê";
            // 
            // dgvDoanhThu
            // 
            this.dgvDoanhThu.AllowUserToAddRows = false;
            this.dgvDoanhThu.AllowUserToDeleteRows = false;
            this.dgvDoanhThu.AllowUserToOrderColumns = true;
            this.dgvDoanhThu.BackgroundColor = System.Drawing.Color.White;
            this.dgvDoanhThu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoanhThu.Location = new System.Drawing.Point(112, 159);
            this.dgvDoanhThu.MultiSelect = false;
            this.dgvDoanhThu.Name = "dgvDoanhThu";
            this.dgvDoanhThu.ReadOnly = true;
            this.dgvDoanhThu.Size = new System.Drawing.Size(476, 250);
            this.dgvDoanhThu.TabIndex = 3;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label51.Location = new System.Drawing.Point(109, 69);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(106, 19);
            this.label51.TabIndex = 3;
            this.label51.Text = "Chọn thời gian";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(189)))), ((int)(((byte)(207)))));
            this.label49.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label49.ForeColor = System.Drawing.Color.Green;
            this.label49.Location = new System.Drawing.Point(341, 36);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(187, 24);
            this.label49.TabIndex = 1;
            this.label49.Text = "Thống kê doanh thu";
            // 
            // pnlQuanTri
            // 
            this.pnlQuanTri.BackColor = System.Drawing.Color.Silver;
            this.pnlQuanTri.Controls.Add(this.pnlTC_Xe);
            this.pnlQuanTri.Controls.Add(this.pnlQT_TienCong);
            this.pnlQuanTri.Controls.Add(this.pnlQT_PhuTung);
            this.pnlQuanTri.Controls.Add(this.pnlQT_Hieuxe);
            this.pnlQuanTri.Controls.Add(this.lblTCQT);
            this.pnlQuanTri.Location = new System.Drawing.Point(716, 43);
            this.pnlQuanTri.Name = "pnlQuanTri";
            this.pnlQuanTri.Size = new System.Drawing.Size(116, 125);
            this.pnlQuanTri.TabIndex = 3;
            // 
            // pnlTC_Xe
            // 
            this.pnlTC_Xe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(189)))), ((int)(((byte)(207)))));
            this.pnlTC_Xe.Controls.Add(this.txtTC_SDT);
            this.pnlTC_Xe.Controls.Add(this.txtTC_DiaChi);
            this.pnlTC_Xe.Controls.Add(this.label47);
            this.pnlTC_Xe.Controls.Add(this.label48);
            this.pnlTC_Xe.Controls.Add(this.cboTC_BienSo);
            this.pnlTC_Xe.Controls.Add(this.label43);
            this.pnlTC_Xe.Controls.Add(this.txtTC_TienNo);
            this.pnlTC_Xe.Controls.Add(this.label42);
            this.pnlTC_Xe.Controls.Add(this.txtTC_ChuXe);
            this.pnlTC_Xe.Controls.Add(this.txtTC_HieuXe);
            this.pnlTC_Xe.Controls.Add(this.txtTC_BienSo);
            this.pnlTC_Xe.Controls.Add(this.label30);
            this.pnlTC_Xe.Controls.Add(this.label37);
            this.pnlTC_Xe.Controls.Add(this.label38);
            this.pnlTC_Xe.Controls.Add(this.dgvDSXe);
            this.pnlTC_Xe.Controls.Add(this.label39);
            this.pnlTC_Xe.Controls.Add(this.label40);
            this.pnlTC_Xe.Controls.Add(this.label41);
            this.pnlTC_Xe.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.pnlTC_Xe.Location = new System.Drawing.Point(809, 82);
            this.pnlTC_Xe.Name = "pnlTC_Xe";
            this.pnlTC_Xe.Size = new System.Drawing.Size(42, 319);
            this.pnlTC_Xe.TabIndex = 4;
            // 
            // txtTC_SDT
            // 
            this.txtTC_SDT.Location = new System.Drawing.Point(637, 377);
            this.txtTC_SDT.Name = "txtTC_SDT";
            this.txtTC_SDT.ReadOnly = true;
            this.txtTC_SDT.Size = new System.Drawing.Size(132, 22);
            this.txtTC_SDT.TabIndex = 12;
            this.txtTC_SDT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTC_DiaChi
            // 
            this.txtTC_DiaChi.Location = new System.Drawing.Point(637, 319);
            this.txtTC_DiaChi.Name = "txtTC_DiaChi";
            this.txtTC_DiaChi.ReadOnly = true;
            this.txtTC_DiaChi.Size = new System.Drawing.Size(132, 22);
            this.txtTC_DiaChi.TabIndex = 11;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label47.Location = new System.Drawing.Point(634, 355);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(63, 15);
            this.label47.TabIndex = 9;
            this.label47.Text = "Điện thoại";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label48.Location = new System.Drawing.Point(634, 299);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(46, 15);
            this.label48.TabIndex = 10;
            this.label48.Text = "Địa chỉ";
            // 
            // cboTC_BienSo
            // 
            this.cboTC_BienSo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboTC_BienSo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboTC_BienSo.FormattingEnabled = true;
            this.cboTC_BienSo.Location = new System.Drawing.Point(186, 69);
            this.cboTC_BienSo.Name = "cboTC_BienSo";
            this.cboTC_BienSo.Size = new System.Drawing.Size(121, 23);
            this.cboTC_BienSo.TabIndex = 8;
            this.cboTC_BienSo.SelectedIndexChanged += new System.EventHandler(this.cboTC_BienSo_SelectedIndexChanged);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label43.Location = new System.Drawing.Point(59, 69);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(116, 22);
            this.label43.TabIndex = 6;
            this.label43.Text = "Nhập biển số";
            // 
            // txtTC_TienNo
            // 
            this.txtTC_TienNo.Location = new System.Drawing.Point(637, 438);
            this.txtTC_TienNo.Name = "txtTC_TienNo";
            this.txtTC_TienNo.ReadOnly = true;
            this.txtTC_TienNo.Size = new System.Drawing.Size(132, 22);
            this.txtTC_TienNo.TabIndex = 5;
            this.txtTC_TienNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label42.Location = new System.Drawing.Point(634, 416);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(49, 15);
            this.label42.TabIndex = 0;
            this.label42.Text = "Tiền nợ";
            // 
            // txtTC_ChuXe
            // 
            this.txtTC_ChuXe.Location = new System.Drawing.Point(637, 263);
            this.txtTC_ChuXe.Name = "txtTC_ChuXe";
            this.txtTC_ChuXe.ReadOnly = true;
            this.txtTC_ChuXe.Size = new System.Drawing.Size(132, 22);
            this.txtTC_ChuXe.TabIndex = 4;
            // 
            // txtTC_HieuXe
            // 
            this.txtTC_HieuXe.Location = new System.Drawing.Point(637, 202);
            this.txtTC_HieuXe.Name = "txtTC_HieuXe";
            this.txtTC_HieuXe.ReadOnly = true;
            this.txtTC_HieuXe.Size = new System.Drawing.Size(132, 22);
            this.txtTC_HieuXe.TabIndex = 3;
            // 
            // txtTC_BienSo
            // 
            this.txtTC_BienSo.Location = new System.Drawing.Point(637, 137);
            this.txtTC_BienSo.Name = "txtTC_BienSo";
            this.txtTC_BienSo.ReadOnly = true;
            this.txtTC_BienSo.Size = new System.Drawing.Size(132, 22);
            this.txtTC_BienSo.TabIndex = 2;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label30.Location = new System.Drawing.Point(634, 241);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(45, 15);
            this.label30.TabIndex = 0;
            this.label30.Text = "Chủ xe";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label37.Location = new System.Drawing.Point(634, 181);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(48, 15);
            this.label37.TabIndex = 0;
            this.label37.Text = "Hiệu xe";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label38.Location = new System.Drawing.Point(634, 115);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(48, 15);
            this.label38.TabIndex = 0;
            this.label38.Text = "Biển số";
            // 
            // dgvDSXe
            // 
            this.dgvDSXe.AllowUserToAddRows = false;
            this.dgvDSXe.AllowUserToResizeColumns = false;
            this.dgvDSXe.AllowUserToResizeRows = false;
            this.dgvDSXe.BackgroundColor = System.Drawing.Color.White;
            this.dgvDSXe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSXe.Location = new System.Drawing.Point(59, 143);
            this.dgvDSXe.MultiSelect = false;
            this.dgvDSXe.Name = "dgvDSXe";
            this.dgvDSXe.ReadOnly = true;
            this.dgvDSXe.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDSXe.Size = new System.Drawing.Size(533, 316);
            this.dgvDSXe.StandardTab = true;
            this.dgvDSXe.TabIndex = 1;
            this.dgvDSXe.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSXe_CellDoubleClick);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label39.Location = new System.Drawing.Point(664, 69);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(70, 22);
            this.label39.TabIndex = 0;
            this.label39.Text = "Chi tiết";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label40.Location = new System.Drawing.Point(56, 109);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(123, 22);
            this.label40.TabIndex = 0;
            this.label40.Text = "Danh sách Xe";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(189)))), ((int)(((byte)(207)))));
            this.label41.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label41.ForeColor = System.Drawing.Color.Green;
            this.label41.Location = new System.Drawing.Point(353, 20);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(128, 24);
            this.label41.TabIndex = 1;
            this.label41.Text = "Danh sách xe";
            // 
            // pnlQT_TienCong
            // 
            this.pnlQT_TienCong.BackColor = System.Drawing.Color.White;
            this.pnlQT_TienCong.Controls.Add(this.cboQT_TienCong);
            this.pnlQT_TienCong.Controls.Add(this.label44);
            this.pnlQT_TienCong.Controls.Add(this.btnTC_Xoa);
            this.pnlQT_TienCong.Controls.Add(this.btnTC_Sua);
            this.pnlQT_TienCong.Controls.Add(this.btnTC_Them);
            this.pnlQT_TienCong.Controls.Add(this.txtQT_TienCong);
            this.pnlQT_TienCong.Controls.Add(this.txtQT_TenTC);
            this.pnlQT_TienCong.Controls.Add(this.txtQT_MaTC);
            this.pnlQT_TienCong.Controls.Add(this.label31);
            this.pnlQT_TienCong.Controls.Add(this.label32);
            this.pnlQT_TienCong.Controls.Add(this.label33);
            this.pnlQT_TienCong.Controls.Add(this.dgvQT_TienCong);
            this.pnlQT_TienCong.Controls.Add(this.label34);
            this.pnlQT_TienCong.Controls.Add(this.label35);
            this.pnlQT_TienCong.Controls.Add(this.label36);
            this.pnlQT_TienCong.Location = new System.Drawing.Point(709, 82);
            this.pnlQT_TienCong.Name = "pnlQT_TienCong";
            this.pnlQT_TienCong.Size = new System.Drawing.Size(50, 319);
            this.pnlQT_TienCong.TabIndex = 3;
            // 
            // cboQT_TienCong
            // 
            this.cboQT_TienCong.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboQT_TienCong.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboQT_TienCong.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboQT_TienCong.FormattingEnabled = true;
            this.cboQT_TienCong.Location = new System.Drawing.Point(194, 65);
            this.cboQT_TienCong.Name = "cboQT_TienCong";
            this.cboQT_TienCong.Size = new System.Drawing.Size(226, 27);
            this.cboQT_TienCong.TabIndex = 9;
            this.cboQT_TienCong.SelectedIndexChanged += new System.EventHandler(this.cboQT_TienCong_SelectedIndexChanged);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label44.Location = new System.Drawing.Point(59, 69);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(126, 22);
            this.label44.TabIndex = 8;
            this.label44.Text = "Loại tiền công";
            // 
            // btnTC_Xoa
            // 
            this.btnTC_Xoa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnTC_Xoa.Location = new System.Drawing.Point(702, 319);
            this.btnTC_Xoa.Name = "btnTC_Xoa";
            this.btnTC_Xoa.Size = new System.Drawing.Size(75, 33);
            this.btnTC_Xoa.TabIndex = 7;
            this.btnTC_Xoa.Text = "Xóa";
            this.btnTC_Xoa.UseVisualStyleBackColor = true;
            this.btnTC_Xoa.Click += new System.EventHandler(this.btnTC_Xoa_Click);
            // 
            // btnTC_Sua
            // 
            this.btnTC_Sua.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnTC_Sua.Location = new System.Drawing.Point(621, 319);
            this.btnTC_Sua.Name = "btnTC_Sua";
            this.btnTC_Sua.Size = new System.Drawing.Size(75, 33);
            this.btnTC_Sua.TabIndex = 6;
            this.btnTC_Sua.Text = "Sửa";
            this.btnTC_Sua.UseVisualStyleBackColor = true;
            this.btnTC_Sua.Click += new System.EventHandler(this.btnTC_Sua_Click);
            // 
            // btnTC_Them
            // 
            this.btnTC_Them.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnTC_Them.Location = new System.Drawing.Point(535, 319);
            this.btnTC_Them.Name = "btnTC_Them";
            this.btnTC_Them.Size = new System.Drawing.Size(75, 33);
            this.btnTC_Them.TabIndex = 5;
            this.btnTC_Them.Text = "Thêm";
            this.btnTC_Them.UseVisualStyleBackColor = true;
            this.btnTC_Them.Click += new System.EventHandler(this.btnTC_Them_Click);
            // 
            // txtQT_TienCong
            // 
            this.txtQT_TienCong.Location = new System.Drawing.Point(535, 267);
            this.txtQT_TienCong.MaxLength = 10;
            this.txtQT_TienCong.Name = "txtQT_TienCong";
            this.txtQT_TienCong.Size = new System.Drawing.Size(132, 20);
            this.txtQT_TienCong.TabIndex = 4;
            this.txtQT_TienCong.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQT_TienCong.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQT_TienCong_KeyDown);
            this.txtQT_TienCong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQT_TienCong_KeyPress);
            // 
            // txtQT_TenTC
            // 
            this.txtQT_TenTC.Location = new System.Drawing.Point(535, 206);
            this.txtQT_TenTC.MaxLength = 50;
            this.txtQT_TenTC.Name = "txtQT_TenTC";
            this.txtQT_TenTC.Size = new System.Drawing.Size(132, 20);
            this.txtQT_TenTC.TabIndex = 3;
            // 
            // txtQT_MaTC
            // 
            this.txtQT_MaTC.Location = new System.Drawing.Point(535, 143);
            this.txtQT_MaTC.MaxLength = 10;
            this.txtQT_MaTC.Name = "txtQT_MaTC";
            this.txtQT_MaTC.Size = new System.Drawing.Size(132, 20);
            this.txtQT_MaTC.TabIndex = 2;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label31.Location = new System.Drawing.Point(532, 241);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(74, 19);
            this.label31.TabIndex = 0;
            this.label31.Text = "Tiền công";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label32.Location = new System.Drawing.Point(532, 181);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(99, 19);
            this.label32.TabIndex = 0;
            this.label32.Text = "Tên tiền công";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label33.Location = new System.Drawing.Point(532, 115);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(97, 19);
            this.label33.TabIndex = 0;
            this.label33.Text = "Mã tiền công";
            // 
            // dgvQT_TienCong
            // 
            this.dgvQT_TienCong.AllowUserToAddRows = false;
            this.dgvQT_TienCong.AllowUserToResizeColumns = false;
            this.dgvQT_TienCong.AllowUserToResizeRows = false;
            this.dgvQT_TienCong.BackgroundColor = System.Drawing.Color.White;
            this.dgvQT_TienCong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvQT_TienCong.Location = new System.Drawing.Point(59, 142);
            this.dgvQT_TienCong.MultiSelect = false;
            this.dgvQT_TienCong.Name = "dgvQT_TienCong";
            this.dgvQT_TienCong.ReadOnly = true;
            this.dgvQT_TienCong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQT_TienCong.Size = new System.Drawing.Size(434, 293);
            this.dgvQT_TienCong.StandardTab = true;
            this.dgvQT_TienCong.TabIndex = 1;
            this.dgvQT_TienCong.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQT_TienCong_CellDoubleClick);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label34.Location = new System.Drawing.Point(562, 69);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(169, 22);
            this.label34.TabIndex = 0;
            this.label34.Text = "Chi tiết - Chỉnh sửa";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label35.Location = new System.Drawing.Point(56, 108);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(182, 22);
            this.label35.TabIndex = 0;
            this.label35.Text = "Danh sách Tiền công";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.White;
            this.label36.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label36.ForeColor = System.Drawing.Color.Green;
            this.label36.Location = new System.Drawing.Point(290, 20);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(270, 24);
            this.label36.TabIndex = 0;
            this.label36.Text = "Quản trị hệ thống - Tiền công";
            // 
            // pnlQT_PhuTung
            // 
            this.pnlQT_PhuTung.BackColor = System.Drawing.Color.White;
            this.pnlQT_PhuTung.Controls.Add(this.cboQT_PhuTung);
            this.pnlQT_PhuTung.Controls.Add(this.label46);
            this.pnlQT_PhuTung.Controls.Add(this.btnPT_Xoa);
            this.pnlQT_PhuTung.Controls.Add(this.btnPT_Sua);
            this.pnlQT_PhuTung.Controls.Add(this.btnPT_Them);
            this.pnlQT_PhuTung.Controls.Add(this.txtPT_DonGia);
            this.pnlQT_PhuTung.Controls.Add(this.txtPT_SoLuong);
            this.pnlQT_PhuTung.Controls.Add(this.txtPT_TenPT);
            this.pnlQT_PhuTung.Controls.Add(this.txtPT_MaPT);
            this.pnlQT_PhuTung.Controls.Add(this.label18);
            this.pnlQT_PhuTung.Controls.Add(this.label17);
            this.pnlQT_PhuTung.Controls.Add(this.label16);
            this.pnlQT_PhuTung.Controls.Add(this.label15);
            this.pnlQT_PhuTung.Controls.Add(this.dgvPhuTung);
            this.pnlQT_PhuTung.Controls.Add(this.label14);
            this.pnlQT_PhuTung.Controls.Add(this.label13);
            this.pnlQT_PhuTung.Controls.Add(this.label12);
            this.pnlQT_PhuTung.Location = new System.Drawing.Point(78, 98);
            this.pnlQT_PhuTung.Name = "pnlQT_PhuTung";
            this.pnlQT_PhuTung.Size = new System.Drawing.Size(46, 334);
            this.pnlQT_PhuTung.TabIndex = 2;
            // 
            // cboQT_PhuTung
            // 
            this.cboQT_PhuTung.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboQT_PhuTung.FormattingEnabled = true;
            this.cboQT_PhuTung.Location = new System.Drawing.Point(148, 65);
            this.cboQT_PhuTung.Name = "cboQT_PhuTung";
            this.cboQT_PhuTung.Size = new System.Drawing.Size(245, 27);
            this.cboQT_PhuTung.TabIndex = 10;
            this.cboQT_PhuTung.SelectedIndexChanged += new System.EventHandler(this.cboQT_PhuTung_SelectedIndexChanged);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label46.Location = new System.Drawing.Point(56, 69);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(83, 22);
            this.label46.TabIndex = 9;
            this.label46.Text = "Phụ tùng";
            // 
            // btnPT_Xoa
            // 
            this.btnPT_Xoa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnPT_Xoa.Location = new System.Drawing.Point(702, 369);
            this.btnPT_Xoa.Name = "btnPT_Xoa";
            this.btnPT_Xoa.Size = new System.Drawing.Size(75, 32);
            this.btnPT_Xoa.TabIndex = 8;
            this.btnPT_Xoa.Text = "Xóa";
            this.btnPT_Xoa.UseVisualStyleBackColor = true;
            this.btnPT_Xoa.Click += new System.EventHandler(this.btnPT_Xoa_Click);
            // 
            // btnPT_Sua
            // 
            this.btnPT_Sua.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnPT_Sua.Location = new System.Drawing.Point(621, 369);
            this.btnPT_Sua.Name = "btnPT_Sua";
            this.btnPT_Sua.Size = new System.Drawing.Size(75, 32);
            this.btnPT_Sua.TabIndex = 7;
            this.btnPT_Sua.Text = "Sửa";
            this.btnPT_Sua.UseVisualStyleBackColor = true;
            this.btnPT_Sua.Click += new System.EventHandler(this.btnPT_Sua_Click);
            // 
            // btnPT_Them
            // 
            this.btnPT_Them.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnPT_Them.Location = new System.Drawing.Point(535, 369);
            this.btnPT_Them.Name = "btnPT_Them";
            this.btnPT_Them.Size = new System.Drawing.Size(75, 32);
            this.btnPT_Them.TabIndex = 6;
            this.btnPT_Them.Text = "Thêm";
            this.btnPT_Them.UseVisualStyleBackColor = true;
            this.btnPT_Them.Click += new System.EventHandler(this.btnPT_Them_Click);
            // 
            // txtPT_DonGia
            // 
            this.txtPT_DonGia.Location = new System.Drawing.Point(535, 319);
            this.txtPT_DonGia.MaxLength = 10;
            this.txtPT_DonGia.Name = "txtPT_DonGia";
            this.txtPT_DonGia.Size = new System.Drawing.Size(132, 20);
            this.txtPT_DonGia.TabIndex = 5;
            this.txtPT_DonGia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPT_DonGia.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPT_DonGia_KeyDown);
            this.txtPT_DonGia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPT_DonGia_KeyPress);
            // 
            // txtPT_SoLuong
            // 
            this.txtPT_SoLuong.Location = new System.Drawing.Point(535, 267);
            this.txtPT_SoLuong.MaxLength = 4;
            this.txtPT_SoLuong.Name = "txtPT_SoLuong";
            this.txtPT_SoLuong.Size = new System.Drawing.Size(132, 20);
            this.txtPT_SoLuong.TabIndex = 4;
            this.txtPT_SoLuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPT_SoLuong.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPT_SoLuong_KeyDown);
            this.txtPT_SoLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPT_SoLuong_KeyPress);
            // 
            // txtPT_TenPT
            // 
            this.txtPT_TenPT.Location = new System.Drawing.Point(535, 202);
            this.txtPT_TenPT.MaxLength = 50;
            this.txtPT_TenPT.Name = "txtPT_TenPT";
            this.txtPT_TenPT.Size = new System.Drawing.Size(132, 20);
            this.txtPT_TenPT.TabIndex = 3;
            // 
            // txtPT_MaPT
            // 
            this.txtPT_MaPT.Location = new System.Drawing.Point(535, 143);
            this.txtPT_MaPT.MaxLength = 10;
            this.txtPT_MaPT.Name = "txtPT_MaPT";
            this.txtPT_MaPT.Size = new System.Drawing.Size(132, 20);
            this.txtPT_MaPT.TabIndex = 2;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label18.Location = new System.Drawing.Point(532, 299);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 19);
            this.label18.TabIndex = 0;
            this.label18.Text = "Đơn giá";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label17.Location = new System.Drawing.Point(532, 241);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 19);
            this.label17.TabIndex = 0;
            this.label17.Text = "Số lượng";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label16.Location = new System.Drawing.Point(532, 181);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(96, 19);
            this.label16.TabIndex = 0;
            this.label16.Text = "Tên phụ tùng";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label15.Location = new System.Drawing.Point(532, 115);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(94, 19);
            this.label15.TabIndex = 0;
            this.label15.Text = "Mã phụ tùng";
            // 
            // dgvPhuTung
            // 
            this.dgvPhuTung.AllowUserToAddRows = false;
            this.dgvPhuTung.AllowUserToResizeColumns = false;
            this.dgvPhuTung.AllowUserToResizeRows = false;
            this.dgvPhuTung.BackgroundColor = System.Drawing.Color.White;
            this.dgvPhuTung.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhuTung.Location = new System.Drawing.Point(59, 136);
            this.dgvPhuTung.MultiSelect = false;
            this.dgvPhuTung.Name = "dgvPhuTung";
            this.dgvPhuTung.ReadOnly = true;
            this.dgvPhuTung.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhuTung.Size = new System.Drawing.Size(434, 316);
            this.dgvPhuTung.StandardTab = true;
            this.dgvPhuTung.TabIndex = 1;
            this.dgvPhuTung.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPhuTung_CellDoubleClick);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label14.Location = new System.Drawing.Point(562, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(169, 22);
            this.label14.TabIndex = 0;
            this.label14.Text = "Chi tiết - Chỉnh sửa";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label13.Location = new System.Drawing.Point(56, 106);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(172, 22);
            this.label13.TabIndex = 0;
            this.label13.Text = "Danh sách phụ tùng";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.ForeColor = System.Drawing.Color.Green;
            this.label12.Location = new System.Drawing.Point(290, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(264, 24);
            this.label12.TabIndex = 0;
            this.label12.Text = "Quản trị hệ thống - Phụ tùng";
            // 
            // pnlQT_Hieuxe
            // 
            this.pnlQT_Hieuxe.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlQT_Hieuxe.Controls.Add(this.cboQT_HieuXe);
            this.pnlQT_Hieuxe.Controls.Add(this.label45);
            this.pnlQT_Hieuxe.Controls.Add(this.label11);
            this.pnlQT_Hieuxe.Controls.Add(this.btnHX_Xoa);
            this.pnlQT_Hieuxe.Controls.Add(this.btnHX_Sua);
            this.pnlQT_Hieuxe.Controls.Add(this.btnHX_Them);
            this.pnlQT_Hieuxe.Controls.Add(this.txtHX_TenHX);
            this.pnlQT_Hieuxe.Controls.Add(this.txtHX_MaHX);
            this.pnlQT_Hieuxe.Controls.Add(this.label10);
            this.pnlQT_Hieuxe.Controls.Add(this.label8);
            this.pnlQT_Hieuxe.Controls.Add(this.label7);
            this.pnlQT_Hieuxe.Controls.Add(this.dgvHieuXe);
            this.pnlQT_Hieuxe.Controls.Add(this.label6);
            this.pnlQT_Hieuxe.Location = new System.Drawing.Point(15, 98);
            this.pnlQT_Hieuxe.Name = "pnlQT_Hieuxe";
            this.pnlQT_Hieuxe.Size = new System.Drawing.Size(34, 334);
            this.pnlQT_Hieuxe.TabIndex = 1;
            // 
            // cboQT_HieuXe
            // 
            this.cboQT_HieuXe.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboQT_HieuXe.FormattingEnabled = true;
            this.cboQT_HieuXe.Location = new System.Drawing.Point(167, 100);
            this.cboQT_HieuXe.Name = "cboQT_HieuXe";
            this.cboQT_HieuXe.Size = new System.Drawing.Size(223, 27);
            this.cboQT_HieuXe.TabIndex = 8;
            this.cboQT_HieuXe.SelectedIndexChanged += new System.EventHandler(this.cboQT_HieuXe_SelectedIndexChanged);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label45.Location = new System.Drawing.Point(90, 105);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(71, 22);
            this.label45.TabIndex = 7;
            this.label45.Text = "Hiệu xe";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Green;
            this.label11.Location = new System.Drawing.Point(290, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(250, 24);
            this.label11.TabIndex = 0;
            this.label11.Text = "Quản trị hệ thống - Hiệu xe";
            // 
            // btnHX_Xoa
            // 
            this.btnHX_Xoa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnHX_Xoa.Location = new System.Drawing.Point(603, 302);
            this.btnHX_Xoa.Name = "btnHX_Xoa";
            this.btnHX_Xoa.Size = new System.Drawing.Size(75, 34);
            this.btnHX_Xoa.TabIndex = 6;
            this.btnHX_Xoa.Text = "Xóa";
            this.btnHX_Xoa.UseVisualStyleBackColor = true;
            this.btnHX_Xoa.Click += new System.EventHandler(this.btnHX_Xoa_Click);
            // 
            // btnHX_Sua
            // 
            this.btnHX_Sua.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnHX_Sua.Location = new System.Drawing.Point(516, 302);
            this.btnHX_Sua.Name = "btnHX_Sua";
            this.btnHX_Sua.Size = new System.Drawing.Size(75, 34);
            this.btnHX_Sua.TabIndex = 5;
            this.btnHX_Sua.Text = "Sửa";
            this.btnHX_Sua.UseVisualStyleBackColor = true;
            this.btnHX_Sua.Click += new System.EventHandler(this.btnHX_Sua_Click);
            // 
            // btnHX_Them
            // 
            this.btnHX_Them.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnHX_Them.Location = new System.Drawing.Point(428, 302);
            this.btnHX_Them.Name = "btnHX_Them";
            this.btnHX_Them.Size = new System.Drawing.Size(75, 34);
            this.btnHX_Them.TabIndex = 4;
            this.btnHX_Them.Text = "Thêm";
            this.btnHX_Them.UseVisualStyleBackColor = true;
            this.btnHX_Them.Click += new System.EventHandler(this.btnHX_Them_Click);
            // 
            // txtHX_TenHX
            // 
            this.txtHX_TenHX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtHX_TenHX.Location = new System.Drawing.Point(428, 249);
            this.txtHX_TenHX.Name = "txtHX_TenHX";
            this.txtHX_TenHX.Size = new System.Drawing.Size(180, 26);
            this.txtHX_TenHX.TabIndex = 3;
            // 
            // txtHX_MaHX
            // 
            this.txtHX_MaHX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtHX_MaHX.Location = new System.Drawing.Point(428, 174);
            this.txtHX_MaHX.Name = "txtHX_MaHX";
            this.txtHX_MaHX.Size = new System.Drawing.Size(119, 26);
            this.txtHX_MaHX.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.Location = new System.Drawing.Point(425, 221);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 19);
            this.label10.TabIndex = 0;
            this.label10.Text = "Tên hiệu xe";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(425, 146);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "Mã hiệu xe";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.Location = new System.Drawing.Point(498, 105);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 22);
            this.label7.TabIndex = 0;
            this.label7.Text = "Quản trị";
            // 
            // dgvHieuXe
            // 
            this.dgvHieuXe.AllowUserToAddRows = false;
            this.dgvHieuXe.AllowUserToResizeColumns = false;
            this.dgvHieuXe.AllowUserToResizeRows = false;
            this.dgvHieuXe.BackgroundColor = System.Drawing.Color.White;
            this.dgvHieuXe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHieuXe.Location = new System.Drawing.Point(90, 176);
            this.dgvHieuXe.MultiSelect = false;
            this.dgvHieuXe.Name = "dgvHieuXe";
            this.dgvHieuXe.ReadOnly = true;
            this.dgvHieuXe.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHieuXe.Size = new System.Drawing.Size(300, 227);
            this.dgvHieuXe.StandardTab = true;
            this.dgvHieuXe.TabIndex = 1;
            this.dgvHieuXe.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvHieuXe_CellDoubleClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(90, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 22);
            this.label6.TabIndex = 0;
            this.label6.Text = "Danh sách hiệu xe";
            // 
            // lblTCQT
            // 
            this.lblTCQT.AutoSize = true;
            this.lblTCQT.BackColor = System.Drawing.Color.White;
            this.lblTCQT.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblTCQT.ForeColor = System.Drawing.Color.Green;
            this.lblTCQT.Location = new System.Drawing.Point(390, 20);
            this.lblTCQT.Name = "lblTCQT";
            this.lblTCQT.Size = new System.Drawing.Size(61, 24);
            this.lblTCQT.TabIndex = 0;
            this.lblTCQT.Text = "Panel";
            // 
            // pnlQuanLy
            // 
            this.pnlQuanLy.BackColor = System.Drawing.Color.Silver;
            this.pnlQuanLy.Controls.Add(this.pnlPhieuThuTien);
            this.pnlQuanLy.Controls.Add(this.pnlPhieuSua);
            this.pnlQuanLy.Controls.Add(this.pnlTiepNhan);
            this.pnlQuanLy.Location = new System.Drawing.Point(0, 115);
            this.pnlQuanLy.Name = "pnlQuanLy";
            this.pnlQuanLy.Size = new System.Drawing.Size(120, 406);
            this.pnlQuanLy.TabIndex = 2;
            // 
            // pnlPhieuThuTien
            // 
            this.pnlPhieuThuTien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(189)))), ((int)(((byte)(207)))));
            this.pnlPhieuThuTien.Controls.Add(this.txtPT_DienThoai);
            this.pnlPhieuThuTien.Controls.Add(this.txtPT_NgayThu);
            this.pnlPhieuThuTien.Controls.Add(this.txtPT_SoTienThu);
            this.pnlPhieuThuTien.Controls.Add(this.txtPT_Email);
            this.pnlPhieuThuTien.Controls.Add(this.txtPT_TienNo);
            this.pnlPhieuThuTien.Controls.Add(this.txtPT_NoMoi);
            this.pnlPhieuThuTien.Controls.Add(this.txtPT_ChuXe);
            this.pnlPhieuThuTien.Controls.Add(this.cboPT_BienSo);
            this.pnlPhieuThuTien.Controls.Add(this.btnHuyThu);
            this.pnlPhieuThuTien.Controls.Add(this.btnThuTien);
            this.pnlPhieuThuTien.Controls.Add(this.label63);
            this.pnlPhieuThuTien.Controls.Add(this.label62);
            this.pnlPhieuThuTien.Controls.Add(this.label61);
            this.pnlPhieuThuTien.Controls.Add(this.label60);
            this.pnlPhieuThuTien.Controls.Add(this.label59);
            this.pnlPhieuThuTien.Controls.Add(this.label58);
            this.pnlPhieuThuTien.Controls.Add(this.label57);
            this.pnlPhieuThuTien.Controls.Add(this.label56);
            this.pnlPhieuThuTien.Controls.Add(this.label55);
            this.pnlPhieuThuTien.Location = new System.Drawing.Point(130, 95);
            this.pnlPhieuThuTien.Name = "pnlPhieuThuTien";
            this.pnlPhieuThuTien.Size = new System.Drawing.Size(41, 343);
            this.pnlPhieuThuTien.TabIndex = 18;
            // 
            // txtPT_DienThoai
            // 
            this.txtPT_DienThoai.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtPT_DienThoai.Location = new System.Drawing.Point(207, 173);
            this.txtPT_DienThoai.Name = "txtPT_DienThoai";
            this.txtPT_DienThoai.ReadOnly = true;
            this.txtPT_DienThoai.Size = new System.Drawing.Size(113, 26);
            this.txtPT_DienThoai.TabIndex = 3;
            this.txtPT_DienThoai.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtPT_NgayThu
            // 
            this.txtPT_NgayThu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtPT_NgayThu.Location = new System.Drawing.Point(207, 211);
            this.txtPT_NgayThu.Name = "txtPT_NgayThu";
            this.txtPT_NgayThu.ReadOnly = true;
            this.txtPT_NgayThu.Size = new System.Drawing.Size(113, 26);
            this.txtPT_NgayThu.TabIndex = 5;
            // 
            // txtPT_SoTienThu
            // 
            this.txtPT_SoTienThu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtPT_SoTienThu.Location = new System.Drawing.Point(207, 251);
            this.txtPT_SoTienThu.Name = "txtPT_SoTienThu";
            this.txtPT_SoTienThu.Size = new System.Drawing.Size(113, 26);
            this.txtPT_SoTienThu.TabIndex = 7;
            this.txtPT_SoTienThu.Text = "0";
            this.txtPT_SoTienThu.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPT_SoTienThu.TextChanged += new System.EventHandler(this.txtPT_SoTienThu_TextChanged);
            this.txtPT_SoTienThu.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPT_SoTienThu_KeyDown);
            this.txtPT_SoTienThu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPT_SoTienThu_KeyPress);
            // 
            // txtPT_Email
            // 
            this.txtPT_Email.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtPT_Email.Location = new System.Drawing.Point(547, 172);
            this.txtPT_Email.Name = "txtPT_Email";
            this.txtPT_Email.Size = new System.Drawing.Size(196, 26);
            this.txtPT_Email.TabIndex = 4;
            // 
            // txtPT_TienNo
            // 
            this.txtPT_TienNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtPT_TienNo.Location = new System.Drawing.Point(547, 213);
            this.txtPT_TienNo.Name = "txtPT_TienNo";
            this.txtPT_TienNo.ReadOnly = true;
            this.txtPT_TienNo.Size = new System.Drawing.Size(121, 26);
            this.txtPT_TienNo.TabIndex = 6;
            this.txtPT_TienNo.Text = "0";
            this.txtPT_TienNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtPT_NoMoi
            // 
            this.txtPT_NoMoi.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtPT_NoMoi.Location = new System.Drawing.Point(547, 251);
            this.txtPT_NoMoi.Name = "txtPT_NoMoi";
            this.txtPT_NoMoi.ReadOnly = true;
            this.txtPT_NoMoi.Size = new System.Drawing.Size(121, 26);
            this.txtPT_NoMoi.TabIndex = 8;
            this.txtPT_NoMoi.Text = "0";
            this.txtPT_NoMoi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtPT_ChuXe
            // 
            this.txtPT_ChuXe.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtPT_ChuXe.Location = new System.Drawing.Point(207, 135);
            this.txtPT_ChuXe.Name = "txtPT_ChuXe";
            this.txtPT_ChuXe.ReadOnly = true;
            this.txtPT_ChuXe.Size = new System.Drawing.Size(198, 26);
            this.txtPT_ChuXe.TabIndex = 1;
            // 
            // cboPT_BienSo
            // 
            this.cboPT_BienSo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboPT_BienSo.FormattingEnabled = true;
            this.cboPT_BienSo.Location = new System.Drawing.Point(547, 129);
            this.cboPT_BienSo.Name = "cboPT_BienSo";
            this.cboPT_BienSo.Size = new System.Drawing.Size(121, 27);
            this.cboPT_BienSo.TabIndex = 2;
            this.cboPT_BienSo.SelectedIndexChanged += new System.EventHandler(this.cboPT_BienSo_SelectedIndexChanged);
            // 
            // btnHuyThu
            // 
            this.btnHuyThu.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnHuyThu.Location = new System.Drawing.Point(478, 317);
            this.btnHuyThu.Name = "btnHuyThu";
            this.btnHuyThu.Size = new System.Drawing.Size(134, 39);
            this.btnHuyThu.TabIndex = 10;
            this.btnHuyThu.Text = "Hủy";
            this.btnHuyThu.UseVisualStyleBackColor = true;
            this.btnHuyThu.Click += new System.EventHandler(this.btnHuyThu_Click);
            // 
            // btnThuTien
            // 
            this.btnThuTien.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnThuTien.Location = new System.Drawing.Point(238, 317);
            this.btnThuTien.Name = "btnThuTien";
            this.btnThuTien.Size = new System.Drawing.Size(138, 39);
            this.btnThuTien.TabIndex = 9;
            this.btnThuTien.Text = "Thanh Toán";
            this.btnThuTien.UseVisualStyleBackColor = true;
            this.btnThuTien.Click += new System.EventHandler(this.btnThuTien_Click);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label63.Location = new System.Drawing.Point(456, 254);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(87, 19);
            this.label63.TabIndex = 9;
            this.label63.Text = "Tiền còn nợ";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label62.Location = new System.Drawing.Point(120, 254);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(80, 19);
            this.label62.TabIndex = 8;
            this.label62.Text = "Số tiền thu";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label61.Location = new System.Drawing.Point(456, 214);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(76, 19);
            this.label61.TabIndex = 7;
            this.label61.Text = "Số tiền nợ";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label60.Location = new System.Drawing.Point(120, 214);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(70, 19);
            this.label60.TabIndex = 6;
            this.label60.Text = "Ngày thu";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label59.Location = new System.Drawing.Point(457, 176);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(47, 19);
            this.label59.TabIndex = 5;
            this.label59.Text = "Email";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label58.Location = new System.Drawing.Point(120, 176);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(78, 19);
            this.label58.TabIndex = 4;
            this.label58.Text = "Điện thoại";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label57.Location = new System.Drawing.Point(456, 138);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(59, 19);
            this.label57.TabIndex = 3;
            this.label57.Text = "Biển số";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label56.Location = new System.Drawing.Point(120, 138);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(56, 19);
            this.label56.TabIndex = 2;
            this.label56.Text = "Chủ xe";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label55.Location = new System.Drawing.Point(345, 48);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(156, 26);
            this.label55.TabIndex = 1;
            this.label55.Text = "Phiếu thu tiền";
            // 
            // pnlPhieuSua
            // 
            this.pnlPhieuSua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(189)))), ((int)(((byte)(207)))));
            this.pnlPhieuSua.Controls.Add(this.cboPhieuSua_BienSo);
            this.pnlPhieuSua.Controls.Add(this.btnAdd);
            this.pnlPhieuSua.Controls.Add(this.btnHTvsTT);
            this.pnlPhieuSua.Controls.Add(this.txtThanhToan);
            this.pnlPhieuSua.Controls.Add(this.label29);
            this.pnlPhieuSua.Controls.Add(this.dgvChiTietPhieuSua);
            this.pnlPhieuSua.Controls.Add(this.label28);
            this.pnlPhieuSua.Controls.Add(this.flowLayoutPanel1);
            this.pnlPhieuSua.Controls.Add(this.txtDonGia);
            this.pnlPhieuSua.Controls.Add(this.txtTienCong);
            this.pnlPhieuSua.Controls.Add(this.cboPhieuSua_PhuTung);
            this.pnlPhieuSua.Controls.Add(this.cboPhieuSua_NoiDung);
            this.pnlPhieuSua.Controls.Add(this.txtThanhTien);
            this.pnlPhieuSua.Controls.Add(this.txtSoLuong);
            this.pnlPhieuSua.Controls.Add(this.txtPhieuSua_NgayNhan);
            this.pnlPhieuSua.Controls.Add(this.label19);
            this.pnlPhieuSua.Controls.Add(this.label20);
            this.pnlPhieuSua.Controls.Add(this.label21);
            this.pnlPhieuSua.Controls.Add(this.label22);
            this.pnlPhieuSua.Controls.Add(this.label23);
            this.pnlPhieuSua.Controls.Add(this.label24);
            this.pnlPhieuSua.Controls.Add(this.label25);
            this.pnlPhieuSua.Controls.Add(this.label26);
            this.pnlPhieuSua.Controls.Add(this.label27);
            this.pnlPhieuSua.Location = new System.Drawing.Point(12, 95);
            this.pnlPhieuSua.Name = "pnlPhieuSua";
            this.pnlPhieuSua.Size = new System.Drawing.Size(41, 343);
            this.pnlPhieuSua.TabIndex = 17;
            // 
            // cboPhieuSua_BienSo
            // 
            this.cboPhieuSua_BienSo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cboPhieuSua_BienSo.FormattingEnabled = true;
            this.cboPhieuSua_BienSo.Location = new System.Drawing.Point(199, 56);
            this.cboPhieuSua_BienSo.Name = "cboPhieuSua_BienSo";
            this.cboPhieuSua_BienSo.Size = new System.Drawing.Size(132, 27);
            this.cboPhieuSua_BienSo.TabIndex = 24;
            this.cboPhieuSua_BienSo.SelectedIndexChanged += new System.EventHandler(this.cboPhieuSua_BienSo_SelectedIndexChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnAdd.Location = new System.Drawing.Point(679, 153);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 25);
            this.btnAdd.TabIndex = 23;
            this.btnAdd.Text = "Thêm";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnHTvsTT
            // 
            this.btnHTvsTT.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnHTvsTT.Location = new System.Drawing.Point(392, 446);
            this.btnHTvsTT.Name = "btnHTvsTT";
            this.btnHTvsTT.Size = new System.Drawing.Size(115, 31);
            this.btnHTvsTT.TabIndex = 22;
            this.btnHTvsTT.Text = "Hoàn tất";
            this.btnHTvsTT.UseVisualStyleBackColor = true;
            this.btnHTvsTT.Click += new System.EventHandler(this.btnHTvsTT_Click);
            // 
            // txtThanhToan
            // 
            this.txtThanhToan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtThanhToan.Location = new System.Drawing.Point(199, 408);
            this.txtThanhToan.Name = "txtThanhToan";
            this.txtThanhToan.ReadOnly = true;
            this.txtThanhToan.Size = new System.Drawing.Size(165, 26);
            this.txtThanhToan.TabIndex = 9;
            this.txtThanhToan.Text = "0";
            this.txtThanhToan.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label29.Location = new System.Drawing.Point(116, 414);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(72, 19);
            this.label29.TabIndex = 0;
            this.label29.Text = "Tổng tiền";
            // 
            // dgvChiTietPhieuSua
            // 
            this.dgvChiTietPhieuSua.AllowUserToAddRows = false;
            this.dgvChiTietPhieuSua.AllowUserToResizeColumns = false;
            this.dgvChiTietPhieuSua.AllowUserToResizeRows = false;
            this.dgvChiTietPhieuSua.BackgroundColor = System.Drawing.Color.White;
            this.dgvChiTietPhieuSua.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPhieuSua.Location = new System.Drawing.Point(118, 207);
            this.dgvChiTietPhieuSua.Name = "dgvChiTietPhieuSua";
            this.dgvChiTietPhieuSua.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChiTietPhieuSua.Size = new System.Drawing.Size(635, 191);
            this.dgvChiTietPhieuSua.TabIndex = 0;
            this.dgvChiTietPhieuSua.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvChiTietPhieuSua_CellDoubleClick);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label28.Location = new System.Drawing.Point(114, 185);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(128, 19);
            this.label28.TabIndex = 0;
            this.label28.Text = "Danh sách chi tiết";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(554, 284);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel1.TabIndex = 17;
            // 
            // txtDonGia
            // 
            this.txtDonGia.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtDonGia.Location = new System.Drawing.Point(657, 123);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.ReadOnly = true;
            this.txtDonGia.Size = new System.Drawing.Size(97, 22);
            this.txtDonGia.TabIndex = 6;
            this.txtDonGia.Text = "0";
            this.txtDonGia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTienCong
            // 
            this.txtTienCong.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtTienCong.Location = new System.Drawing.Point(199, 156);
            this.txtTienCong.Name = "txtTienCong";
            this.txtTienCong.ReadOnly = true;
            this.txtTienCong.Size = new System.Drawing.Size(132, 22);
            this.txtTienCong.TabIndex = 7;
            this.txtTienCong.Text = "0";
            this.txtTienCong.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTienCong.TextChanged += new System.EventHandler(this.txtTienCong_TextChanged);
            // 
            // cboPhieuSua_PhuTung
            // 
            this.cboPhieuSua_PhuTung.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboPhieuSua_PhuTung.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboPhieuSua_PhuTung.FormattingEnabled = true;
            this.cboPhieuSua_PhuTung.Location = new System.Drawing.Point(199, 126);
            this.cboPhieuSua_PhuTung.Name = "cboPhieuSua_PhuTung";
            this.cboPhieuSua_PhuTung.Size = new System.Drawing.Size(217, 21);
            this.cboPhieuSua_PhuTung.TabIndex = 4;
            this.cboPhieuSua_PhuTung.SelectedIndexChanged += new System.EventHandler(this.cboPhieuSua_PhuTung_SelectedIndexChanged);
            // 
            // cboPhieuSua_NoiDung
            // 
            this.cboPhieuSua_NoiDung.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboPhieuSua_NoiDung.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboPhieuSua_NoiDung.FormattingEnabled = true;
            this.cboPhieuSua_NoiDung.Location = new System.Drawing.Point(199, 95);
            this.cboPhieuSua_NoiDung.Name = "cboPhieuSua_NoiDung";
            this.cboPhieuSua_NoiDung.Size = new System.Drawing.Size(217, 21);
            this.cboPhieuSua_NoiDung.TabIndex = 3;
            this.cboPhieuSua_NoiDung.SelectedIndexChanged += new System.EventHandler(this.cboPhieuSua_NoiDung_SelectedIndexChanged);
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtThanhTien.Location = new System.Drawing.Point(500, 155);
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.ReadOnly = true;
            this.txtThanhTien.Size = new System.Drawing.Size(132, 22);
            this.txtThanhTien.TabIndex = 8;
            this.txtThanhTien.Text = "0";
            this.txtThanhTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtSoLuong.Location = new System.Drawing.Point(500, 124);
            this.txtSoLuong.MaxLength = 5;
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(85, 22);
            this.txtSoLuong.TabIndex = 5;
            this.txtSoLuong.Text = "0";
            this.txtSoLuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSoLuong.TextChanged += new System.EventHandler(this.txtSoLuong_TextChanged);
            this.txtSoLuong.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSoLuong_KeyDown);
            this.txtSoLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoLuong_KeyPress);
            // 
            // txtPhieuSua_NgayNhan
            // 
            this.txtPhieuSua_NgayNhan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtPhieuSua_NgayNhan.Location = new System.Drawing.Point(523, 57);
            this.txtPhieuSua_NgayNhan.MaxLength = 10;
            this.txtPhieuSua_NgayNhan.Name = "txtPhieuSua_NgayNhan";
            this.txtPhieuSua_NgayNhan.ReadOnly = true;
            this.txtPhieuSua_NgayNhan.Size = new System.Drawing.Size(133, 26);
            this.txtPhieuSua_NgayNhan.TabIndex = 2;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label19.Location = new System.Drawing.Point(426, 162);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 15);
            this.label19.TabIndex = 0;
            this.label19.Text = "Thành tiền";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label20.Location = new System.Drawing.Point(116, 162);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 15);
            this.label20.TabIndex = 0;
            this.label20.Text = "Tiền công";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label21.Location = new System.Drawing.Point(606, 130);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 15);
            this.label21.TabIndex = 0;
            this.label21.Text = "Đơn giá";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label22.Location = new System.Drawing.Point(426, 130);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(55, 15);
            this.label22.TabIndex = 0;
            this.label22.Text = "Số lượng";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label23.Location = new System.Drawing.Point(116, 131);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 15);
            this.label23.TabIndex = 0;
            this.label23.Text = "Phụ tùng";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label24.Location = new System.Drawing.Point(116, 98);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 15);
            this.label24.TabIndex = 0;
            this.label24.Text = "Nội dung";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(426, 63);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(81, 19);
            this.label25.TabIndex = 0;
            this.label25.Text = "Ngày nhận";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label26.Location = new System.Drawing.Point(114, 63);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(79, 19);
            this.label26.TabIndex = 0;
            this.label26.Text = "Biển số xe";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label27.ForeColor = System.Drawing.Color.Green;
            this.label27.Location = new System.Drawing.Point(334, 20);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(165, 24);
            this.label27.TabIndex = 0;
            this.label27.Text = "Chi tiết phiếu sửa";
            // 
            // pnlTiepNhan
            // 
            this.pnlTiepNhan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(189)))), ((int)(((byte)(207)))));
            this.pnlTiepNhan.Controls.Add(this.label9);
            this.pnlTiepNhan.Controls.Add(this.monthCalendar1);
            this.pnlTiepNhan.Controls.Add(this.btnTiepNhan);
            this.pnlTiepNhan.Controls.Add(this.cboListHX);
            this.pnlTiepNhan.Controls.Add(this.txtSDT);
            this.pnlTiepNhan.Controls.Add(this.txtDiaChi);
            this.pnlTiepNhan.Controls.Add(this.txtBienSo);
            this.pnlTiepNhan.Controls.Add(this.txtTenKH);
            this.pnlTiepNhan.Controls.Add(this.lblSDT);
            this.pnlTiepNhan.Controls.Add(this.lblDiaChi);
            this.pnlTiepNhan.Controls.Add(this.lblHieuXe);
            this.pnlTiepNhan.Controls.Add(this.lblBienSo);
            this.pnlTiepNhan.Controls.Add(this.lblTenKH);
            this.pnlTiepNhan.Controls.Add(this.label5);
            this.pnlTiepNhan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.pnlTiepNhan.Location = new System.Drawing.Point(59, 95);
            this.pnlTiepNhan.Name = "pnlTiepNhan";
            this.pnlTiepNhan.Size = new System.Drawing.Size(44, 343);
            this.pnlTiepNhan.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.ForeColor = System.Drawing.Color.Navy;
            this.label9.Location = new System.Drawing.Point(118, 389);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(381, 44);
            this.label9.TabIndex = 8;
            this.label9.Text = "Sau khi xe hoàn tất, chúng tôi sẽ liên hệ với Quý khách qua số điện thoại trên! C" +
    "hân thành cám ơn!";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(635, 333);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 7;
            // 
            // btnTiepNhan
            // 
            this.btnTiepNhan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnTiepNhan.Location = new System.Drawing.Point(256, 312);
            this.btnTiepNhan.Name = "btnTiepNhan";
            this.btnTiepNhan.Size = new System.Drawing.Size(75, 31);
            this.btnTiepNhan.TabIndex = 6;
            this.btnTiepNhan.Text = "Hoàn tất";
            this.btnTiepNhan.UseVisualStyleBackColor = true;
            this.btnTiepNhan.Click += new System.EventHandler(this.btnTiepNhan_Click);
            // 
            // cboListHX
            // 
            this.cboListHX.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboListHX.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboListHX.FormattingEnabled = true;
            this.cboListHX.Location = new System.Drawing.Point(256, 172);
            this.cboListHX.MaxLength = 50;
            this.cboListHX.Name = "cboListHX";
            this.cboListHX.Size = new System.Drawing.Size(157, 27);
            this.cboListHX.TabIndex = 3;
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(256, 255);
            this.txtSDT.MaxLength = 20;
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(157, 26);
            this.txtSDT.TabIndex = 5;
            this.txtSDT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSDT.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSDT_KeyDown);
            this.txtSDT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSDT_KeyPress);
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(256, 215);
            this.txtDiaChi.MaxLength = 50;
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(213, 26);
            this.txtDiaChi.TabIndex = 4;
            // 
            // txtBienSo
            // 
            this.txtBienSo.Location = new System.Drawing.Point(256, 135);
            this.txtBienSo.MaxLength = 10;
            this.txtBienSo.Name = "txtBienSo";
            this.txtBienSo.Size = new System.Drawing.Size(157, 26);
            this.txtBienSo.TabIndex = 2;
            // 
            // txtTenKH
            // 
            this.txtTenKH.Location = new System.Drawing.Point(256, 95);
            this.txtTenKH.MaxLength = 50;
            this.txtTenKH.Name = "txtTenKH";
            this.txtTenKH.Size = new System.Drawing.Size(213, 26);
            this.txtTenKH.TabIndex = 1;
            // 
            // lblSDT
            // 
            this.lblSDT.AutoSize = true;
            this.lblSDT.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblSDT.ForeColor = System.Drawing.Color.Black;
            this.lblSDT.Location = new System.Drawing.Point(118, 260);
            this.lblSDT.Name = "lblSDT";
            this.lblSDT.Size = new System.Drawing.Size(95, 19);
            this.lblSDT.TabIndex = 0;
            this.lblSDT.Text = "Số điện thoại";
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblDiaChi.ForeColor = System.Drawing.Color.Black;
            this.lblDiaChi.Location = new System.Drawing.Point(118, 220);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(56, 19);
            this.lblDiaChi.TabIndex = 0;
            this.lblDiaChi.Text = "Địa chỉ";
            // 
            // lblHieuXe
            // 
            this.lblHieuXe.AutoSize = true;
            this.lblHieuXe.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblHieuXe.ForeColor = System.Drawing.Color.Black;
            this.lblHieuXe.Location = new System.Drawing.Point(118, 180);
            this.lblHieuXe.Name = "lblHieuXe";
            this.lblHieuXe.Size = new System.Drawing.Size(61, 19);
            this.lblHieuXe.TabIndex = 0;
            this.lblHieuXe.Text = "Hiệu xe";
            // 
            // lblBienSo
            // 
            this.lblBienSo.AutoSize = true;
            this.lblBienSo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblBienSo.ForeColor = System.Drawing.Color.Black;
            this.lblBienSo.Location = new System.Drawing.Point(118, 140);
            this.lblBienSo.Name = "lblBienSo";
            this.lblBienSo.Size = new System.Drawing.Size(59, 19);
            this.lblBienSo.TabIndex = 0;
            this.lblBienSo.Text = "Biển số";
            // 
            // lblTenKH
            // 
            this.lblTenKH.AutoSize = true;
            this.lblTenKH.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblTenKH.ForeColor = System.Drawing.Color.Black;
            this.lblTenKH.Location = new System.Drawing.Point(118, 100);
            this.lblTenKH.Name = "lblTenKH";
            this.lblTenKH.Size = new System.Drawing.Size(115, 19);
            this.lblTenKH.TabIndex = 0;
            this.lblTenKH.Text = "Tên khách hàng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label5.Location = new System.Drawing.Point(350, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 26);
            this.label5.TabIndex = 0;
            this.label5.Text = "Tiếp nhận xe";
            // 
            // pnlHome
            // 
            this.pnlHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(189)))), ((int)(((byte)(207)))));
            this.pnlHome.Controls.Add(this.btnLogin);
            this.pnlHome.Controls.Add(this.txtPassword);
            this.pnlHome.Controls.Add(this.txtUsername);
            this.pnlHome.Controls.Add(this.label4);
            this.pnlHome.Controls.Add(this.label3);
            this.pnlHome.Controls.Add(this.label2);
            this.pnlHome.Controls.Add(this.label1);
            this.pnlHome.Location = new System.Drawing.Point(746, 431);
            this.pnlHome.Name = "pnlHome";
            this.pnlHome.Size = new System.Drawing.Size(117, 90);
            this.pnlHome.TabIndex = 3;
            // 
            // btnLogin
            // 
            this.btnLogin.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnLogin.Location = new System.Drawing.Point(359, 323);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(114, 37);
            this.btnLogin.TabIndex = 3;
            this.btnLogin.Text = "Đăng nhập";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtPassword.Location = new System.Drawing.Point(385, 274);
            this.txtPassword.MaxLength = 20;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(125, 26);
            this.txtPassword.TabIndex = 2;
            this.txtPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPassword_KeyDown);
            // 
            // txtUsername
            // 
            this.txtUsername.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtUsername.Location = new System.Drawing.Point(385, 225);
            this.txtUsername.MaxLength = 20;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(125, 26);
            this.txtUsername.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(266, 278);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Mật khẩu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(266, 230);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tên đăng nhập";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(236, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(328, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Vui lòng đăng nhập để vào hệ thống";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(188, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(462, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chào mừng đến với hệ thống quản lý Gara Mr.Tam";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 521);
            this.Controls.Add(this.pnlHome);
            this.Controls.Add(this.pnlContent);
            this.ForeColor = System.Drawing.Color.Black;
            this.MainMenuStrip = this.mnuChinh;
            this.Name = "frmMain";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GagaManagent";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.mnuChinh.ResumeLayout(false);
            this.mnuChinh.PerformLayout();
            this.pnlContent.ResumeLayout(false);
            this.pnlContent.PerformLayout();
            this.pnlTonKho.ResumeLayout(false);
            this.pnlTonKho.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTonKho)).EndInit();
            this.pnlThongKe.ResumeLayout(false);
            this.pnlThongKe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoanhThu)).EndInit();
            this.pnlQuanTri.ResumeLayout(false);
            this.pnlQuanTri.PerformLayout();
            this.pnlTC_Xe.ResumeLayout(false);
            this.pnlTC_Xe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSXe)).EndInit();
            this.pnlQT_TienCong.ResumeLayout(false);
            this.pnlQT_TienCong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQT_TienCong)).EndInit();
            this.pnlQT_PhuTung.ResumeLayout(false);
            this.pnlQT_PhuTung.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhuTung)).EndInit();
            this.pnlQT_Hieuxe.ResumeLayout(false);
            this.pnlQT_Hieuxe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHieuXe)).EndInit();
            this.pnlQuanLy.ResumeLayout(false);
            this.pnlPhieuThuTien.ResumeLayout(false);
            this.pnlPhieuThuTien.PerformLayout();
            this.pnlPhieuSua.ResumeLayout(false);
            this.pnlPhieuSua.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPhieuSua)).EndInit();
            this.pnlTiepNhan.ResumeLayout(false);
            this.pnlTiepNhan.PerformLayout();
            this.pnlHome.ResumeLayout(false);
            this.pnlHome.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuChinh;
        private System.Windows.Forms.ToolStripMenuItem QuanLyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TiepNhanXeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PhieuSuaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TraCuuToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ThongKeToolStripMenuItem1;
        private System.Windows.Forms.Panel pnlContent;
        private System.Windows.Forms.ToolStripMenuItem DSXeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DoanhThuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TonKhoToolStripMenuItem;
        private System.Windows.Forms.Panel pnlHome;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem LogoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem QuanTriToolStripMenuItem;
        private System.Windows.Forms.Panel pnlQuanLy;
        private System.Windows.Forms.Panel pnlTiepNhan;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblBienSo;
        private System.Windows.Forms.Label lblTenKH;
        private System.Windows.Forms.Label lblHieuXe;
        private System.Windows.Forms.Label lblSDT;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtBienSo;
        private System.Windows.Forms.TextBox txtTenKH;
        private System.Windows.Forms.ComboBox cboListHX;
        private System.Windows.Forms.Button btnTiepNhan;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel pnlPhieuSua;
        private System.Windows.Forms.Button btnHTvsTT;
        private System.Windows.Forms.TextBox txtThanhToan;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DataGridView dgvChiTietPhieuSua;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.TextBox txtTienCong;
        private System.Windows.Forms.ComboBox cboPhieuSua_PhuTung;
        private System.Windows.Forms.ComboBox cboPhieuSua_NoiDung;
        private System.Windows.Forms.TextBox txtThanhTien;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.TextBox txtPhieuSua_NgayNhan;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel pnlQuanTri;
        private System.Windows.Forms.Label lblTCQT;
        private System.Windows.Forms.ToolStripMenuItem HieuXeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PhuTungToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TienCongToolStripMenuItem;
        private System.Windows.Forms.Panel pnlQT_Hieuxe;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgvHieuXe;
        private System.Windows.Forms.Button btnHX_Xoa;
        private System.Windows.Forms.Button btnHX_Sua;
        private System.Windows.Forms.Button btnHX_Them;
        private System.Windows.Forms.TextBox txtHX_TenHX;
        private System.Windows.Forms.TextBox txtHX_MaHX;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel pnlQT_PhuTung;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridView dgvPhuTung;
        private System.Windows.Forms.TextBox txtPT_DonGia;
        private System.Windows.Forms.TextBox txtPT_SoLuong;
        private System.Windows.Forms.TextBox txtPT_TenPT;
        private System.Windows.Forms.TextBox txtPT_MaPT;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnPT_Xoa;
        private System.Windows.Forms.Button btnPT_Sua;
        private System.Windows.Forms.Button btnPT_Them;
        private System.Windows.Forms.Panel pnlQT_TienCong;
        private System.Windows.Forms.Button btnTC_Xoa;
        private System.Windows.Forms.Button btnTC_Sua;
        private System.Windows.Forms.Button btnTC_Them;
        private System.Windows.Forms.TextBox txtQT_TienCong;
        private System.Windows.Forms.TextBox txtQT_TenTC;
        private System.Windows.Forms.TextBox txtQT_MaTC;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DataGridView dgvQT_TienCong;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel pnlTC_Xe;
        private System.Windows.Forms.TextBox txtTC_TienNo;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtTC_ChuXe;
        private System.Windows.Forms.TextBox txtTC_HieuXe;
        private System.Windows.Forms.TextBox txtTC_BienSo;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.DataGridView dgvDSXe;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox cboTC_BienSo;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox cboQT_TienCong;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox cboQT_HieuXe;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox cboQT_PhuTung;
        private System.Windows.Forms.TextBox txtTC_SDT;
        private System.Windows.Forms.TextBox txtTC_DiaChi;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ComboBox cboPhieuSua_BienSo;
        private System.Windows.Forms.Panel pnlThongKe;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.DataGridView dgvDoanhThu;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.ComboBox cboThang;
        private System.Windows.Forms.ComboBox cboNam;
        private System.Windows.Forms.Button btnIn;
        private System.Windows.Forms.TextBox txtDoanhThu;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Panel pnlPhieuThuTien;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button btnHuyThu;
        private System.Windows.Forms.Button btnThuTien;
        private System.Windows.Forms.ToolStripMenuItem PhieuThuToolStripMenuItem;
        private System.Windows.Forms.TextBox txtPT_DienThoai;
        private System.Windows.Forms.TextBox txtPT_NgayThu;
        private System.Windows.Forms.TextBox txtPT_SoTienThu;
        private System.Windows.Forms.TextBox txtPT_Email;
        private System.Windows.Forms.TextBox txtPT_TienNo;
        private System.Windows.Forms.TextBox txtPT_NoMoi;
        private System.Windows.Forms.TextBox txtPT_ChuXe;
        private System.Windows.Forms.ComboBox cboPT_BienSo;
        private System.Windows.Forms.ToolStripMenuItem MaxNhanXeToolStripMenuItem;
        private System.Windows.Forms.Button btnKetqua;
        private System.Windows.Forms.Panel pnlTonKho;
        private System.Windows.Forms.Button btnXemTK;
        private System.Windows.Forms.Button btnInTK;
        private System.Windows.Forms.ComboBox cboTK_Nam;
        private System.Windows.Forms.ComboBox cboTK_Thang;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.DataGridView dgvTonKho;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
    }
}


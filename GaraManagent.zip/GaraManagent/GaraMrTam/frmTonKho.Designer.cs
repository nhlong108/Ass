﻿namespace GaraMrTam
{
    partial class frmTonKho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrprvTonKho = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.rptTonKho1 = new GaraMrTam.rptTonKho();
            this.SuspendLayout();
            // 
            // ctrprvTonKho
            // 
            this.ctrprvTonKho.ActiveViewIndex = 0;
            this.ctrprvTonKho.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrprvTonKho.Cursor = System.Windows.Forms.Cursors.Default;
            this.ctrprvTonKho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrprvTonKho.Location = new System.Drawing.Point(0, 0);
            this.ctrprvTonKho.Name = "ctrprvTonKho";
            this.ctrprvTonKho.ReportSource = this.rptTonKho1;
            this.ctrprvTonKho.Size = new System.Drawing.Size(284, 261);
            this.ctrprvTonKho.TabIndex = 0;
            this.ctrprvTonKho.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // frmTonKho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.ctrprvTonKho);
            this.Name = "frmTonKho";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tồn kho";
            this.Load += new System.EventHandler(this.frmTonKho_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer ctrprvTonKho;
        private rptTonKho rptTonKho1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaraMrTam
{
    public partial class frmTonKho : Form
    {
        public frmTonKho()
        {
            InitializeComponent();
        }

        private void frmTonKho_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=" + Environment.MachineName + ";Initial Catalog=GaraManagent;Integrated Security=True");

            DataSet ds = new DataSet();
            SqlCommand com = new SqlCommand("PCTonKho", conn);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Clear();
            SqlDataAdapter da = new SqlDataAdapter(com);
            da.Fill(ds, "TonKho");
            ds.WriteXmlSchema(Application.StartupPath + @"\tonkho.xsd");
            rptTonKho rpt = new rptTonKho();
            rpt.SetDataSource(ds.Tables["TonKho"]);
            ctrprvTonKho.ReportSource = rpt;
            ctrprvTonKho.Refresh();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraMrTam.DataControl
{
    public class DataConnect
    {
        protected SqlConnection sql_con = new SqlConnection(@"Data Source=" + Environment.MachineName + ";Initial Catalog=GaraManagent;Integrated Security=True");
    }
}

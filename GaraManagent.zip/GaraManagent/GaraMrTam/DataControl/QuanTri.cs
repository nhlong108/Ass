﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace GaraMrTam.DataControl
{
    public class QuanTri : DataConnect
    {
        public DataTable _TB;

        #region NguoiDung

        //Lấy thông tin đăng nhập
        public DataTable IDNguoiDung(string user, string pass)
        {
            try
            {
                sql_con.Open();
                _TB = new DataTable();
                string sql = "SELECT * FROM NguoiDung WHERE Username=@user AND Password=@pass";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.CommandType = CommandType.Text;
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@user", user);
                com.Parameters.AddWithValue("@pass", pass);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (_TB != null)
                    adt.Fill(_TB);
                sql_con.Close();
                return _TB;
            }
            catch
            {
                return null;
            }
        }

        /*public DataTable ListNguoiDung()
        {
            try
            {
                sql_con.Open();
                _TB = new DataTable();
                string sql = "SELECT * FROM NguoiDung";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.CommandType = CommandType.Text;
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (_TB != null)
                    adt.Fill(_TB);
                sql_con.Close();
                return _TB;
            }
            catch
            {
                return null;
            }
        }*/

        #endregion

        #region PhuTung

        //Lấy danh sách phụ tùng
        public DataTable ListPhuTung()
        {
            try
            {
                sql_con.Open();
                _TB = new DataTable();
                string sql = "SELECT * FROM PhuTung";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (_TB != null)
                    adt.Fill(_TB);
                sql_con.Close();
                return _TB;
            }
            catch
            {
                return null;
            }
        }

        //Thêm phụ tùng
        public int insertPhuTung(string MaPT, string TenPT, int SoLuong, float DonGia)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO PhuTung VALUES(@MaPT, @TenPT, @SoLuong, @DonGia)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaPT", MaPT);
                com.Parameters.AddWithValue("@TenPT", TenPT);
                com.Parameters.AddWithValue("@SoLuong", SoLuong);
                com.Parameters.AddWithValue("@DonGia", DonGia);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Sửa phụ tùng
        public int updatePhuTung(string MaPT, string TenPT, int SoLuong, float DonGia)
        {
            try
            {
                sql_con.Open();
                string sql = "UPDATE PhuTung SET TenPhuTung=@TenPT, SoLuong=@SoLuong, DonGia=@DonGia WHERE MaPhuTung=@MaPT";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaPT", MaPT);
                com.Parameters.AddWithValue("@TenPT", TenPT);
                com.Parameters.AddWithValue("@SoLuong", SoLuong);
                com.Parameters.AddWithValue("@DonGia", DonGia);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Xóa phụ tùng
        public int deletePhuTung(string MaPT)
        {
            try
            {
                sql_con.Open();
                string sql = "DELETE FROM PhuTung WHERE MaPhuTung=@MaPT";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaPT", MaPT);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        #endregion

        #region TienCong

        //Danh sách tiền công
        public DataTable ListTienCong()
        {
            try
            {
                sql_con.Open();
                _TB = new DataTable();
                string sql = "SELECT * FROM TienCong";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (_TB != null)
                    adt.Fill(_TB);
                sql_con.Close();
                return _TB;
            }
            catch
            {
                return null;
            }
        }

        //Thêm tiền công
        public int insertTienCong(string MaCong, string TenCong, float TienCong)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO TienCong VALUES(@MaCong, @TenCong, @TienCong)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaCong", MaCong);
                com.Parameters.AddWithValue("@TenCong", TenCong);
                com.Parameters.AddWithValue("@TienCong", TienCong);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Sửa tiền công
        public int updateTienCong(string MaCong, string TenCong, float TienCong)
        {
            try
            {
                sql_con.Open();
                string sql = "UPDATE TienCong SET TenCong=@TenCong, TienCong=@TienCong WHERE MaCong=@MaCong";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaCong", MaCong);
                com.Parameters.AddWithValue("@TenCong", TenCong);
                com.Parameters.AddWithValue("@TienCong", TienCong);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Xóa tiền công
        public int deleteTienCong(string MaCong)
        {
            try
            {
                sql_con.Open();
                string sql = "DELETE FROM TienCong WHERE MaCong=@MaCong";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaCong", MaCong);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        #endregion

        #region HieuXe

        //Danh sách hiệu xe
        public DataTable ListHieuXe()
        {
            try
            {
                sql_con.Open();
                _TB = new DataTable();
                string sql = "SELECT * FROM HieuXe";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (_TB != null)
                    adt.Fill(_TB);
                sql_con.Close();
                return _TB;
            }
            catch
            {
                return null;
            }
        }

        //Thêm hiệu xe
        public int insertHieuXe(string MaHieuXe, string TenHieuXe)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO HieuXe VALUES(@MaHieuXe, @TenHieuXe)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaHieuXe", MaHieuXe);
                com.Parameters.AddWithValue("@TenHieuXe", TenHieuXe);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Sửa hiệu xe
        public int updateHieuXe(string MaHieuXe, string TenHieuXe)
        {
            try
            {
                sql_con.Open();
                string sql = "UPDATE HieuXe SET TenHieuXe=@TenHieuXe WHERE MaHieuXe=@MaHieuXe";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaHieuXe", MaHieuXe);
                com.Parameters.AddWithValue("@TenHieuXe", TenHieuXe);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Xóa hiệu xe
        public int deleteHieuXe(string MaHieuXe)
        {
            try
            {
                sql_con.Open();
                string sql = "DELETE FROM HieuXe WHERE MaHieuXe=@MaHieuXe";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaHieuXe", MaHieuXe);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        #endregion

        #region Thống kê

        //Lấy danh sách doanh thu hiển thị ra DGV
        public DataTable DoanhThu(DateTime start, DateTime end)
        {
            try
            {
                sql_con.Open();
                _TB = new DataTable();
                string sql = @"SELECT hx1.TenHieuXe, ISNULL(nt1.SoLuotSua, 0), ISNULL(nt1.TongTien, 0) FROM (SELECT nt.MaHieuXe, count(MaHieuXe) as 'SoLuotSua', sum(TongTien) as 'TongTien'
                    FROM (SELECT hx.MaHieuXe, hx.TenHieuXe, ps.TongTien FROM PhieuSua ps, HieuXe hx, DanhSachXe dsx, PhieuNhan pn 
				WHERE ps.MaPhieuNhan=pn.MaPhieuNhan AND pn.BienSo=dsx.BienSo AND dsx.MaHieuXe=hx.MaHieuXe AND ps.NgaySua>=@start AND NgaySua<@end) nt GROUP BY nt.MaHieuXe) nt1 
                        FULL OUTER JOIN HieuXe hx1 ON hx1.MaHieuXe=nt1.MaHieuXe";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("start", start);
                com.Parameters.AddWithValue("end", end);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (_TB != null)
                    adt.Fill(_TB);
                sql_con.Close();
                return _TB;
            }
            catch
            {
                return null;
            }
        }

        //Ghi doanh thu vào bảng doanh thu
        public int insertDoanhThu(int Thang, int Nam, string HieuXe, int LuotSua, float TongTien, float Tile)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO DoanhThu VALUES(@Thang, @Nam, @HieuXe, @LuotSua, @TongTien, @Tile)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@Thang", Thang);
                com.Parameters.AddWithValue("@Nam", Nam);
                com.Parameters.AddWithValue("@HieuXe", HieuXe);
                com.Parameters.AddWithValue("@LuotSua", LuotSua);
                com.Parameters.AddWithValue("@TongTien", TongTien);
                com.Parameters.AddWithValue("@Tile", Tile);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Xóa bảng doanh thu
        public int resetDoanhThu()
        {
            try
            {
                sql_con.Open();
                string sql = "DELETE FROM DoanhThu";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Lấy danh sách phụ tùng tồn kho hiển thị ra DGV
        public DataTable TonKho(DateTime start, DateTime end)
        {
            try
            {
                sql_con.Open();
                _TB = new DataTable();
                string sql = @"SELECT pt1.MaPhuTung, pt1.TenPhuTung, pt1.SoLuong, ISNULL(ctpt.SoLuong, 0) as 'PhatSinh' 
                                FROM (SELECT pt.MaPhuTung, SUM(ctps.SoLuong) as 'SoLuong' FROM PhieuSua ps, ChiTietPhieuSua ctps, PhuTung pt 
                                WHERE ps.MaPhieuSua=ctps.MaPhieuSua AND ps.NgaySua>=@start AND ps.NgaySua<@end AND ctps.MaPhuTung=pt.MaPhuTung GROUP BY pt.MaPhuTung) ctpt 
                                FULL OUTER JOIN PhuTung pt1 ON pt1.MaPhuTung=ctpt.MaPhuTung";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("start", start);
                com.Parameters.AddWithValue("end", end);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (_TB != null)
                    adt.Fill(_TB);
                sql_con.Close();
                return _TB;
            }
            catch
            {
                return null;
            }
        }

        //Xóa bảng tồn kho
        public int resetTonKho()
        {
            try
            {
                sql_con.Open();
                string sql = "DELETE FROM TonKho";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Ghi bảng tồn kho
        public int insertTonKho(int Thang, int Nam, string MaPhuTung, int TonDau, int PhatSinh, int TonCuoi)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO TonKho VALUES(@Thang, @Nam, @MaPhuTung, @TonDau, @PhatSinh, @TonCuoi)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@Thang", Thang);
                com.Parameters.AddWithValue("@Nam", Nam);
                com.Parameters.AddWithValue("@MaPhuTung", MaPhuTung);
                com.Parameters.AddWithValue("@TonDau", TonDau);
                com.Parameters.AddWithValue("@PhatSinh", PhatSinh);
                com.Parameters.AddWithValue("@TonCuoi", TonCuoi);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        
        #endregion

        // Sửa tham số: số xe nhận tối đa
        public int ThamSo(int SL)
        {
            try
            {
                sql_con.Open();
                string sql = "UPDATE ThamSo Set SoLuong=@SL TenThamSo='SoXeNhanToiDa'";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@SL", SL);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GaraMrTam.DataControl
{
    public class Data : DataConnect
    {
        public DataTable TABLE;

        #region TiepNhanXe
        
        //Ghi phiếu nhận
        public int insertPhieuNhan(string BienSo, DateTime NgayNhan)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO PhieuNhan VALUES(@BienSo, @NgayNhan)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@BienSo", BienSo);
                com.Parameters.AddWithValue("@NgayNhan", NgayNhan);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Kiểm tra xe có đang sửa không: trường hợp nhập sai biển số
        public DataTable KiemTraBienSo(string BienSo)
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT BienSo FROM PhieuNhan WHERE MaPhieuNhan not in (SELECT MaPhieuNhan FROM PhieuSua) AND BienSo=@BienSo";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.CommandType = CommandType.Text;
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@BienSo", BienSo);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }

        //Lấy danh sách biển số xe đang sửa
        public DataTable IDPhieuNhan()
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT * FROM PhieuNhan WHERE MaPhieuNhan not in (SELECT MaPhieuNhan FROM PhieuSua)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.CommandType = CommandType.Text;
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }

        //Lấy ngày nhận hiển thị ra textbox
        public DataTable NgayNhan(int MaPhieuNhan)
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT NgayNhan FROM PhieuNhan WHERE MaPhieuNhan=@MaPhieuNhan";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.CommandType = CommandType.Text;
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaPhieuNhan", MaPhieuNhan);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }

        //Lấy số xe đã nhận trong ngày
        public DataTable SoXeNhan(string ngaynhan)
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT count(MaPhieuNhan) FROM PhieuNhan WHERE NgayNhan>=@ngaynhan";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.CommandType = CommandType.Text;
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@ngaynhan", ngaynhan);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }

        //Lấy số xe tối đa được nhận
        public DataTable ThamSo()
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT SoLuong FROM ThamSo WHERE TenThamSo='SoXeNhanToiDa'";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.CommandType = CommandType.Text;
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }

        #endregion

        #region PhieuSua

        //Lấy mã phiếu nhận để ghi vào phiếu sửa
        public DataTable MaPhieuNhan(string BienSo)
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT MaPhieuNhan FROM PhieuNhan WHERE MaPhieuNhan not in (SELECT MaPhieuNhan FROM PhieuSua) AND BienSo=@BienSo";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.CommandType = CommandType.Text;
                com.Parameters.Clear();
                com.Parameters.AddWithValue("BienSo", BienSo);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }

        //Hàm lấy tiền công cho sự kiện cboTienCong_change
        public DataTable TienCong(string MaCong)
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT TienCong FROM TienCong WHERE MaCong=@MaCong";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaCong", MaCong);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }
        //Hàm lấy tiền công cho sự kiện cboPhuTung_change
        public DataTable GiaPhuTung(string MaPT)
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT DonGia FROM PhuTung WHERE MaPhuTung=@MaPT";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaPT", MaPT);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }
        //
        // Phiếu tạm
        //
        // Ghi thông tin vào phiếu tạm
        public int insertPhieuTam(string MaCong, string TenCong, string MaPT, string TenPT, int SL, float DonGia, float TienCong, float TienPT, float ThanhTien)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO PhieuTam VALUES(@MaCong, @TenCong, @MaPT, @TenPT, @SL, @DonGia, @TienCong, @TienPT, @ThanhTien)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaCong", MaCong);
                com.Parameters.AddWithValue("@TenCong", TenCong);
                com.Parameters.AddWithValue("@MaPT", MaPT);
                com.Parameters.AddWithValue("@TenPT", TenPT);
                com.Parameters.AddWithValue("@SL", SL);
                com.Parameters.AddWithValue("@TienCong", TienCong);
                com.Parameters.AddWithValue("@TienPT", TienPT);
                com.Parameters.AddWithValue("@DonGia", DonGia);
                com.Parameters.AddWithValue("@ThanhTien", ThanhTien);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Xóa thông tin cần trên phiếu tạm
        public int deletePhieuTam(string MaCong)
        {
            try
            {
                sql_con.Open();
                string sql = "DELETE FROM PhieuTam WHERE MaCong=@MaCong";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaCong", MaCong);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        //Sửa thông tin cần trên phiếu tạm
        public int updatePhieuTam(string MaCong, string MaPT, string TenPT, int SL, float DonGia, float TienPT, float ThanhTien)
        {
            try
            {
                sql_con.Open();
                string sql = "UPDATE PhieuTam SET MaPhuTung=@MaPT, TenPhuTung=@TenPT, SoLuong=@SL, DonGia=@DonGia, TienPhuTung=@TienPT, ThanhTien=@ThanhTien WHERE MaCong=@MaCong";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaCong", MaCong);
                com.Parameters.AddWithValue("@MaPT", MaPT);
                com.Parameters.AddWithValue("@TenPT", TenPT);
                com.Parameters.AddWithValue("@SL", SL);
                com.Parameters.AddWithValue("@TienPT", TienPT);
                com.Parameters.AddWithValue("@DonGia", DonGia);
                com.Parameters.AddWithValue("@ThanhTien", ThanhTien);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        //Xóa bảng phiếu tạm
        public int resetPhieuTam()
        {
            try
            {
                sql_con.Open();
                string sql = "DELETE FROM PhieuTam";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        //Lấy thông tin từ phiếu tạm để ghi vào phiếu sửa
        public DataTable PhieuTam()
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT * FROM PhieuTam";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }
        //lấy thông tin phiếu tạm hiển thị lên dgv
        public DataTable dgvPhieuTam()
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT TenCong, TenPhuTung, SoLuong, DonGia, TienCong, TienPhuTung, ThanhTien FROM PhieuTam";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }
        //Hàm kiểm tra nội dung đã ghi vào phiếu tạm chưa
        public DataTable IDPhieuTam(string MaCong)
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT * FROM PhieuTam WHERE MaCong=@MaCong";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaCong", MaCong);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }
        //
        //Phiếu sửa
        //
        //Lấy tổng tiền phiếu sửa
        public DataTable TongTien()
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT Sum(ThanhTien) FROM PhieuTam";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }
        //Ghi phiếu sửa
        public int insertPhieuSua(int MaPhieuNhan, string NgaySua, float TongTien)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO PhieuSua VALUES(@MaPhieuNhan, @NgaySua, @TongTien)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaPhieuNhan", MaPhieuNhan);
                com.Parameters.AddWithValue("@NgaySua", NgaySua);
                com.Parameters.AddWithValue("@TongTien", TongTien);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        //Lấy phiếu sửa mới nhất
        public DataTable IDPhieuSua()
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT Max(MaPhieuSua) FROM PhieuSua";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }
        //Ghi chi tiết phiếu sửa
        public int insertChiTietPhieuSua(int MaPhieuSua, string MaCong, string MaPhuTung, float DonGia, int SoLuong, float TienCong, float TienPhuTung, float ThanhTien)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO ChiTietPhieuSua VALUES(@MaPhieuSua, @MaCong, @MaPhuTung, @DonGia, @SoLuong, @TienCong, @TienPhuTung, @ThanhTien)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@MaPhieuSua", MaPhieuSua);
                com.Parameters.AddWithValue("@MaCong", MaCong);
                com.Parameters.AddWithValue("@MaPhuTung", MaPhuTung);
                com.Parameters.AddWithValue("@SoLuong", SoLuong);
                com.Parameters.AddWithValue("@TienCong", TienCong);
                com.Parameters.AddWithValue("@TienPhuTung", TienPhuTung);
                com.Parameters.AddWithValue("@DonGia", DonGia);
                com.Parameters.AddWithValue("@ThanhTien", ThanhTien);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        //
        //
        //
        
        #endregion

        #region DanhSachXe

        //Lấy danh sách xe
        public DataTable ListXe()
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT * FROM DanhSachXe";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }
        //Lấy thông tin xe
        public DataTable IDXe(string BienSo)
        {
            try
            {
                sql_con.Open();
                TABLE = new DataTable();
                string sql = "SELECT * FROM DanhSachXe WHERE BienSo=@BienSo";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@BienSo", BienSo);
                SqlDataAdapter adt = new SqlDataAdapter(com);
                if (TABLE != null)
                    adt.Fill(TABLE);
                sql_con.Close();
                return TABLE;
            }
            catch
            {
                return null;
            }
        }
        //Ghi xe mới
        public int insertXe(string BienSo, string ChuXe, string MaHieuXe, string DiaChi, int SDT, float TienNo)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO DanhSachXe VALUES(@BienSo, @MaHieuXe, @ChuXe, @DiaChi, @SDT, @TienNo)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@BienSo", BienSo);
                com.Parameters.AddWithValue("@MaHieuXe", MaHieuXe);
                com.Parameters.AddWithValue("@ChuXe", ChuXe);
                com.Parameters.AddWithValue("@DiaChi", DiaChi);
                com.Parameters.AddWithValue("@SDT", SDT);
                com.Parameters.AddWithValue("@TienNo", TienNo);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        //Sửa thông tin xe
        public int updateXe(string BienSo, string ChuXe, string DiaChi, int SDT)
        {
            try
            {
                sql_con.Open();
                string sql = "UPDATE DanhSachXe SET ChuXe=@ChuXe, DiaChi=@DiaChi, SDT=@SDT WHERE BienSo=@BienSo";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@BienSo", BienSo);
                com.Parameters.AddWithValue("@ChuXe", ChuXe);
                com.Parameters.AddWithValue("@DiaChi", DiaChi);
                com.Parameters.AddWithValue("@SDT", SDT);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        //Sửa tiền nợ
        public int updateTienNo(string BienSo, float TienNo) 
        {
            try
            {
                sql_con.Open();
                string sql = "UPDATE DanhSachXe SET TienNo+=@TienNo WHERE BienSo=@BienSo";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@BienSo", BienSo);
                com.Parameters.AddWithValue("@TienNo", TienNo);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        //Xóa xe
        public int deleteXe(string BienSo)
        {
            try
            {
                sql_con.Open();
                string sql = "DELETE FROM DanhSachXe WHERE BienSo=@BienSo";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@BienSo", BienSo);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        #endregion

        #region Phiếu thu tiền
        //Ghi phiếu thu tiền
        public int insertPhieuThu(string BienSo, string Email, float TienThu, string NgayLap)
        {
            try
            {
                sql_con.Open();
                string sql = "INSERT INTO PhieuThu VALUES(@BienSo, @Email, @TienThu, @NgayLap)";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@BienSo", BienSo);
                com.Parameters.AddWithValue("@Email", Email);
                com.Parameters.AddWithValue("@TienThu", TienThu);
                com.Parameters.AddWithValue("@NgayLap", NgayLap);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }

        //Cập nhật tiền nợ
        public int TienNo(string BienSo, float TienNo)
        {
            try
            {
                sql_con.Open();
                string sql = "UPDATE DanhSachXe SET TienNo=@TienNo WHERE BienSo=@BienSo";
                SqlCommand com = new SqlCommand(sql, sql_con);
                com.Parameters.Clear();
                com.Parameters.AddWithValue("@BienSo", BienSo);
                com.Parameters.AddWithValue("@TienNo", TienNo);
                com.ExecuteNonQuery();
                sql_con.Close();
                return 1;
            }
            catch
            {
                return 0;
            }
        }
        #endregion
    }
}
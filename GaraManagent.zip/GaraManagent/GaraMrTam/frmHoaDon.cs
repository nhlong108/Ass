﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaraMrTam
{
    public partial class frmHoaDon : Form
    {
        DataSet ds;
        DataControl.DataConnect con = new DataControl.DataConnect();
        public int MaHD;
        public frmHoaDon()
        {
            InitializeComponent();
        }

        private void frmHoaDon_Load(object sender, EventArgs e)
        {
            //ds = new DataSet();
            //SqlCommand com = new SqlCommand("PCHoaDon", );
            //com.CommandType = CommandType.StoredProcedure;
            //com.Parameters.Add(new SqlParameter("@MaHoaDon", MaHD));
            //SqlDataAdapter da = new SqlDataAdapter(com);
            //DataTable dt = new DataTable();
            //da.Fill(ds, "HoaDon");
            //ds.WriteXmlSchema(Application.StartupPath + @"\hoadon.xsd");

            //HoaDon obj = new HoaDon();
            //obj.SetDataSource(ds.Tables["HoaDon"]);
            //crystalReportViewer1.ReportSource = obj;
            //crystalReportViewer1.Refresh();
        }
    }
}

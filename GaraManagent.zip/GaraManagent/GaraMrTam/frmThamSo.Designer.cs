﻿namespace GaraMrTam
{
    partial class frmThamSo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtThamSo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtThamSo
            // 
            this.txtThamSo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtThamSo.Location = new System.Drawing.Point(99, 69);
            this.txtThamSo.MaxLength = 2;
            this.txtThamSo.Name = "txtThamSo";
            this.txtThamSo.Size = new System.Drawing.Size(91, 26);
            this.txtThamSo.TabIndex = 0;
            this.txtThamSo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtThamSo_KeyDown);
            this.txtThamSo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtThamSo_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(72, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Số xe tối đa được nhận";
            // 
            // frmThamSo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 137);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtThamSo);
            this.MaximizeBox = false;
            this.Name = "frmThamSo";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Số xe nhận tối đa";
            this.Load += new System.EventHandler(this.frmThamSo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtThamSo;
        private System.Windows.Forms.Label label1;
    }
}
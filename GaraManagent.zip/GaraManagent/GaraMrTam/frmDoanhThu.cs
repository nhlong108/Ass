﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaraMrTam
{
    public partial class frmDoanhThu : Form
    {
        public frmDoanhThu()
        {
            InitializeComponent();
        }

        private void frmDoanhThu_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=" + Environment.MachineName + ";Initial Catalog=GaraManagent;Integrated Security=True");

            DataSet ds = new DataSet();
            SqlCommand com = new SqlCommand("PCDoanhThu", conn);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Clear();
            SqlDataAdapter da = new SqlDataAdapter(com);
            da.Fill(ds, "DoanhThu");
            ds.WriteXmlSchema(Application.StartupPath + @"\doanhthu.xsd");
            rptDoanhThu rpt = new rptDoanhThu();
            rpt.SetDataSource(ds.Tables["DoanhThu"]);
            crystalReportViewer1.ReportSource = rpt;
            crystalReportViewer1.Refresh();
        }
    }
}

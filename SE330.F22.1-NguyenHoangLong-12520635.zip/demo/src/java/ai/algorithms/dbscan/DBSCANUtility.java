package ai.algorithms.dbscan;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;




public class DBSCANUtility {

	public static double getDistance(DBSCANPoint p, DBSCANPoint q){
		int dx = p.getX() - q.getX();
		int dy = p.getY() - q.getY();
		double distance = Math.sqrt(dx * dx + dy * dy);
		return distance;
	}
	
	public static List<DBSCANPoint> isKeyPoint(List<DBSCANPoint> lst, DBSCANPoint p, 
			int e, int minp){
		
		int count = 0;
		
		List<DBSCANPoint> tmpLst = new ArrayList<DBSCANPoint>();
		
		for(Iterator<DBSCANPoint> it = lst.iterator(); it.hasNext();){
			DBSCANPoint q = it.next();
			if(getDistance(p, q) < e){
				++count;
				if(!tmpLst.contains(q)){
					tmpLst.add(q);
				}
			}
		}		
		if(count >= minp){
			p.setKey(true);
			return tmpLst;
		}
		return null;
	}
	
	public static void setListClassed(List<DBSCANPoint> lst){
		for(Iterator<DBSCANPoint> it = lst.iterator(); it.hasNext(); ){
			DBSCANPoint p = it.next();
			if(!p.isClassed()){
				p.setClassed(true);
			}
		}
	}
	
	public static boolean mergeList(List<DBSCANPoint> a, List<DBSCANPoint> b){
		boolean merge = false;
		for(int index = 0; index < b.size(); ++index){
			if(a.contains(b.get(index))){
				merge = true;
				break;
			}
		}
		if(merge){
			for (int index = 0; index < b.size(); ++index){
				if(!a.contains(b.get(index))){
					a.add(b.get(index));
				}
			}
		}
		return merge;
	}
	
	public static List<DBSCANPoint> getPointList() throws IOException{
		List<DBSCANPoint> lst = new ArrayList<DBSCANPoint>();
		String txtPath = "points.txt";
		BufferedReader br = new BufferedReader(new FileReader(txtPath));
		String str = "";
		while ((str = br.readLine()) != null && str != ""){
			lst.add(new DBSCANPoint(str));
		}
		br.close();
		return lst;
	}
}

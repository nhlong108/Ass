package ai.algorithms.dbscan;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DBSCAN {
	
	private static List<DBSCANPoint> pointList = new ArrayList<DBSCANPoint>();
	
	private static List<List<DBSCANPoint>> resultList = new ArrayList<List<DBSCANPoint>>();
	
	private static int e = 2;
	
	private static int minp = 3;
	
	private static void display(){
		int index = 1;
		for(Iterator<List<DBSCANPoint>> it = resultList.iterator(); it.hasNext(); ){
			List<DBSCANPoint> lst = it.next();
			if(lst.isEmpty()){
				continue;
			}
			System.out.println(index);
			
			for(Iterator<DBSCANPoint> it1 = lst.iterator(); it1.hasNext(); ){
				DBSCANPoint p = it1.next();
				System.out.print(p.print());
			}
			index++;
		}
	}
	
	private static void applyDbscan(){
		try{
			pointList = DBSCANUtility.getPointList();
			for(Iterator<DBSCANPoint> it = pointList.iterator(); it.hasNext(); ){
				DBSCANPoint p = it.next();
				if(!p.isClassed()){
					List<DBSCANPoint> tmpList = new ArrayList<DBSCANPoint>();
					if((tmpList = DBSCANUtility.isKeyPoint(pointList, p, e, minp)) != null){
						DBSCANUtility.setListClassed(tmpList);
						resultList.add(tmpList);
					}
				}
			}
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	private static List<List<DBSCANPoint>> getResult(){
		applyDbscan();
		int length = resultList.size();
		for(int i = 0; i < length; ++i){
			for(int j = i + 1; j < length; ++j){
				if(DBSCANUtility.mergeList(resultList.get(i), resultList.get(j))){
					resultList.get(j).clear();
				}
			}
		}
		return resultList;
	}

	public static void main(String[] args) {
		getResult();
		display();
	}

}

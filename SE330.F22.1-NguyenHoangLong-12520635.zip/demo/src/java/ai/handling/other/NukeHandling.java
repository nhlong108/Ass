package ai.handling.other;

import java.awt.Point;
import java.util.ArrayList;

import ai.core.XVR;
import ai.handling.units.UnitsActions;
import ai.protoss.ProtossObserver;
import jnibwapi.model.Unit;
import jnibwapi.types.UnitCommandType.UnitCommandTypes;

public class NukeHandling {

	public static Point nuclearDetectionPoint = null;
	
	private static XVR xvr = XVR.getInstance();

	public static void nukeDetected(int x, int y) {		

		
		nuclearDetectionPoint = new Point(x, y);
		Point probableGhostLocation = null;
		
		ArrayList<Unit> enemyGhostsKnown = new ArrayList<Unit>();
		Unit motherfucker = null;
		for (Unit unit : xvr.getBwapi().getEnemyUnits()) {
			if (unit.getType().isGhost()) {
				enemyGhostsKnown.add(unit);
				if (unit.getLastCommandID() == UnitCommandTypes.Use_Tech_Position.ordinal()) {
					motherfucker = unit;
					System.out.println("## MOTHERFUCKER FOUND");
					break;
				}
			}
		}
		
		if (enemyGhostsKnown.isEmpty() && motherfucker == null) {
			ProtossObserver.tryToScanPoint(x, y);
			System.out.println("## HOPELESS NUKE CASE!");
		}
		else {
			if (motherfucker != null) {
				probableGhostLocation = new Point(motherfucker.getX(), motherfucker.getY());
			}
			else {
				Unit someGhost = enemyGhostsKnown.get(0);
				System.out.println("## TRYING TO GUESS THAT THIS IS: " + someGhost);
				probableGhostLocation = new Point(someGhost.getX(), someGhost.getY());
			}
			ProtossObserver.tryToScanPoint(x, y);
		}
		
		if (probableGhostLocation != null) {
			ArrayList<Unit> armyUnitsNearby = xvr.layArmyUnitsTrongBanKinh(
					probableGhostLocation.x, probableGhostLocation.y, 40, true);
			System.out.println("## ATTACKING NUKE PLACE WITH: " + armyUnitsNearby.size()
					+ " SOLDIERS!");
			for (Unit unit : armyUnitsNearby) {
				UnitsActions.tanCong(unit, probableGhostLocation.x, probableGhostLocation.y);
			}
		}
		else {
			System.out.println("## GHOST POSITION UNKNOWN");
		}
	}

}

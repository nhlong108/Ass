package ai.handling.units;

import java.util.ArrayList;

import jnibwapi.model.ChokePoint;
import jnibwapi.model.Unit;
import jnibwapi.types.UnitType;
import jnibwapi.types.TechType.TechTypes;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.army.StrengthEvaluator;
import ai.handling.army.TargetHandling;
import ai.handling.map.MapExploration;
import ai.handling.map.MapPoint;
import ai.managers.StrategyManager;
import ai.managers.UnitManager;
import ai.protoss.ProtossShieldBattery;
import ai.utils.RUtilities;

public class UnitsActions {

	private static XVR xvr = XVR.getInstance();
	
	public static void loadUnitInto(Unit unit, Unit loadTo) {
		if (unit != null && loadTo != null) {
			XVR.getInstance().getBwapi().load(unit.getID(), loadTo.getID());
		}
	}
	
	public static void diChuyen(Unit unit, Unit destination) {
		if (unit == null || destination == null) {
			return;
		}
		diChuyen(unit, destination.getX(), destination.getY());
	}

	public static void diChuyen(Unit unit, MapPoint point) {
		diChuyen(unit, point.getX(), point.getY());
	}

	public static void diChuyen(Unit unit, int x, int y) {
		XVR.getInstance().getBwapi().move(unit.getID(), x, y);
	}
	
	public static void tanCong(Unit ourUnit, MapPoint point) {
		if (ourUnit == null || point == null) {
			return;
		}
		tanCong(ourUnit, point.getX(), point.getY());
	}

	public static void tanCong(Unit ourUnit, int x, int y) {
		if (ourUnit != null) {
			xvr.getBwapi().attack(ourUnit.getID(), x, y);
		}
	}
	
	public static void tanCongUnitDich(Unit ourUnit, Unit enemy) {
		if (ourUnit != null && enemy != null && enemy.isDetected()) {
			xvr.getBwapi().attack(ourUnit.getID(), enemy.getID());
		}
	}
	
	public static void suaChua(Unit worker, Unit building) {
		if (worker != null && building != null) {
			xvr.getBwapi().repair(worker.getID(), building.getID());
		}
	}
	
	public boolean cotheTaoUnit(UnitType type) {
		return cotheTaoUnit(type.getUnitTypesObject());
	}

	public static boolean cotheTaoUnit(UnitTypes type) {
		switch (type) {
		case Protoss_Cybernetics_Core:
			return xvr.demUnitsOfType(UnitTypes.Protoss_Cybernetics_Core) > 0;
		default:
			System.out.println("Khong tao duoc unit ERROR: " + type);
			return false;
		}
	}
	
	public static void hoTro(Unit toRescue, boolean critical) {
		CallForHelp.issueCallForHelp(toRescue, critical);
	}
	
	public static void goToRandomChokePoint(Unit unit) {
		ChokePoint goTo = MapExploration.getRandomChokePoint();
		UnitsActions.diChuyen(unit, goTo.getCenterX(), goTo.getCenterY());
	}
	
	public static void diChuyenKhoiUnit(Unit unit, MapPoint placeToMoveAwayFrom,
			int howManyTiles) {
		if (unit == null || placeToMoveAwayFrom == null) {
			return;
		}

		int xDirectionToUnit = placeToMoveAwayFrom.getX() - unit.getX();
		int yDirectionToUnit = placeToMoveAwayFrom.getY() - unit.getY();

		double vectorLength = xvr.layKhoangCachGiua(placeToMoveAwayFrom, unit);
		double ratio = howManyTiles / vectorLength;

		diChuyen(unit, (int) (unit.getX() - ratio * xDirectionToUnit), (int) (unit.getY() - ratio
				* yDirectionToUnit));
	}
	
	public static void diChuyenKhoiUnitDiemTrucTiep(Unit unit,
			MapPoint pointThatMakesDirection, int howManyTiles) {
		if (unit == null || pointThatMakesDirection == null) {
			return;
		}

		int xDirectionToUnit = pointThatMakesDirection.getX() - unit.getX();
		int yDirectionToUnit = pointThatMakesDirection.getY() - unit.getY();

		double vectorLength = xvr.layKhoangCachGiua(pointThatMakesDirection, unit);
		double ratio = howManyTiles / vectorLength;

		diChuyen(unit, (int) (unit.getX() + ratio * xDirectionToUnit), (int) (unit.getY() + ratio
				* yDirectionToUnit));
	}
	
	public static boolean danTraiQuan(Unit unit) {
		return unit.isIdle() && !unit.isMoving() && !unit.isAttacking() && !unit.isUnderAttack();
	}
	
	public static void diChuyenveCanCuChinh(Unit unit) {
		Unit firstBase = xvr.layCanCuGoc();
		if (unit.isWorker()) {
			if (xvr.layKhoangCachSimple(unit, firstBase) < 8) {
				diChuyen(unit, MapExploration.getRandomChokePoint());
			} else {
				diChuyen(unit, firstBase);
			}
		} else {
			diChuyen(unit, firstBase);
		}
	}

	public static void danTraiNgauNhien(Unit unit) {
		if (!StrengthEvaluator.isStrengthRatioFavorableFor(unit)) {
			UnitsActions.diChuyenveCanCuChinh(unit);
			return;
		}

		if (!StrategyManager.isAttackPending()
				&& (xvr.coDetectorDich(unit.getX(), unit.getY()) || xvr
						.coTruMatDat(unit.getX(), unit.getY()))) {
			Unit goTo = xvr.layCanCuMoiNhat();
			UnitsActions.tanCong(unit, goTo.getX(), goTo.getY());
			return;
		}

		Unit enemyNearby = TargetHandling.getEnemyNearby(unit, 8);
		if (enemyNearby != null && unit.isWorker() && unit.getHitPoints() > 18) {
			Unit goTo = xvr.layCanCuGoc();
			UnitsActions.tanCong(unit, goTo.getX(), goTo.getY());
			return;
		}

		boolean groundAttackCapable = unit.canAttackGroundUnits();
		boolean airAttackCapable = unit.canAttackAirUnits();
		Unit importantEnemyUnit = TargetHandling.getImportantEnemyUnitTargetIfPossibleFor(unit,
				groundAttackCapable, airAttackCapable);
		if (importantEnemyUnit != null && importantEnemyUnit.isDetected()) {
			Unit goTo = importantEnemyUnit;
			UnitsActions.tanCong(unit, goTo.getX(), goTo.getY());
		}

		System.out.println("###### Dan Quan ########");
		if (!unit.isMoving() && !unit.isUnderAttack() && unit.getHitPoints() > 18) {

			MapPoint goTo = MapExploration
					.getNearestUnknownPointFor(unit.getX(), unit.getY(), true);
			if (goTo != null
					&& xvr.getBwapi().getMap()
							.isConnected(unit, goTo.getX() / 32, goTo.getY() / 32)) {
				UnitsActions.tanCong(unit, goTo.getX(), goTo.getY());
			} else {
				UnitsActions.tanCong(unit, unit.getX() + 1000 - RUtilities.rand(0, 2000),
						unit.getY() + 1000 - RUtilities.rand(0, 2000));
			}
			// }
		} else if (unit.isWorker() && unit.isUnderAttack()) {
			UnitsActions.diChuyen(unit, xvr.layCanCuGoc());
		}

		if (unit.isAttacking() && !StrengthEvaluator.isStrengthRatioFavorableFor(unit)) {
			UnitsActions.diChuyenveCanCuChinh(unit);
		}
	}
	
	public static boolean chayKhoiQuanOrTruDich(Unit unit,
			boolean tryAvoidingDetectors, boolean allowAttackingDetectorsIfSafe, boolean isAirUnit) {
		final int RUN_DISTANCE = 6;

		if (tryAvoidingDetectors) {
			boolean isEnemyDetectorNear = xvr.coDetectorDich(unit);

			if (isEnemyDetectorNear) {
				boolean canDetectorShootAtThisUnit = false;
				boolean isAttackingDetectorSafe = false;

				if (allowAttackingDetectorsIfSafe) {
					Unit enemyDetector = xvr.layDetectorDich(unit);
					if (isAirUnit) {
						canDetectorShootAtThisUnit = enemyDetector.canAttackAirUnits();
					} else {
						canDetectorShootAtThisUnit = enemyDetector.canAttackGroundUnits();
					}

					if (!canDetectorShootAtThisUnit) {
						ArrayList<Unit> enemyUnitsNearDetector = xvr.layUnitsTrongBanKinh(
								enemyDetector, 9, xvr.layArmyUnitDoiThu());
						if (enemyUnitsNearDetector.size() <= 1) {
							isAttackingDetectorSafe = true;
						}
					}
				}

				if (!allowAttackingDetectorsIfSafe || !isAttackingDetectorSafe) {

					UnitsActions.diChuyenKhoiUnit(unit,
							xvr.layDetectorDich(unit.getX(), unit.getY()), RUN_DISTANCE);
					return true;
				}
			}
		}
		boolean isEnemyBuildingNear = isAirUnit ? xvr.coTruPhongKhong(unit.getX(),
				unit.getY()) : xvr.coTruMatDat(unit.getX(), unit.getY());
		if (isEnemyBuildingNear) {
			Unit enemyBuilding = isAirUnit ? xvr.layTruPhongKhongDichThu(unit.getX(),
					unit.getY()) : xvr
					.layTruMatDatDichThu(unit.getX(), unit.getY());
			UnitsActions.diChuyenKhoiUnit(unit, enemyBuilding, RUN_DISTANCE);
			return true;
		}

		return false;
	}
	
	public static void actKhiMauVaGiapThap(Unit unit, boolean isImportantUnit) {
		UnitType type = unit.getType();
		Unit goTo = null;

		if (xvr.getTimeSecond() < 340
				&& (UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Photon_Cannon) < 2 || !XVR
						.doithuProtoss())) {
			return;
		}

		if (xvr.getTimeSecond() < 300
				&& UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Photon_Cannon) == 0) {
			return;
		}

		int currShields = unit.getShields();
		int maxShields = type.getMaxShields();
		int currHP = unit.getHitPoints();
		int maxHP = type.getMaxHitPoints();

		if (StrategyManager.isAttackPending() && currShields >= 0.13 * maxShields) {
			if (!isImportantUnit && currHP >= 0.6 * maxHP) {
				return;
			}
		}

		if (currShields >= maxShields / 2) {
			return;
		}

		if (xvr.layUnitsTrongBanKinh(UnitTypes.Terran_Bunker, 3, unit, false).size() > 0) {
			return;
		}

		if (xvr.layUnitsTrongBanKinh(UnitTypes.Protoss_Photon_Cannon, 3, unit, false).size() > 0) {
			return;
		}

		if (xvr.layUnitsTrongBanKinh(unit, 3, xvr.layUnitsOfTypeDoiThu(UnitTypes.Protoss_Archon)).size() > 0) {
			return;
		}

		if (xvr.layUnitsTrongBanKinh(UnitTypes.Zerg_Sunken_Colony, 3, unit, false).size() > 0) {
			return;
		}

		if (xvr.demLoaiUnitsTrongBanKinh(UnitManager.BASE, 13, unit, true) >= 1) {
			if (unit.getHitPoints() > (type.getMaxHitPoints() / 3 + 3)) {
				return;
			}
		}

		goTo = ProtossShieldBattery.getOneWithEnergy();
		if (goTo != null && goTo.isUnpowered()) {
			goTo = null;
		}

		if (goTo != null) {
			if (goTo.getEnergy() >= 13) {
				UnitsActions.rightClick(unit, goTo);
				return;
			}
		}
		else {
			goTo = xvr.layUnitOfTypeGanNhat(UnitTypes.Protoss_Photon_Cannon, xvr.layCanCuMoiNhat());
		}

		if (goTo == null) {
			goTo = xvr.layCanCuGoc();
		}

		if (goTo != null) {
			UnitsActions.diChuyen(unit, goTo);
		}
	}
	
	private static void rightClick(Unit unit, Unit clickTo) {
		if (unit == null || clickTo == null) {
			System.err.println("rightClick # unit: " + unit + " # clickTo: " + clickTo);
			return;
		}
		xvr.getBwapi().rightClick(unit.getID(), clickTo.getID());
	}
	
	public static void useTech(Unit wizard, TechTypes tech, Unit useOn) {
		xvr.getBwapi().useTech(wizard.getID(), tech.getID(), useOn.getID());
	}
	
}

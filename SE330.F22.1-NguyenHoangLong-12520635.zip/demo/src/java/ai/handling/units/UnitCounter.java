package ai.handling.units;

import java.util.HashMap;
import java.util.Set;

import jnibwapi.model.Unit;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;

public class UnitCounter {
	
	private static HashMap<Integer, Integer> soluongUnits = new HashMap<Integer, Integer>();
	private static XVR xvr = XVR.getInstance();
	
	public static void TinhSoLuongUnits(){
		resetUnits();
		countUnits();
	}
	
	private static void resetUnits(){
		soluongUnits.clear();
	}
	
	private static void countUnits(){
		for(Unit unit : xvr.getBwapi().getMyUnits()){
			soluongUnits.put(unit.getTypeID(), 
					(soluongUnits.containsKey(unit.getTypeID()) 
							? soluongUnits.get(unit.getTypeID()) + 1 :1));
		}
	}
	
	public static int laySoLuongUnits(UnitTypes type){
		return soluongUnits.containsKey(type.ordinal()) 
				? soluongUnits.get(type.ordinal()) : 0;
	}
	
	public static Set<Integer> layKieuUnits(){
		return soluongUnits.keySet();
	}
	
	public static int laySoLuongUnitsHoanThanh(UnitTypes type){
		int result = 0;
		for(Unit unit : xvr.layUnitsOfType(type)){
			if(unit.isCompleted()){
				result++;
			}
		}
		return result;
	}
	
	public static int laySoLuongUnitsThamChien(){
		return laySoLuongUnits(UnitTypes.Protoss_Reaver)
				+ laySoLuongUnits(UnitTypes.Protoss_Corsair)
				+ laySoLuongUnits(UnitTypes.Protoss_Scout)
				+ laySoLuongUnits(UnitTypes.Protoss_Carrier)
				+ laySoLuongUnits(UnitTypes.Protoss_Arbiter)
				+ LaySoLuongUnitsBoBinh();
		
	}
	
	public static int LaySoLuongUnitsBoBinh() {
		return laySoLuongUnits(UnitTypes.Protoss_Zealot)
				+ laySoLuongUnits(UnitTypes.Protoss_Dragoon)
				+ laySoLuongUnits(UnitTypes.Protoss_High_Templar)
				+ laySoLuongUnits(UnitTypes.Protoss_High_Templar);
	}

	public static int laySoLuongUnitsThamChienHoanThanh(){
		return laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Reaver)
				+ laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Corsair)
				+ laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Reaver)
				+ laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Carrier)
				+ laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Reaver)
				+ LaySoLuongUnitsBoBinhHoanThanh();
	}
	
	private static int LaySoLuongUnitsBoBinhHoanThanh() {
		return laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Zealot)
				+ laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Dragoon)
				+ laySoLuongUnitsHoanThanh(UnitTypes.Protoss_High_Templar)
				+ laySoLuongUnitsHoanThanh(UnitTypes.Protoss_High_Templar);
	}

	public static boolean coNha(UnitTypes unitType){
		return laySoLuongUnits(unitType) > 0;
	}
	
	public static boolean coNhaHoanThanh(UnitTypes unitType){
		return laySoLuongUnitsHoanThanh(unitType) > 0;
	}
	
	public static boolean coPylonHoanThanh(){
		return laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Pylon) > 0;
	}
	
	public static int laySoLuongPylon(){
		return laySoLuongUnits(UnitTypes.Protoss_Pylon);
	}
	
	public static int laySoLuongPylonHoanThanh(){
		return laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Pylon);
	}
	
	public static int demSoLuongKhongBinh(){
		return laySoLuongUnits(UnitTypes.Protoss_Observer)
				+ laySoLuongUnits(UnitTypes.Protoss_Arbiter)
				+ laySoLuongUnits(UnitTypes.Protoss_Carrier);
	}

}

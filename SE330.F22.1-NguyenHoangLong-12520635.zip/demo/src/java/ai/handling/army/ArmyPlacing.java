package ai.handling.army;

import jnibwapi.model.Unit;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.map.MapPoint;
import ai.handling.map.MapPointInstance;
import ai.handling.units.UnitsActions;
import ai.handling.units.UnitCounter;
import ai.managers.UnitManager;
import ai.protoss.ProtossGateway;
import ai.protoss.ProtossNexus;

public class ArmyPlacing {

	private static XVR xvr = XVR.getInstance();

	public static MapPoint getArmyGatheringPointFor(Unit unit) {
		int bases = UnitCounter.laySoLuongUnits(UnitManager.BASE);

		MapPoint runTo = null;

		if (bases == 1) {
			MapPoint base = ProtossNexus.getSecondBaseLocation();
			runTo = base;

			Unit cannon = xvr.layUnitOfTypeGanNhat(
					UnitTypes.Protoss_Photon_Cannon, base);
			if (cannon != null) {
				runTo = cannon;
			}

			Unit gateway = xvr.layUnitOfTypeGanNhat(
					UnitTypes.Protoss_Gateway, base);
			if (runTo == null && gateway != null) {
				runTo = gateway;
			}
		}

		else if (bases > 1) {

			if (xvr.demUnitsTrongBanKinh(ProtossNexus.getTileForNextBase(false),
					10, true) >= 2) {
				runTo = ProtossNexus.getTileForNextBase(false);
			} else {
				Unit baseNearestToEnemy = xvr.layCanCuGanDichNhat();
				if (baseNearestToEnemy.equals(xvr.layCanCuGoc())) {
					runTo = xvr.layCanCuMoiNhat();
				} else {
					runTo = baseNearestToEnemy;
				}
			}
		}

		if (runTo == null) {
			if (!ProtossGateway.getAllObjects().isEmpty()) {
				runTo = ProtossGateway.getAllObjects().get(0);
			}
		}

		if (runTo == null) {
			return null;
		} else {
			return new MapPointInstance(runTo.getX(), runTo.getY()).translate(-4, 0);
		}
	}

	public static void goToSafePlaceIfNotAlreadyThere(Unit unit) {

		MapPoint safePlace = getArmyGatheringPointFor(unit);

		if (xvr.layKhoangCachSimple(unit, safePlace) >= 30) {
			UnitsActions.diChuyen(unit, safePlace);
		}
		else {
			UnitsActions.tanCong(unit, safePlace);
		}
	}

	public static MapPoint getArmyCenterPoint() {
		int totalX = 0;
		int totalY = 0;
		int counter = 0;
		for (Unit unit : xvr.layUnitsNonWorker()) {
			totalX += unit.getX();
			totalY += unit.getY();
			counter++;
			if (counter > 10) {
				break;
			}
		}
		return new MapPointInstance((int) ((double) totalX / counter),
				(int) ((double) totalY / counter));
	}

}

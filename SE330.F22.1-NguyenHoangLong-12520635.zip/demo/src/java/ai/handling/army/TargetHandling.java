package ai.handling.army;

import java.util.ArrayList;
import java.util.Collection;

import jnibwapi.model.Unit;
import jnibwapi.types.UnitType;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.map.MapPoint;

public class TargetHandling {

	public static final int MAX_DIST = 50;

	private static XVR xvr = XVR.getInstance();

	public static Unit getImportantEnemyUnitTargetIfPossibleFor(MapPoint point,
			boolean includeGroundUnits, boolean includeAirUnits) {
		Collection<Unit> enemyUnits = xvr.layCongTrinhDoiThu();
		
		for (Unit unit : enemyUnits) {
			UnitType type = unit.getType();

			if (type.isFlyer() && !includeAirUnits) {
				continue;
			}
			if (!type.isFlyer() && !includeGroundUnits) {
				continue;
			}

			if (unit.isExists()
					&& unit.getHitPoints() > 0
					&& (type.isFleetBeacon() || type.isTerranMine()
							|| (unit.isRepairing() && type.isSCV())
							|| type.isLurker() || type.isObserver()
							|| type.isScienceVessel() || type.isTank()
							|| type.isReaver() || type.isHighTemplar() || (type
							.isDarkTemplar() && unit.isDetected()))
					&& xvr.layKhoangCachGiua(unit, point) <= MAX_DIST) {
				if (isProperTarget(unit)) {
					return unit;
				}
			}
		}

		return null;
	}

	public static Unit findTopPriorityTargetIfPossible(
			Collection<Unit> enemyBuildings) {
		for (Unit unit : enemyBuildings) {
			UnitType type = unit.getType();
			if (type.isBunker() || type.isCarrier() || type.isPhotonCannon()
					|| type.isObserver() || type.isScienceVessel()
					|| type.isSunkenColony()) {
				if (isProperTarget(unit)) {
					return unit;
				}
			}
			if (unit.isRepairing() && isProperTarget(unit)) {
				return unit;
			}
		}
		return null;
	}

	public static boolean isProperTarget(Unit target) {
		if (target == null) {
			return false;
		}
		
		if (!target.isDetected()) {
			return false;
		}

		boolean isProper;
		UnitType type = target.getType();

		if (type.isOnGeyser() || target.isStasised()) {
			return false;
		}

		if (type.isBuilding()) {
			isProper = target.isExists() || !target.isVisible();
		} else {
			if ((target.isHidden() || !target.isDetected())) {
				return false;
			}

			isProper = target.isExists() || !target.isVisible();

			if (isProper && (target.isHidden() || !target.isDetected())) {
				return false;
			}
		}

		return isProper;
	}

	public static Unit findHighPriorityTargetIfPossible(
			Collection<Unit> enemyBuildings) {
		for (Unit unit : enemyBuildings) {
			UnitType type = unit.getType();
			if (type.isSporeColony() || type.isMissileTurret() || type.isBase()) {
				if (isProperTarget(unit)) {
					return unit;
				}
			}
		}
		return null;
	}

	public static Unit findNormalPriorityTargetIfPossible(
			Collection<Unit> enemyBuildings) {
		for (Unit unit : enemyBuildings) {
			UnitType type = unit.getType();
			if (!type.isOnGeyser()) {
				if (isProperTarget(unit)) {
					return unit;
				}
			}
		}
		return null;
	}

	public static Unit getEnemyNearby(Unit unit, int maxTileDistance) {
		Unit nearestEnemy = xvr.layUnitGanNhatTuList(unit.getX(),
				unit.getY(), xvr.layUnitsDoiThuVisible());
		if (nearestEnemy != null
				&& xvr.layKhoangCachGiua(unit, nearestEnemy) < maxTileDistance) {
			return nearestEnemy;
		} else {
			return null;
		}
	}

	public static ArrayList<Unit> getTopPriorityTargetsNear(MapPoint near,
			int tileRadius) {
		return xvr.layUnitsTrongBanKinh(near, tileRadius, xvr.layUnitsOfTypeDoiThu(
				UnitTypes.Protoss_Carrier, UnitTypes.Terran_Battlecruiser,
				UnitTypes.Terran_Siege_Tank_Siege_Mode,
				UnitTypes.Terran_Bunker, UnitTypes.Terran_Siege_Tank_Tank_Mode,
				UnitTypes.Zerg_Guardian, UnitTypes.Zerg_Lurker,
				UnitTypes.Zerg_Sunken_Colony, UnitTypes.Zerg_Ultralisk,
				UnitTypes.Protoss_Observer));
	}

}

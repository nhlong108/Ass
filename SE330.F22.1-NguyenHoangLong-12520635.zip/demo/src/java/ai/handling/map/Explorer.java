package ai.handling.map;

import java.util.ArrayList;

import jnibwapi.model.BaseLocation;
import jnibwapi.model.Unit;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.units.UnitsActions;
import ai.handling.units.UnitCounter;
import ai.managers.WorkerManager;
import ai.protoss.ProtossNexus;
import ai.utils.RUtilities;

public class Explorer {

	private static Unit explorer;
	private static XVR xvr = XVR.getInstance();

	public static Unit getExplorer() {
		return explorer;
	}

	private static boolean _exploredSecondBase = false;
	private static boolean _exploredBackOfMainBase = false;
	private static boolean _isDiscoveringEnemyBase = false;

	public static void explore(Unit explorer) {
		if (!explorer.isCompleted()) {
			return;
		}
		Explorer.explorer = explorer;

		if (_isDiscoveringEnemyBase && explorer.isUnderAttack() && explorer.getShields() < 14) {
			if (xvr.layCongTrinhDoiThu().size() > 0) {
				_isDiscoveringEnemyBase = false;
			}
		}

		boolean isWounded = isExplorerWounded();
		double distToEnemy = getDistanceToNearestEnemy();

		boolean shouldBeConstructing = explorer.isConstructing();
		boolean shouldContinueAttacking = explorer.isAttacking() && !isWounded;
		boolean shouldBeDiscovering = _isDiscoveringEnemyBase || !_exploredBackOfMainBase
				|| !_exploredSecondBase || MapExploration.enemyBuildingsDiscovered.isEmpty();
		boolean isEnemyClose = distToEnemy > 0 && distToEnemy < 3;
		boolean shouldBeMoving = explorer.isMoving() && isEnemyClose;
		if (!explorer.isIdle()
				&& (shouldBeDiscovering || shouldBeMoving || shouldBeConstructing || shouldContinueAttacking)) {
			return;
		}


		if (tryRunningFromEnemiesIfNecessary()) {
			return;
		}


		if (tryScoutingNextBaseLocation()) {
			return;
		}

		if (tryDiscoveringEnemyBaseLocation()) {
			return;
		}
		
		if (tryAttackingEnemyIfPossible()) {
			return;
		}


		gatherResourcesIfIdle();
	}

	private static void gatherResourcesIfIdle() {
		if (explorer.isIdle()) {
			WorkerManager.gatherResources(explorer, xvr.layCanCuGoc());
		}
	}

	private static double getDistanceToNearestEnemy() {
		Unit nearestEnemy = xvr.layUnitGanNhatTuList(explorer.getX(), explorer.getY(),
				xvr.layUnitsDoiThuVisible());
		return explorer.distanceTo(nearestEnemy);
	}

	private static boolean isExplorerWounded() {
		return (explorer.getShields()) < 16
				|| (explorer.getShields() < 20 && (explorer.getShields() + explorer.getHitPoints() < 30));
	}

	private static boolean tryRunningFromEnemiesIfNecessary() {
		boolean isWounded = isExplorerWounded();

		Unit nearestEnemy = xvr.layUnitGanNhatTuList(explorer.getX(), explorer.getY(),
				xvr.layUnitsDoiThuVisible());
		double distToNearestEnemy = explorer.distanceTo(nearestEnemy);

		boolean isUnitUnderAttack = explorer.isUnderAttack();
		boolean isEnemyArmyUnitClose = isEnemyArmyUnitCloseToExplorer();
		boolean isEnemyCloseAndUnitIsWounded = distToNearestEnemy > 0 && distToNearestEnemy <= 5
				&& isWounded;
		boolean isOverwhelmed = xvr.layUnitsDichTrongBanKinh(6, explorer).size() >= 2
				&& xvr.layUnitsDichTrongBanKinh(3, explorer).size() >= 1;


		if (isOverwhelmed || isUnitUnderAttack || isEnemyArmyUnitClose
				|| isEnemyCloseAndUnitIsWounded) {
			double distToMainBase = explorer.distanceTo(xvr.layCanCuGoc());

			if (distToMainBase < 13) {
				UnitsActions.diChuyen(explorer, MapExploration.getMostDistantBaseLocation(explorer));
				return true;
			}

			else {
				UnitsActions.diChuyenveCanCuChinh(explorer);
				return true;
			}
		}

		return false;
	}

	private static boolean isEnemyArmyUnitCloseToExplorer() {
		Unit nearestArmyUnit = xvr.layUnitGanNhatTuList(explorer, xvr.layArmyUnitDoiThu());
		if (nearestArmyUnit == null) {
			return false;
		} else {
			double dist = nearestArmyUnit.distanceTo(explorer);
			return dist < 12 && dist > 0 && !nearestArmyUnit.isWorker();
		}
	}

	private static boolean tryAttackingEnemyIfPossible() {
		Unit enemyUnit = null;

		enemyUnit = xvr.layEnemyWorkerTrongBanKinh(300, explorer);
		if (XVR.doithuTerran()) {
			enemyUnit = xvr.getWorkerDichDangXayDungTrongBanKinh(300, explorer);
			if (enemyUnit == null) {
				enemyUnit = xvr.layEnemyWorkerTrongBanKinh(300, explorer);
			}
		}
		if (enemyUnit != null && enemyUnit.distanceTo(xvr.layCanCuGoc()) < 20) {
			enemyUnit = null;
		}

		// boolean isWounded = isExplorerWounded();
		boolean isWounded = isExplorerWounded();
		boolean isProperTargetSelected = enemyUnit != null;
		boolean isNeighborhoodQuiteSafe = (xvr.layUnitsDichTrongBanKinh(3, explorer).size() == 0 && xvr
				.layUnitsDichTrongBanKinh(6, explorer).size() <= 1);
		boolean hasFullShields = explorer.getShields() >= 19;
		boolean isVeryAlive = explorer.getShields() + explorer.getHitPoints() >= 35;
		boolean isOverwhelmed = xvr.layEnemyWorkersTrongBanKinh(6, explorer).size() >= 2;

		if ((!isOverwhelmed || isVeryAlive)
				&& isProperTargetSelected
				&& ((!isWounded && isNeighborhoodQuiteSafe) || (hasFullShields && isNeighborhoodQuiteSafe))) {

			UnitsActions.tanCongUnitDich(explorer, enemyUnit);
			return true;
		}

		if (enemyUnit == null && (!isWounded && isNeighborhoodQuiteSafe)) {
			enemyUnit = xvr.layUnitOfTypeDoiThu(UnitTypes.Protoss_Pylon,
					UnitTypes.Terran_Supply_Depot, UnitTypes.Zerg_Spawning_Pool);

			if (enemyUnit == null) {
				enemyUnit = xvr.layUnitGanNhatTuList(explorer, xvr.layCongTrinhDoiThu());
			}
		}

		if (enemyUnit != null) {
			UnitsActions.tanCongUnitDich(explorer, enemyUnit);
			return true;
		}
		return false;
	}

	private static boolean tryDiscoveringEnemyBaseLocation() {
		boolean hasDiscoveredBaseLocation = !MapExploration.enemyBuildingsDiscovered.isEmpty();
		if (!hasDiscoveredBaseLocation) {
			BaseLocation goTo = null;

			ArrayList<BaseLocation> possibleBases = new ArrayList<BaseLocation>();
			possibleBases.addAll(xvr.getBwapi().getMap().getStartLocations());
			possibleBases.removeAll(MapExploration.baseLocationsDiscovered);
			possibleBases.remove(MapExploration.getOurBaseLocation());

			if (possibleBases.isEmpty()) {
				goTo = (BaseLocation) RUtilities.getRandomListElement(xvr.getBwapi().getMap()
						.getStartLocations());
			} else {
				goTo = (BaseLocation) RUtilities.getRandomListElement(possibleBases);
			}

			if (goTo != null) {
				_isDiscoveringEnemyBase = true;
				UnitsActions.diChuyen(explorer, goTo);
				MapExploration.baseLocationsDiscovered.add(goTo);
				return true;
			}
		}
		return false;
	}

	private static boolean tryScoutingNextBaseLocation() {
		if (!_exploredBackOfMainBase) {
			scoutBackOfMainBase();
			_exploredBackOfMainBase = true;
			return true;
		}

		if (!_exploredSecondBase) {
			MapPoint secondBase = ProtossNexus.getSecondBaseLocation();
			UnitsActions.diChuyen(explorer, secondBase);
			_exploredSecondBase = true;
			return true;
		}

		if (UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Nexus) >= 2) {
			MapPoint tileForNextBase = ProtossNexus.getTileForNextBase(false);
			if (!xvr.getBwapi().isVisible(tileForNextBase.getTx(), tileForNextBase.getTy())) {
				UnitsActions.diChuyen(explorer, tileForNextBase);
				return true;
			} else {
				if (!explorer.isMoving()) {
					UnitsActions.diChuyen(
							explorer,
							MapExploration.getNearestUnknownPointFor(explorer.getX(),
									explorer.getY(), true));
					return true;
				}
			}
		}
		return false;
	}

	private static void scoutBackOfMainBase() {

		int x = 0;
		int y = 0;
		int counter = 0;
		for (Unit mineral : ProtossNexus.getMineralsNearBase(xvr.layCanCuGoc())) {
			x += mineral.getX();
			y += mineral.getY();
			counter++;
		}
		x /= counter;
		y /= counter;

		MapPoint backOfTheBase = new MapPointInstance(x, y);
		UnitsActions.diChuyenKhoiUnitDiemTrucTiep(explorer, backOfTheBase, 7);

	}

}

package ai.handling.constructing;

import java.util.ArrayList;
import java.util.HashMap;

import jnibwapi.JNIBWAPI;
import jnibwapi.model.ChokePoint;
import jnibwapi.model.Unit;
import jnibwapi.types.UnitType;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.map.MapExploration;
import ai.handling.map.MapPoint;
import ai.handling.map.MapPointInstance;
import ai.handling.units.UnitsActions;
import ai.handling.units.UnitCounter;
import ai.managers.UnitManager;
import ai.protoss.ProtossArbiterTribunal;
import ai.protoss.ProtossAssimilator;
import ai.protoss.ProtossCitadelOfAdun;
import ai.protoss.ProtossCyberneticsCore;
import ai.protoss.ProtossFleetBeacon;
import ai.protoss.ProtossForge;
import ai.protoss.ProtossGateway;
import ai.protoss.ProtossNexus;
import ai.protoss.ProtossObservatory;
import ai.protoss.ProtossPhotonCannon;
import ai.protoss.ProtossPylon;
import ai.protoss.ProtossRoboticsFacility;
import ai.protoss.ProtossRoboticsSupportBay;
import ai.protoss.ProtossShieldBattery;
import ai.protoss.ProtossStargate;
import ai.protoss.ProtossTemplarArchives;
import ai.utils.RUtilities;

public class Constructing {

	private static final int PROLONGATED_CONSTRUCTION_TIME = 300; // in fps

	private static XVR xvr = XVR.getInstance();

	private static HashMap<UnitTypes, Unit> _recentConstructionsInfo = new HashMap<>();
	private static HashMap<UnitTypes, MapPoint> _recentConstructionsPlaces = new HashMap<>();
	private static HashMap<Unit, UnitTypes> _recentConstructionsUnitToType = new HashMap<>();
	private static HashMap<Unit, Integer> _recentConstructionsTimes = new HashMap<>();
	private static int _recentConstructionsCounter = 0;
	private static int _actCounter = 0;

	// private static int iIncStep;
	// private static int jIncStep;

	public static void act() {
		_actCounter++;
		if (_actCounter >= 3) {
			_actCounter = 0;
		}

		// Store info about constructing given building for 3 acts, then
		// remove all data
		if (_recentConstructionsCounter++ >= 3) {
			resetInfoAboutConstructions();
		}

		// Check only every N frames
		boolean shouldBuildNexus = ProtossNexus.shouldBuild();
		boolean canBuildOtherThingThanNexus = !shouldBuildNexus || xvr.duTaiNguyen(550);

		if (_actCounter == 0) {
			ProtossNexus.buildIfNecessary();
		} else if (_actCounter == 1 && canBuildOtherThingThanNexus) {
			ProtossPhotonCannon.buildIfNecessary();
			ProtossRoboticsFacility.buildIfNecessary();
			ProtossCyberneticsCore.buildIfNecessary();
			ProtossRoboticsSupportBay.buildIfNecessary();
			ProtossTemplarArchives.buildIfNecessary();
			ProtossGateway.buildIfNecessary();
			ProtossObservatory.buildIfNecessary();
			ProtossAssimilator.buildIfNecessary();
			ProtossCitadelOfAdun.buildIfNecessary();
		} else if (canBuildOtherThingThanNexus) {
			ProtossPhotonCannon.buildIfNecessary();
			ProtossPylon.buildIfNecessary();
			ProtossStargate.buildIfNecessary();
			ProtossForge.buildIfNecessary();
			ProtossShieldBattery.buildIfNecessary();
			ProtossArbiterTribunal.buildIfNecessary();
			ProtossGateway.buildIfNecessary();
		}

		// It can happen that damned worker will stuck somewhere (what a retard)
		if (RUtilities.rand(0, 20) == 0) {
			checkForProlongatedConstructions();
		}
	}

	private static void checkForProlongatedConstructions() {
		int now = xvr.getTime();
		for (Unit builder : _recentConstructionsTimes.keySet()) {
			if (!builder.isConstructing()) {
				continue;
			}

			if (now - _recentConstructionsTimes.get(builder) > PROLONGATED_CONSTRUCTION_TIME) {
				MapPoint buildTile = _recentConstructionsPlaces.get(builder);
				UnitTypes building = _recentConstructionsUnitToType.get(builder);

				constructBuilding(xvr, building, buildTile);

				UnitsActions.diChuyen(builder, xvr.layCanCuGoc());
			}
		}
	}

	private static MapPoint getTileAccordingToBuildingType(UnitTypes building) {

		// Pylon
		if (UnitTypes.Protoss_Pylon.ordinal() == building.ordinal()) {
			return ProtossPylon.findTileForPylon();
		}

		// Photon Cannon
		else if (UnitTypes.Protoss_Photon_Cannon.ordinal() == building.ordinal()) {
			return ProtossPhotonCannon.findTileForCannon();
		}

		// Assimilator
		else if (UnitTypes.Protoss_Assimilator.ordinal() == building.ordinal()) {
			return findTileForAssimilator();
		}

		// Base
		else if (UnitManager.BASE.ordinal() == building.ordinal()) {
			return ProtossNexus.getTileForNextBase(false);
		}

		// Standard building
		else {

			return ProtossPylon.findTileNearPylonForNewBuilding(building);


		}
	}

	public static int[] shouldBuildAnyBuilding() {
		int mineralsRequired = 0;
		int gasRequired = 0;
		int buildingsToBuildTypesNumber = 0;
		if (ProtossNexus.shouldBuild()) {
			mineralsRequired += 400;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossTemplarArchives.shouldBuild()) {
			mineralsRequired += 150;
			gasRequired += 200;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossRoboticsFacility.shouldBuild()) {
			mineralsRequired += 200;
			gasRequired += 200;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossRoboticsSupportBay.shouldBuild()) {
			mineralsRequired += 150;
			gasRequired += 100;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossGateway.shouldBuild()) {
			mineralsRequired += 150;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		// if (TerranBunker.shouldBuild()
		// && UnitCounter.getNumberOfUnits(UnitTypes.Protoss_Bunker) < 2) {
		// mineralsRequired += 100;
		// buildingsToBuildTypesNumber++;
		// }
		if (ProtossAssimilator.shouldBuild()) {
			mineralsRequired += 100;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossPylon.shouldBuild()) {
			mineralsRequired += 100;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossForge.shouldBuild()) {
			mineralsRequired += 150;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossCyberneticsCore.shouldBuild()) {
			mineralsRequired += 150;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossCitadelOfAdun.shouldBuild()) {
			mineralsRequired += 150;
			gasRequired += 100;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossObservatory.shouldBuild()) {
			mineralsRequired += 50;
			gasRequired += 100;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossArbiterTribunal.shouldBuild()) {
			mineralsRequired += 200;
			gasRequired += 150;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossFleetBeacon.shouldBuild()) {
			mineralsRequired += 300;
			gasRequired += 200;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}
		if (ProtossShieldBattery.shouldBuild()) {
			mineralsRequired += 100;
			buildingsToBuildTypesNumber++;
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		}

		if (buildingsToBuildTypesNumber > 0) {
			return new int[] { mineralsRequired + 8, gasRequired, buildingsToBuildTypesNumber };
		} else {
			return null;
		}
	}

	private static void resetInfoAboutConstructions() {
		_recentConstructionsCounter = 0;
		_recentConstructionsInfo.clear();
	}

	private static void addInfoAboutConstruction(UnitTypes building, Unit builder,
			MapPoint buildTile) {
		_recentConstructionsCounter = 0;
		_recentConstructionsInfo.put(building, builder);
		_recentConstructionsPlaces.put(building, buildTile);
		_recentConstructionsUnitToType.put(builder, building);
		_recentConstructionsTimes.put(builder, xvr.getTime());
		ShouldBuildCache.cacheShouldBuildInfo(building, false);
	}

	public static MapPoint findBuildTile(XVR xvr, int builderID, UnitTypes type, MapPoint place) {
		return findBuildTile(xvr, builderID, type.ordinal(), place.getX(), place.getY());
	}

	public static MapPoint findBuildTile(XVR xvr, int builderID, int buildingTypeID, int x, int y) {

		// Point pointToBuild = getLegitTileToBuildNear(builderID,
		// buildingTypeID, tileX, tileY, minDist, maxDist);
		MapPoint tileToBuild = ProtossPylon.findTileNearPylonForNewBuilding(UnitType
				.getUnitTypesByID(buildingTypeID));

		if (tileToBuild == null) {
			JNIBWAPI bwapi = xvr.getBwapi();
			bwapi.printText("Unable to find tile for new "
					+ bwapi.getUnitType(buildingTypeID).getName());
		}
		return tileToBuild;
	}

	public static MapPoint findTileForAssimilator() {
		Unit nearestGeyser = xvr.layUnitGanNhatTuList(xvr.layCanCuGoc(), xvr.layUnitsGas());
		if (nearestGeyser != null
				&& xvr.layUnitsTrongBanKinh(UnitManager.BASE, 15, nearestGeyser, true)
						.isEmpty()) {
			return null;
		}
		if (nearestGeyser != null) {
			return new MapPointInstance(nearestGeyser.getX() - 64, nearestGeyser.getY() - 32);
		} else {
			return null;
		}
	}

	public static MapPoint getLegitTileToBuildNear(Unit worker, UnitTypes type, MapPoint nearTo,
			int minimumDist, int maximumDist, boolean requiresPower) {
		if (worker == null || type == null) {
			return null;
		}
		return getLegitTileToBuildNear(worker.getID(), type.ordinal(), nearTo.getTx(),
				nearTo.getTy(), minimumDist, maximumDist, requiresPower);
	}

	public static MapPoint getLegitTileToBuildNear(Unit worker, UnitTypes type, int tileX,
			int tileY, int minimumDist, int maximumDist, boolean requiresPower) {
		if (worker == null || type == null) {
			return null;
		}
		return getLegitTileToBuildNear(worker.getID(), type.ordinal(), tileX, tileY, minimumDist,
				maximumDist, requiresPower);
	}

	public static MapPoint getLegitTileToBuildNear(int builderID, int buildingTypeID, int tileX,
			int tileY, int minimumDist, int maximumDist, boolean requiresPower) {
		JNIBWAPI bwapi = XVR.getInstance().getBwapi();
		UnitType type = UnitType.getUnitTypeByID(buildingTypeID);
		boolean isBase = type.isBase();
		boolean isCannon = type.isPhotonCannon();
		boolean isPylon = type.isPylon();

		int currentDist = minimumDist;
		while (currentDist <= maximumDist) {
			for (int i = tileX - currentDist; i <= tileX + currentDist; i++) {
				for (int j = tileY - currentDist; j <= tileY + currentDist; j++) {
					if ((!requiresPower || bwapi.hasPower(i, j))
							&& bwapi.canBuildHere(builderID, i, j, buildingTypeID, false)) {
						int x = i * 32;
						int y = j * 32;
						MapPointInstance place = new MapPointInstance(x, y);
						Unit optimalBuilder = xvr.layBuilderToiUu(place);
						if (optimalBuilder != null
								&& (isCannon || isBase || isBuildTileFreeFromUnits(
										optimalBuilder.getID(), i, j))) {
							if (!isTooNearMineralAndBase(place)
									&& (isPylon || isEnoughPlaceToOtherBuildings(place, type))
									&& (isBase || !isOverlappingNextNexus(place, type))
									&& (isBase || !isTooCloseToAnyChokePoint(place))) {

								return place;
							}
						}
					}
				}
			}

			currentDist++;
		}

		return null;
	}

	public static boolean isTooCloseToAnyChokePoint(MapPointInstance place) {
		// for (ChokePoint choke : MapExploration.getChokePoints()) {
		// if (choke.getRadius() < 210
		// && (xvr.layKhoangCachGiua(choke, place) - choke.getRadius() / 32) <=
		// MIN_DIST_FROM_CHOKE_POINT) {
		// return true;
		// }
		// }
		return false;
	}

	private static boolean isOverlappingNextNexus(MapPoint place, UnitType type) {
		if (!type.isBase() && UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Pylon) >= 1) {
			return xvr.layKhoangCachSimple(place, ProtossNexus.getTileForNextBase(false)) <= 4;
		} else {
			return false;
		}
	}

	private static boolean isEnoughPlaceToOtherBuildings(MapPoint place, UnitType type) {
		// type.isPhotonCannon() ||
		if (type.isBase() || type.isOnGeyser() || type.isPylon()) {
			return true;
		}

		int wHalf = type.getTileWidth();
		int hHalf = type.getTileHeight();
		int maxDimension = wHalf > hHalf ? wHalf : hHalf;
		// Map map = xvr.getBwapi().getMap();

		// Define center of the building
		// MapPoint center = new MapPointInstance(place.getX(), place.getY());
		MapPoint center = new MapPointInstance(place.getX() + wHalf, place.getY() + hHalf);

		ArrayList<Unit> buildingsNearby = xvr.layUnitsTrongBanKinh(center, maxDimension + 1,
				xvr.layUnitsBuildings());


		for (Unit unit : buildingsNearby) {
			if (unit.getType().isBuilding() && unit.distanceTo(center) <= maxDimension + 1) {
				return false;
			}
		}
		return true;

	}

	public static boolean isTooNearMineralAndBase(MapPoint point) {
		Unit nearestMineral = xvr.layUnitGanNhatTuList(point, xvr.layUnitsKimCuong());
		double distToMineral = xvr.layKhoangCachGiua(nearestMineral, point);
		if (distToMineral <= 3) {
			return true;
		}

		if (distToMineral <= 5) {
			Unit nearestBase = xvr.layUnitOfTypeGanNhat(UnitManager.BASE, point);
			double distToBase = xvr.layKhoangCachGiua(nearestBase, point);
			if (distToBase < distToMineral) {
				return true;
			}
		}
		return false;
	}

	public static boolean isBuildTileFullyBuildableFor(int builderID, int i, int j,
			int buildingTypeID) {
		UnitType buildingType = UnitType.getUnitTypeByID(buildingTypeID);
		int wHalf = buildingType.getTileWidth() / 2;
		int hHalf = buildingType.getTileHeight() / 2;
		for (int tx = i - wHalf; tx < i + wHalf; tx++) {
			for (int ty = j - hHalf; ty < j + hHalf; ty++) {
				if (!xvr.getBwapi().isBuildable(tx, ty, true)) {
					return false;
				}
			}
		}

		return true;
	}

	public static boolean isBuildTileFreeFromUnits(int builderID, int tileX, int tileY) {
		JNIBWAPI bwapi = XVR.getInstance().getBwapi();
		MapPointInstance point = new MapPointInstance(tileX * 32, tileY * 32);

		// Check if units are blocking this tile
		boolean unitsInWay = false;
		for (Unit u : bwapi.getAllUnits()) {
			if (u.getID() == builderID) {
				continue;
			}
			if (xvr.layKhoangCachGiua(u, point) <= 3) {
				unitsInWay = true;
			}
		}
		if (!unitsInWay) {
			return true;
		}

		return false;
	}

	public static void construct(XVR xvr, UnitTypes building) {

		MapPoint buildTile = getTileAccordingToBuildingType(building);

		if (buildTile != null) {


			if (building.getType().isBase()
					&& UnitCounter.coNhaHoanThanh(UnitTypes.Protoss_Forge)) {
				handleBaseConstruction(building, buildTile);
			} else {

				// Proper construction order
				constructBuilding(xvr, building, buildTile);
			}

		}
	}

	private static void handleBaseConstruction(UnitTypes building, MapPoint buildTile) {
		boolean baseInterrupted = false;

		ChokePoint choke = MapExploration.getImportantChokePointNear(buildTile);

		MapPointInstance point = MapPointInstance.getMiddlePointBetween(buildTile, choke);

		ArrayList<Unit> pylons = xvr.layUnitsTrongBanKinh(UnitTypes.Protoss_Pylon, 10,
				choke, true);
		int cannonsNearby = xvr.demLoaiUnitsTrongBanKinh(UnitTypes.Protoss_Photon_Cannon, 16,
				point, true);

		boolean pylonIsOkay = !pylons.isEmpty() && pylons.get(0).isCompleted();
		if (!pylonIsOkay) {
			baseInterrupted = true;
			building = UnitTypes.Protoss_Pylon;

			buildTile = getLegitTileToBuildNear(xvr.layWorkerNgauNhien(), building, point, 0, 10, true);
		}


		if (pylonIsOkay && cannonsNearby < 0) {
			baseInterrupted = true;
			building = UnitTypes.Protoss_Photon_Cannon;

			buildTile = ProtossPhotonCannon.findTileForCannon();
			// System.out.println("------------- FORCE CANNON FOR BASE");
		}
		if (!baseInterrupted) {
			if (buildTile == null || !Constructing.canBuildAt(buildTile, UnitManager.BASE)) {
				buildTile = ProtossNexus.getTileForNextBase(true);
			}
		}

		constructBuilding(xvr, building, buildTile);
	}

	private static boolean canBuildAt(MapPoint point, UnitTypes type) {
		Unit randomWorker = xvr.layWorkerNgauNhien();
		if (randomWorker == null || point == null) {
			return false;
		}
		return xvr.getBwapi().canBuildHere(randomWorker.getID(), point.getTx(), point.getTy(),
				type.getID(), false);
	}

	private static boolean constructBuilding(XVR xvr, UnitTypes building, MapPoint buildTile) {
		if (buildTile == null) {
			return false;
		}

		Unit workerUnit = xvr.layBuilderToiUu(buildTile);
		if (workerUnit != null) {

			if (buildTile != null) {
				build(workerUnit, buildTile, building);

	
				return true;
			}
		}
		return false;
	}

	public static int ifWeAreBuildingItCountHowManyWorkersIsBuildingIt(UnitTypes type) {
		int result = 0;


		for (Unit unit : xvr.layWorkers()) {
			if (unit.getBuildTypeID() == type.ordinal()) {
				result++;
			}
		}
		return result;
	}

	public static boolean weAreBuilding(UnitTypes type) {
		if (_recentConstructionsInfo.containsKey(type)) {
			return true;
		}
		for (Unit unit : xvr.getBwapi().getMyUnits()) {
			if ((!unit.isCompleted() && unit.getTypeID() == type.ordinal())
					|| unit.getBuildTypeID() == type.ordinal()) {
				return true;
			}
		}
		return false;
	}

	private static void build(Unit builder, MapPoint buildTile, UnitTypes building) {
		boolean canProceed = false;

		if (building.getType().isPhotonCannon() || building.getType().isGateway()) {
			int builders = ifWeAreBuildingItCountHowManyWorkersIsBuildingIt(building);
			canProceed = builders == 0;
		} else {
			canProceed = !weAreBuilding(building);
		}

		if (canProceed) {
			xvr.getBwapi().build(builder.getID(), buildTile.getTx(), buildTile.getTy(),
					building.ordinal());
			addInfoAboutConstruction(building, builder, buildTile);
		
		}
	}

	public static Unit getRandomWorker() {
		return xvr.layWorkerNgauNhien();
	}

	public static boolean canBuildHere(Unit builder, UnitTypes buildingType, int tx, int ty) {
		return xvr.getBwapi().canBuildHere(builder.getID(), tx, ty, buildingType.ordinal(), false);
	}
}

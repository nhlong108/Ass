package ai.core;

import java.util.ArrayList;
import java.util.HashMap;

import jnibwapi.BWAPIEventListener;
import jnibwapi.JNIBWAPI;
import jnibwapi.model.Player;
import jnibwapi.model.Unit;
import jnibwapi.types.RaceType.RaceTypes;
import jnibwapi.types.UnitDamages;
import jnibwapi.types.UnitType;
import ai.handling.map.MapExploration;
import ai.handling.other.NukeHandling;
import ai.managers.StrategyManager;
import ai.protoss.ProtossCyberneticsCore;
import ai.protoss.ProtossGateway;
import ai.protoss.ProtossNexus;
import ai.protoss.ProtossObserver;

public class XVRClient implements BWAPIEventListener {

	private JNIBWAPI bwapi;
	private XVR xvr;

	private ArrayList<Integer> historyOfOurUnits = new ArrayList<>(400);
	private HashMap<Integer, UnitType> historyOfOurUnitsObjects = new HashMap<>();

	// =========================================

	public JNIBWAPI getBwapi() {
		return bwapi;
	}

	public static void main(String[] args) {
		new XVRClient();
	}

	public XVRClient() {
		bwapi = new JNIBWAPI(this);
		xvr = new XVR(this);

		bwapi.start();
	}

	// =========================================

	@Override
	public void connected() {
		bwapi.loadTypeData();
	}

	@Override
	public void gameStarted() {

		// Game settings
		bwapi.enableUserInput();
		bwapi.setGameSpeed(XVR.TOCDO_GAME);
		bwapi.loadMapData(true);

		// ========================================

		XVR.NGUOICHOI = bwapi.getSelf();
		XVR.ID_NGUOICHOI = bwapi.getSelf().getID();

		Player enemy = bwapi.getEnemies().get(0);
		XVR.datDOITHU(enemy);
		XVR.ID_DOITHU = enemy.getID();

		// ========================================

		// Creates map where values of attacks of all unit types are stored.
		UnitDamages.rememberUnitDamageValues();

		// Removes some of initial choke points e.g. those on the edge of the
		// map.
		MapExploration.processInitialChokePoints();

		// ========================================

		// Enemy -> Protoss
		if (enemy.getRaceID() == RaceTypes.Protoss.ordinal()) {
			XVR.setEnemyRace("Protoss");
		}
		// ENEMY -> Terran
		else if (enemy.getRaceID() == RaceTypes.Terran.ordinal()) {
			XVR.setEnemyRace("Terran");
		}
		// ENEMY -> Zerg
		else if (enemy.getRaceID() == RaceTypes.Protoss.ordinal()) {
			XVR.setEnemyRace("Zerg");
		}

		// ==========
		// HotFix
		ProtossNexus.initialMineralGathering();
		
		// =========
		// Nice initial message
	}

	@Override
	public void gameUpdate() {
		Debug.drawDebug(xvr);

		xvr.act();
	}

	public void gameEnded() {
	}

	public void keyPressed(int keyCode) {
	}

	public void matchEnded(boolean winner) {
		Debug.message(xvr, "## Winnn! ##", false);
	}

	public void sendText(String text) {
	}

	private static boolean responded = false;
	
	public void receiveText(String text) {
		if (!responded) {
			responded = true;
			xvr.getBwapi().sendText("sorry, cant talk right now");
			xvr.getBwapi().sendText("have to click very fast, u kno");
		}
	}

	public void nukeDetect(int x, int y) {
		System.out.println("DETECTED NUKE AT: " + x + ", " + y);
		NukeHandling.nukeDetected(x, y);
	}

	public void nukeDetect() {
		System.out.println("DETECTED NUKE OVERALL");
	}

	public void playerLeft(int playerID) {
		xvr.getBwapi().sendText("#");
	}

	public void unitCreate(int unitID) {
		xvr.unitCreated(unitID);
		Unit unit = bwapi.getUnit(unitID);
		UnitType unitType = unit.getType();
		if (!unit.isEnemy()) {
			historyOfOurUnits.add(unitID);
			historyOfOurUnitsObjects.put(unitID, unit.getType());
		}
		
		if (unit.isMyUnit() && unitType.isBase()) {
			ProtossNexus.updateNextBaseToExpand();
		}
	}

	public void unitDestroy(int unitID) {
		boolean wasOurUnit = historyOfOurUnits.contains(unitID);
		if (wasOurUnit) {
			Debug.ourDeaths++;
		} else {
			Debug.enemyDeaths++;
		}

		if (!wasOurUnit) {
			boolean removedSomething = MapExploration
					.enemyUnitDestroyed(unitID);

			if (removedSomething && StrategyManager.getTargetUnit() != null
					&& StrategyManager.getTargetUnit().getID() == unitID) {
				StrategyManager.forceRedefinitionOfNextTarget();
			}
		}

		UnitType unitType = null;
		for (int historyUnitID : historyOfOurUnitsObjects.keySet()) {
			if (historyUnitID == unitID) {
				unitType = historyOfOurUnitsObjects.get(historyUnitID);
			}
		}
		
		if (unitType != null) {
			if (unitType.isBase() && wasOurUnit) {
				ProtossNexus.updateNextBaseToExpand();
			}
		}
	}

	public void unitDiscover(int unitID) {
		Unit unit = Unit.getByID(unitID);
		if (unit == null || !unit.isEnemy()) {
			return;
		}

		MapExploration.enemyUnitDiscovered(unit);

		
		if (XVR.doithuProtoss()) {
			if (unit.getType().isDragoon()) {
				ProtossCyberneticsCore.forceShouldBuild();
			}
		}
	}

	public void unitEvade(int unitID) {
		Unit unit = Unit.getByID(unitID);
		if (unit == null || !unit.isEnemy()) {
			return;
		}
	}

	public void unitHide(int unitID) {
		Unit unit = Unit.getByID(unitID);
		if (unit == null || !unit.isEnemy()) {
			return;
		}

		if (unit.isEnemy()
				&& (unit.isCloaked() || unit.isBurrowed() || !unit.isDetected())) {
			ProtossObserver.hiddenUnitDetected(unit);
		}
	}

	public void unitMorph(int unitID) {
	}

	public void unitShow(int unitID) {
		Unit unit = Unit.getByID(unitID);
		if (unit == null || !unit.isEnemy()) {
			return;
		}

		if (unit.isEnemy() && unit.isHidden()) {

			ProtossObserver.hiddenUnitDetected(unit);
		}

		if (unit.getType().isCarrier() && !ProtossGateway.isPlanAntiAirActive()) {
			ProtossGateway.changePlanToAntiAir();
		}
	}

	public void unitRenegade(int unitID) {
		Unit unit = Unit.getByID(unitID);
		if (unit == null || !unit.isEnemy()) {
			return;
		}
		MapExploration.enemyUnitDiscovered(unit);
	}

	public void saveGame(String gameName) {
	}

	public void unitComplete(int unitID) {
		Unit unit = bwapi.getUnit(unitID);
		UnitType unitType = unit.getType();
		if (unit.isMyUnit() && unitType.isBase()) {
			ProtossNexus.updateNextBaseToExpand();
		}
	}

	public void playerDropped(int playerID) {
		xvr.getBwapi().sendText("###");
	}

}

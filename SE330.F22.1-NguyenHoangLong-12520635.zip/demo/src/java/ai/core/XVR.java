package ai.core;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import ai.handling.map.MapExploration;
import ai.handling.map.MapPoint;
import ai.handling.map.MapPointInstance;
import ai.handling.units.UnitCounter;
import ai.managers.ArmyCreationManager;
import ai.managers.BotStrategyManager;
import ai.managers.ConstructingManager;
import ai.managers.StrategyManager;
import ai.managers.TechnologyManager;
import ai.managers.UnitManager;
import ai.managers.WorkerManager;
import ai.protoss.ProtossGateway;
import ai.protoss.ProtossNexus;
import ai.utils.RUtilities;
import jnibwapi.JNIBWAPI;
import jnibwapi.model.Unit;
import jnibwapi.model.Player;
import jnibwapi.types.UnitType;
import jnibwapi.types.UnitType.UnitTypes;

public class XVR {

	public static final int TOCDO_GAME = 0;
	
	private static final int WHAT_IS_NEAR_DISTANCE = 13;
	
	private static Player DOITHU;
	public static int ID_DOITHU;
	private static String TOC_DOITHU = "Underfined";
	public static Player NGUOICHOI;
	public static int ID_NGUOICHOI;
	
	protected static boolean doithuTerran = false;
	protected static boolean doithuZerg = false;
	protected static boolean doithuProtoss = false;
	
	private static XVR lastInstance;
	private XVRClient client;
	private JNIBWAPI bwapi;
	
	private int time = 0;
	
	@SuppressWarnings("static-access")
	public XVR(XVRClient bwapiClient){
		this.lastInstance = this;
		this.client = bwapiClient;
		this.bwapi = bwapiClient.getBwapi();
	}
	
	public void act(){
		try {
			time++;
			
			if(getTime() % 4 ==0){
				UnitCounter.TinhSoLuongUnits();
			}
			
			if(getTime() % 10 == 0){
				MapExploration.updateInfoAboutHiddenUnits();
			}
			
			if(getTime() % 21 == 0){
				StrategyManager.evaluateMassiveAttackOptions();
			}
			
			if(getTime() % 23 == 0){
				TechnologyManager.act();
			}
			
			if(getTime() % 11 == 0){
				WorkerManager.act();
			}
			
			if(getTime() % 22 ==0){
				UnitManager.act();
			}
			
			if(getTime() % 22 == 7 || getTime() % 22 == 14){
				UnitManager.apDungStrengthEvaluatorLenTatCaUnits();
			}
			
			if(getTime() % 8 == 0){
				UnitManager.avoidSeriousSpellEffectsIfNecessary();
			}
			
			if(getTime() % 8 == 0){
				ProtossNexus.act();
			}
			
			if (getTime() % 13 == 0) {
				ArmyCreationManager.act();
			}

			if (getTime() % 9 == 0) {
				ConstructingManager.act();
			}
		} catch(Exception e){
			System.err.println("Loi");
			e.printStackTrace();
		}
	}
	
	public void unitCreated(int unitID){
		
	}
	
	public static boolean doithuTerran(){
		return doithuTerran;
	}
	
	public static boolean doithuZerg(){
		return doithuZerg;
	}
	
	public static boolean doithuProtoss(){
		return doithuProtoss;
	}

	public static XVR getInstance() {
		return lastInstance;
	}
	
	public XVRClient getClient(){
		return client;
	}
	
	public JNIBWAPI getBwapi(){
		return bwapi;
	}
	
	public int getTime() {
		return time;
	}
	
	public int getTimeSecond(){
		return time / 30;
	}
	
	public int getTimeDifferenceBetweenNowAnd(int oldTime){
		return time - oldTime;
	}
	
	public void buildUnit(Unit building, UnitTypes type){
		if(building == null || type == null){
			return;
		}
		getBwapi().train(building.getID(), type.ordinal());
	}
	
	public ArrayList<Unit> layUnitsOfType(UnitTypes unitTtype) {
		return layUnitsOfType(unitTtype.ordinal());
	}
	
	public ArrayList<Unit> layUnitsOfType(int unitType){
		ArrayList<Unit> objOfThisType = new ArrayList<Unit>();
		for(Unit unit : bwapi.getMyUnits()){
			if(unit.getTypeID() == unitType){
				objOfThisType.add(unit);
			}
		}
		return objOfThisType;
	}
	
	public ArrayList<Unit> layUnitsOfTypeHoanThanh(UnitTypes unitType){
		ArrayList<Unit> objOfThisType = new ArrayList<Unit>();
		
		for(Unit unit : bwapi.getMyUnits()){
			if(unit.getTypeID() == unitType.getID() 
					&& unit.isCompleted()){
				objOfThisType.add(unit);
			}
		}
		return objOfThisType;
	}
	
	public int demUnitsOfType(UnitTypes unitType){
		int dem = 0;
		
		for(Unit unit : bwapi.getMyUnits()){
			if(unit.getTypeID() == unitType.getID()){
				dem++;
			}
		}
		return dem;
	}
	
	public ArrayList<Unit> layUnitsNonWorker(){
		ArrayList<Unit> objectsOfThisType = new ArrayList<Unit>();

		for (Unit unit : bwapi.getMyUnits()) {
			if (!unit.isWorker() && unit.isCompleted()) {
				objectsOfThisType.add(unit);
			}
		}

		return objectsOfThisType;
	}
	
	public ArrayList<Unit> layArmyUnitsAndBuildingsPhongThu(){
		ArrayList<Unit> objectsOfThisType = new ArrayList<Unit>();

		for (Unit unit : layUnitsNonWorker()) {
			UnitType type = unit.getType();
			if (unit.isCompleted() && (!type.isBuilding() || unit.isDefensiveGroundBuilding())) {
				objectsOfThisType.add(unit);
			}
		}
		return objectsOfThisType;
	}
	
	public ArrayList<Unit> layArmyUnitsAndBuildingsPhongThuDichThu() {
		ArrayList<Unit> objectsOfThisType = new ArrayList<Unit>();

		for (Unit unit : bwapi.getEnemyUnits()) {
			UnitType type = unit.getType();
			if ((!type.isBuilding() && !unit.isWorker() && !unit.getType().isLarvaOrEgg())
					|| (type.isBuilding() && unit.isDefensiveGroundBuilding())) {
				objectsOfThisType.add(unit);
			}
		}

		return objectsOfThisType;
	}
	
	public ArrayList<Unit> layWorkers() {
		ArrayList<Unit> objectsOfThisType = new ArrayList<Unit>();

		for (Unit unit : bwapi.getMyUnits()) {
			if (unit.isWorker() && unit.isCompleted()) {
				objectsOfThisType.add(unit);
			}
		}

		return objectsOfThisType;
	}
	
	public int layKimCuong() {
		return bwapi.getSelf().getMinerals();
	}

	public int layGas() {
		return bwapi.getSelf().getGas();
	}
	
	public int laySoQuanFree() {
		return (bwapi.getSelf().getSupplyTotal() - bwapi.getSelf().getSupplyUsed()) / 2;
	}

	public int layTongSoQuan() {
		return (bwapi.getSelf().getSupplyTotal()) / 2;
	}

	public int laySoQuanDaSuDung() {
		return layTongSoQuan() - laySoQuanFree();
	}
	
	public double layKhoangCachGiua(Unit u1, Point point) {
		return layKhoangCachGiua(u1, point.x, point.y);
	}

	public double layKhoangCachGiua(MapPoint u1, MapPoint point) {
		if (u1 == null || point == null) {
			return -1;
		}
		return layKhoangCachGiua(u1.getX(), u1.getY(), point.getX(), point.getX());
	}

	public double layKhoangCachGiua(Unit u1, Unit u2) {
		if (u2 == null) {
			return -1;
		}
		return layKhoangCachGiua(u1, u2.getX(), u2.getY());
	}

	public double layKhoangCachGiua(MapPoint point, int x, int y) {
		if (point == null) {
			return -1;
		}
		return layKhoangCachGiua(point.getX(), point.getY(), x, y);
	}

	public double layKhoangCachGiua(int x1, int y1, int x2, int y2) {
		return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)) / 32;
	}
	
	public ArrayList<Unit> layUnitsKimCuong() {
		ArrayList<Unit> objectsOfThisType = new ArrayList<Unit>();

		int m1 = UnitTypes.Resource_Mineral_Field.ordinal();
		int m2 = UnitTypes.Resource_Mineral_Field_Type_2.ordinal();
		int m3 = UnitTypes.Resource_Mineral_Field_Type_3.ordinal();

		for (Unit unit : bwapi.getNeutralUnits()) {
			if (unit.getTypeID() == m1 || unit.getTypeID() == m2 || unit.getTypeID() == m3) {
				objectsOfThisType.add(unit);
			}
		}

		return objectsOfThisType;
	}
	
	public ArrayList<Unit> layUnitsGas() {
		ArrayList<Unit> objectsOfThisType = new ArrayList<Unit>();

		for (Unit unit : bwapi.getNeutralUnits()) {
			if (unit.getTypeID() == UnitTypes.Resource_Vespene_Geyser.ordinal()) {
				objectsOfThisType.add(unit);
			}
		}

		return objectsOfThisType;
	}
	
	public Unit layCanCuGoc() {
		ArrayList<Unit> bases = layUnitsOfType(UnitManager.BASE.ordinal());
		if (!bases.isEmpty()) {
			return bases.get(0);
		} else {
			return null;
		}
	}
	
	public Unit layUnitOfTypeGanNhat(UnitTypes type, MapPoint closeTo){
		return layUnitOfTypeGanNhat(type, closeTo.getX(), closeTo.getY());
	}
	
	public Unit layUnitOfTypeGanNhat(UnitTypes type, int x, int y){
		double KhoangCachGanNhat = 999999;
		Unit UnitGanNhat = null;
		
		for(Unit otherUnit : layUnitsOfType(type)){
			if(!otherUnit.isCompleted()){
				continue;
			}
			double KhoangCach = layKhoangCachGiua(otherUnit, x, y);
			if(KhoangCach < KhoangCachGanNhat){
				KhoangCachGanNhat = KhoangCach;
				UnitGanNhat = otherUnit;
			}
		}
		return UnitGanNhat; 
	}
	
	public boolean duTaiNguyen(int kimcuong){
		return duTaiNguyen(kimcuong, 0, 0);
	}
	
	public boolean duTaiNguyen(int kimcuong, int gas){
		return duTaiNguyen(gas, 0, 0);
	}
	
	public boolean duTaiNguyen(int kimcuong, int gas, int supply){
		if(kimcuong > 0 && layKimCuong() < kimcuong){
			return false;
		}
		if(gas > 0 && layGas() < gas){
			return false;
		}
		if(supply > 0 && laySoQuanFree() < supply){
			return false;
		}
		return true;
	}
	
	public int demLoaiUnitsTrongBanKinh(UnitTypes type, int Radius,
			MapPoint point, boolean onlyMyUnits){
		if(point == null){
			return -1;
		}
		return demLoaiUnitsTrongBanKinh(type, Radius, point.getX(), point.getY(), onlyMyUnits);
	}
	
	public int demLoaiUnitsTrongBanKinh(UnitTypes type, int Radius,
			int x, int y, boolean onlyMyUnits){
		int result = 0;
		Collection<Unit> unitsList = onlyMyUnits ? bwapi.getMyUnits() : bwapi.getAllUnits();
		for(Unit unit : unitsList){
			if(type.ordinal() == unit.getTypeID() && layKhoangCachGiua(unit, x, y) < Radius){
				result++;
			}
		}
		return result;
	}
	
	public ArrayList<Unit> layUnitsTrongBanKinh(UnitTypes type, int Radius,
			MapPoint point, boolean onlyMyUints){
		if (point == null){
			return new ArrayList<>();
		}
		return layUnitsTrongBanKinh(type, Radius, point.getX(), point.getY(), onlyMyUints);
	}
	
	public ArrayList<Unit> layUnitsTrongBanKinh(UnitTypes type, int Radius,
			int x, int y, boolean onlyMyUnits){
		HashMap<Unit, Double> unitToDistance = new HashMap<Unit, Double>();
		
		for(Unit unit : (onlyMyUnits ? bwapi.getMyUnits() : bwapi.getAllUnits())){
			double khoangcach = layKhoangCachGiua(unit, x, y);
			if(type.ordinal() == unit.getTypeID() && khoangcach <= Radius){
				unitToDistance.put(unit, khoangcach);
			}
		}
		
		ArrayList<Unit> resultList = new ArrayList<Unit>();
		resultList.addAll(RUtilities.sortByValue(unitToDistance, true).keySet());
		return resultList;
	}
	
	public int demUnitsTrongBanKinh(MapPoint point, int Radius, boolean onlyMyUnits) {
		return demUnitsTrongBanKinh(point.getX(), point.getY(), Radius, onlyMyUnits);
	}

	public int demUnitsTrongBanKinh(int x, int y, int Radius, boolean onlyMyUnits) {
		return demUnitsTrongBanKinh(new MapPointInstance(x, y), Radius,
				(onlyMyUnits ? bwapi.getMyUnits() : bwapi.getAllUnits()));
	}

	public int demUnitsTrongBanKinh(MapPoint point, int Radius, Collection<Unit> units) {
		int result = 0;

		for (Unit unit : units) {
			if (layKhoangCachGiua(unit, point) <= Radius) {
				result++;
			}
		}

		return result;
	}
	
	public ArrayList<Unit> layArmyUnitsTrongBanKinh(int x, int y, int Radius, boolean onlyMyUnits) {
		ArrayList<Unit> resultList = new ArrayList<Unit>();

		for (Unit unit : (onlyMyUnits ? bwapi.getMyUnits() : bwapi.getAllUnits())) {
			if (unit.getType().isArmy() && layKhoangCachGiua(unit, x, y) <= Radius) {
				resultList.add(unit);
			}
		}

		return resultList;
	}
	
	public int demKimCuongTrongBanKinh(int Radius, int x, int y) {
		int result = 0;
		for (Unit unit : layUnitsKimCuong()) {
			if (layKhoangCachGiua(unit, x, y) <= Radius) {
				result++;
			}
		}
		return result;
	}
	
	public ArrayList<Unit> layArmyUnitsKhongHoatDongTrongBanKinh(int x, int y, int Radius) {
		ArrayList<Unit> units = new ArrayList<Unit>();
		for (Unit unit : layUnitsNonWorker()) {
			if (unit.isIdle() && layKhoangCachGiua(unit, x, y) <= Radius) {
				units.add(unit);
			}
		}
		return units;
	}
	
	public ArrayList<Unit> layCongTrinhDoiThuVisible() {
		ArrayList<Unit> congtrinh = new ArrayList<Unit>();
		for (Unit unit : getBwapi().getEnemyUnits()) {
			if (unit.getType().isBuilding()) {
				congtrinh.add(unit);
			}
		}
		return congtrinh;
	}
	
	public Unit layUnitGanNhatTuList(MapPoint location, Collection<Unit> units) {
		if (location == null) {
			return null;
		}
		return layUnitGanNhatTuList(location.getX(), location.getY(), units);
	}

	public Unit layUnitGanNhatTuList(int x, int y, Collection<Unit> units) {
		double nearestDistance = 999999;
		Unit Unitgannhat = null;

		for (Unit otherUnit : units) {
			if (!otherUnit.isCompleted()) {
				continue;
			}

			double distance = layKhoangCachGiua(otherUnit, x, y);
			if (distance < nearestDistance) {
				nearestDistance = distance;
				Unitgannhat = otherUnit;
			}
		}

		return Unitgannhat;
	}
	
	public ArrayList<Unit> layUnitsDoiThuVisible(boolean includeGroundUnits, boolean includeAirUnits) {
		ArrayList<Unit> units = new ArrayList<Unit>();
		for (Unit unit : bwapi.getEnemyUnits()) {
			UnitType type = unit.getType();
			if (!type.isBuilding()) {
				if (!type.isFlyer() && includeGroundUnits) {
					units.add(unit);
				} else if (type.isFlyer() && includeAirUnits) {
					units.add(unit);
				}
			}
		}
		return units;
	}

	public ArrayList<Unit> layUnitsDoiThuVisible() {
		return layUnitsDoiThuVisible(true, true);
	}
	
	public Collection<Unit> layArmyUnitDoiThu() {
		ArrayList<Unit> armyUnits = new ArrayList<Unit>();
		for (Unit enemy : MapExploration.getEnemyUnitsDiscovered()) {
			if (!enemy.isWorker() && !enemy.getType().isBuilding()
					&& enemy.getType().getGroundAttackNormalized() > 0) {
				armyUnits.add(enemy);
			}
		}
		return armyUnits;
	}
	
	public Collection<Unit> layUnitsOfTypeDoiThu(UnitTypes... types) {
		ArrayList<UnitTypes> typesList = new ArrayList<UnitTypes>();
		for (UnitTypes unitTypes : types) {
			typesList.add(unitTypes);
		}

		ArrayList<Unit> armyUnits = new ArrayList<Unit>();
		for (UnitTypes type : types) {
			for (Unit enemy : getBwapi().getEnemyUnits()) {
				if (type.getID() == enemy.getType().getID()) {
					armyUnits.add(enemy);
				}
			}
		}
		return armyUnits;
	}
	
	public Unit layUnitOfTypeDoiThu(UnitTypes... types) {
		ArrayList<UnitTypes> typesList = new ArrayList<UnitTypes>();
		for (UnitTypes unitTypes : types) {
			typesList.add(unitTypes);
		}
		for (UnitTypes type : types) {
			for (Unit enemy : getBwapi().getEnemyUnits()) {
				if (type.getID() == enemy.getType().getID()) {
					return enemy;
				}
			}
		}
		return null;
	}
	
	public Collection<Unit> layCongTrinhDoiThu() {
		return MapExploration.getEnemyBuildingsDiscovered();
	}

	public int laySoLuongQuanTrongBanKinh(Unit unit, int Radius, ArrayList<Unit> unitsList) {
		return laySoLuongQuanTrongBanKinh(unit.getX(), unit.getY(), Radius, unitsList);
	}

	public int laySoLuongQuanTrongBanKinh(int x, int y, int Radius, ArrayList<Unit> unitsList) {
		int counter = 0;

		for (Unit unit : unitsList) {
			if (layKhoangCachGiua(unit, x, y) <= Radius) {
				counter++;
			}
		}

		return counter;
	}
	
	private ArrayList<Unit> layTatCaUnits() {
		ArrayList<Unit> allUnits = new ArrayList<Unit>();
		allUnits.addAll(bwapi.getAllUnits());
		return allUnits;
	}

	public ArrayList<Unit> layUnitsTrongBanKinh(int x, int y, int Radius) {
		return layUnitsTrongBanKinh(new MapPointInstance(x, y), Radius, layTatCaUnits());
	}
	
	public ArrayList<Unit> layUnitsTrongBanKinh(MapPoint point, int Radius,
			Collection<Unit> unitsList) {
		HashMap<Unit, Double> unitToDistance = new HashMap<Unit, Double>();

		for (Unit unit : unitsList) {
			double distance = layKhoangCachGiua(unit, point.getX(), point.getY());
			if (distance <= Radius) {
				unitToDistance.put(unit, distance);
			}
		}

		ArrayList<Unit> resultList = new ArrayList<Unit>();
		resultList.addAll(RUtilities.sortByValue(unitToDistance, true).keySet());
		return resultList;
	}
	

	public static String layTocDoiTHu() {
		return TOC_DOITHU;
	}
	
	public static void setEnemyRace(String enemyRaceString) {
		TOC_DOITHU = enemyRaceString;

		if ("Protoss".equals(TOC_DOITHU)) {
			doithuProtoss = true;
			ProtossGateway.enemyIsProtoss();
			BotStrategyManager.setExpandWithCannons(true);
		}

		
		else if ("Zerg".equals(TOC_DOITHU)) {
			doithuZerg = true;
			ProtossGateway.enemyIsZerg();
		}

		
		else if ("Terran".equals(TOC_DOITHU)) {
			doithuTerran = true;
			ProtossGateway.enemyIsTerran();
		}
	}
	
	public Unit layWorkerNgauNhien() {
		for (Unit unit : bwapi.getMyUnits()) {
			if (unit.getTypeID() == UnitManager.WORKER.ordinal() && !unit.isConstructing()) {
				return unit;
			}
		}
		return null;
	}
	
	public Unit layBuilderToiUu(MapPoint buildTile) {
		ArrayList<Unit> freeWorkers = new ArrayList<Unit>();
		for (Unit worker : layWorkers()) {
			if (worker.isCompleted() && !worker.isConstructing() && !worker.isRepairing()
					&& !worker.isUnderAttack()) {
				freeWorkers.add(worker);
			}
		}

		// Return the closest builder to the tile
		return layUnitGanNhatTuList(buildTile, freeWorkers);
	}
	
	public boolean coDetectorDich(int x, int y) {
		return layDetectorDich(x, y) != null;
	}

	public boolean coDetectorDich(MapPoint point) {
		return coDetectorDich(point.getX(), point.getY());
	}

	public Unit layDetectorDich(MapPoint point) {
		return layDetectorDich(point.getX(), point.getY());
	}

	public Unit layDetectorDich(int x, int y) {
		ArrayList<Unit> enemiesNearby = layUnitsTrongBanKinh(new MapPointInstance(x, y),
				WHAT_IS_NEAR_DISTANCE, bwapi.getEnemyUnits());
		for (Unit enemy : enemiesNearby) {
			if (enemy.isCompleted() && enemy.getType().isDetector()) {
				return enemy;
			}
		}
		return null;
	}
	
	public boolean coTruMatDat(MapPoint point) {
		return coTruMatDat(point.getX(), point.getY());
	}

	public boolean coTruMatDat(int x, int y) {
		ArrayList<Unit> enemiesNearby = layUnitsTrongBanKinh(new MapPointInstance(x, y), 11,
				layCongTrinhDoiThu());
		for (Unit enemy : enemiesNearby) {
			if (enemy.isCompleted() && enemy.getType().isAttackCapable()
					&& enemy.canAttackGroundUnits()) {
				return true;
			}
		}
		return false;
	}
	
	public boolean coTruPhongKhong(int x, int y) {
		ArrayList<Unit> enemiesNearby = layUnitsTrongBanKinh(new MapPointInstance(x, y),
				WHAT_IS_NEAR_DISTANCE, layCongTrinhDoiThu());
		for (Unit enemy : enemiesNearby) {
			if (enemy.isCompleted() && enemy.getType().isAttackCapable()
					&& enemy.canAttackAirUnits()) {
				return true;
			}
		}
		return false;
	}

	public Unit layTruMatDatDichThu(MapPoint point) {
		return layTruMatDatDichThu(point.getX(), point.getY());
	}

	public Unit layTruMatDatDichThu(int x, int y, int Radius) {
		ArrayList<Unit> enemiesNearby = layUnitsTrongBanKinh(new MapPointInstance(x, y),
				WHAT_IS_NEAR_DISTANCE, layCongTrinhDoiThu());
		for (Unit enemy : enemiesNearby) {
			if (enemy.isCompleted() && enemy.getType().isAttackCapable()
					&& enemy.canAttackGroundUnits()) {
				return enemy;
			}
		}
		return null;
	}

	public Unit layTruMatDatDichThu(int x, int y) {
		return layTruMatDatDichThu(x, y, WHAT_IS_NEAR_DISTANCE);
	}

	public Unit layTruPhongKhongDichThu(int x, int y) {
		ArrayList<Unit> enemiesNearby = layUnitsTrongBanKinh(new MapPointInstance(x, y),
				WHAT_IS_NEAR_DISTANCE, layCongTrinhDoiThu());
		for (Unit enemy : enemiesNearby) {
			if (enemy.isCompleted() && enemy.getType().isAttackCapable()
					&& enemy.canAttackAirUnits()) {
				return enemy;
			}
		}
		return null;
	}

	public Unit layCanCuMoiNhat() {
		ArrayList<Unit> bases = layUnitsOfType(UnitManager.BASE.ordinal());
		if (!bases.isEmpty()) {
			return bases.get(bases.size() - 1);
		} else {
			return null;
		}
	}
	
	public ArrayList<Unit> layUnitsArmy() {
		ArrayList<Unit> objectsOfThisType = new ArrayList<Unit>();

		for (Unit unit : bwapi.getMyUnits()) {
			UnitType type = unit.getType();
			if (!type.isBuilding() && !type.isWorker()) {
				objectsOfThisType.add(unit);
			}
		}

		return objectsOfThisType;
	}
	
	public int layKhoangCachSimple(MapPoint point1, MapPoint point2) {
		if (point1 == null || point2 == null) {
			return -1;
		}
		return (Math.abs(point1.getX() - point2.getX()) + Math.abs(point1.getY() - point2.getY())) / 32;
	}
	
	public Unit layCanCuGanDichNhat() {
		Unit nearestEnemyBase = MapExploration.getNearestEnemyBase();
		if (nearestEnemyBase == null && !MapExploration.getEnemyBuildingsDiscovered().isEmpty()) {
			nearestEnemyBase = MapExploration.getEnemyBuildingsDiscovered().iterator().next();
		}

		if (nearestEnemyBase == null) {
			return layCanCuMoiNhat();
		} else {
			Unit base = layUnitGanNhatTuList(nearestEnemyBase, ProtossNexus.getBases());
			if (base.equals(layCanCuGoc())) {
				base = layCanCuMoiNhat();
			}
			return base;
		}
	}
	
	public boolean coDichTrongBanKinh(MapPoint point, int Radius) {
		return laySoLuongQuanTrongBanKinh(point.getX(), point.getY(), Radius,
				layUnitsDoiThuVisible()) > 0;
	}
	
	public Unit layDichThuGanNhatTrongBanKinh(MapPoint point, int Radius) {
		Unit enemy = layUnitGanNhatTuList(point, bwapi.getEnemyUnits());
		if (enemy == null || layKhoangCachGiua(enemy, point) > Radius) {
			return null;
		}
		return enemy;
	}
	
	public Player layDichThu() {
		return DOITHU;
	}

	public static void datDOITHU(Player eNEMY) {
		DOITHU = eNEMY;
	}
	
	public ArrayList<Unit> layUnitsNonBuilding() {
		ArrayList<Unit> objectsOfThisType = new ArrayList<Unit>();

		for (Unit unit : bwapi.getMyUnits()) {
			if (!unit.getType().isBuilding() && unit.isCompleted()) {
				objectsOfThisType.add(unit);
			}
		}

		return objectsOfThisType;
	}
	
	public ArrayList<Unit> layUnitsBuildings() {
		ArrayList<Unit> objectsOfThisType = new ArrayList<Unit>();

		for (Unit unit : bwapi.getMyUnits()) {
			if (unit.getType().isBuilding()) {
				objectsOfThisType.add(unit);
			}
		}

		return objectsOfThisType;
	}
	
	public Collection<Unit> layEnemyWorkersTrongBanKinh(int Radius, Unit explorer) {
		ArrayList<Unit> result = new ArrayList<>();
		for (Unit enemy : getBwapi().getEnemyUnits()) {
			if (enemy.getType().isWorker()) {
				if (layKhoangCachGiua(explorer, enemy) <= Radius) {
					result.add(enemy);
				}
			}
		}
		return result;
	}
	
	public Unit layEnemyWorkerTrongBanKinh(int tileRadius, Unit explorer) {
		for (Unit enemy : getBwapi().getEnemyUnits()) {
			if (enemy.getType().isWorker()) {
				if (layKhoangCachGiua(explorer, enemy) <= tileRadius) {
					return enemy;
				}
			}
		}
		return null;
	}
	
	public Unit getWorkerDichDangSuaChuaTrongBanKinh(int Radius, Unit explorer) {
		for (Unit enemy : getBwapi().getEnemyUnits()) {
			if (enemy.getType().isWorker()) {
				if (enemy.isRepairing() && layKhoangCachGiua(explorer, enemy) <= Radius) {
					return enemy;
				}
			}
		}
		return null;
	}
	
	public Unit getWorkerDichDangXayDungTrongBanKinh(int Radius, Unit explorer) {
		for (Unit enemy : getBwapi().getEnemyUnits()) {
			if (enemy.getType().isWorker()) {
				if (enemy.isConstructing() && layKhoangCachGiua(explorer, enemy) <= Radius) {
					return enemy;
				}
			}
		}
		return null;
	}
	
	public Collection<Unit> getWorkersDichTrongBanKinh(int Radius, Unit explorer) {
		ArrayList<Unit> result = new ArrayList<>();

		for (Unit enemy : getBwapi().getEnemyUnits()) {
			if (enemy.getType().isWorker()) {
				if (layKhoangCachGiua(explorer, enemy) <= Radius) {
					result.add(enemy);
				}
			}
		}
		return result;
	}
	
	public Collection<Unit> layUnitsDichTrongBanKinh(int tileRadius, Unit explorer) {
		ArrayList<Unit> result = new ArrayList<>();

		for (Unit enemy : getBwapi().getEnemyUnits()) {
			if (!enemy.getType().isBuilding()) {
				if (layKhoangCachGiua(explorer, enemy) <= tileRadius) {
					result.add(enemy);
				}
			}
		}
		return result;
	}

}

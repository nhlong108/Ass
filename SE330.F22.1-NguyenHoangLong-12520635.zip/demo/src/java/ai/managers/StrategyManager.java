package ai.managers;

import java.awt.Point;
import java.util.Collection;
import java.util.Iterator;

import jnibwapi.model.Unit;
import ai.core.Debug;
import ai.core.XVR;
import ai.handling.army.ArmyPlacing;
import ai.handling.army.TargetHandling;
import ai.handling.map.MapExploration;
import ai.handling.units.UnitCounter;

public class StrategyManager {

	private static XVR xvr = XVR.getInstance();

	private static final int MINIMUM_THRESHOLD_ARMY_TO_PUSH = 41;
	private static final int STATE_PEACE = 5;

	private static final int STATE_NEW_ATTACK = 7;

	private static final int STATE_ATTACK_PENDING = 9;

	private static final int STATE_RETREAT = 11;


	private static int currentState = STATE_PEACE;

	
	private static Point _attackPoint;

	
	private static Unit _attackTargetUnit;

	private static int retreatsCounter = 0;
	private static final int EXTRA_UNITS_PER_RETREAT = 5;

	private static int _minBattleUnits = 2;
	private static int _lastTimeWaitCalled = 0;

	

	private static boolean decideIfWeAreReadyToAttack() {
		int battleUnits = UnitCounter.laySoLuongUnitsThamChienHoanThanh();
		int minUnits = calculateMinimumUnitsToAttack();
		
		if (xvr.getTimeSecond() >= 380 && minUnits < 5) {
			final int EXTRA = 5;
			minUnits += EXTRA;
			_minBattleUnits += EXTRA;
		}
		
		// int dragoons =
		// UnitCounter.getNumberOfUnits(UnitTypes.Protoss_Dragoon);

//		System.out.println("battleUnits >= minUnits -> " + battleUnits + " / " + minUnits);
		if (battleUnits >= minUnits) {
//			System.out.println("   YES");
			return true;
		} else {
			boolean weAreReady = (battleUnits >= minUnits * 0.35) && isAnyAttackFormPending();
//			System.out.println("   NO: " + weAreReady);

			if (battleUnits > MINIMUM_THRESHOLD_ARMY_TO_PUSH) {
				weAreReady = true;
			}

//			if (isAnyAttackFormPending() && !weAreReady) {
//				if (retreatsCounter == 0 || _minBattleUnits == 0) {
//					_minBattleUnits = 13;
//				}
//				retreatsCounter++;
//			}

			return weAreReady;
		}

		// if (battleUnits >= MINIMUM_INITIAL_ARMY_TO_PUSH_ONE_TIME
		// && !pushedInitially) {
		// pushedInitially = true;
		// return true;
		// }
		//
		// // If there's more than threshold of psi used, attack. Always.
		// if (xvr.getSuppliesUsed() >= (ProtossNexus.MAX_WORKERS +
		// MINIMUM_ARMY_PSI_USED_THRESHOLD)) {
		// return true;
		// }
		//
		// // If there's more than threshold value of battle units
		// if (battleUnits > MINIMUM_THRESHOLD_ARMY_TO_PUSH) {
		// return true;
		// }
		//
		// int minimumArmyToPush;
		// if (!pushedInitially) {
		// minimumArmyToPush = MINIMUM_INITIAL_ARMY_TO_PUSH_ONE_TIME;
		// pushedInitially = true;
		// return true;
		// } else {
		// minimumArmyToPush = MINIMUM_NON_INITIAL_ARMY_TO_PUSH + 5
		// * retreatsCounter;
		// }
		// boolean weAreReadyToAttack = (battleUnits >= (forceMinimum ?
		// minimumArmyToPush
		// : minimumArmyToPush));
		//
		// if (minimumArmyToPush == MINIMUM_INITIAL_ARMY_TO_PUSH_ONE_TIME
		// || battleUnits >= (1.5 * minimumArmyToPush)
		// * Math.max(1,
		// MapExploration.getNumberOfKnownEnemyBases())) {
		// weAreReadyToAttack = true;
		// }

		// if ((MapExploration.getNumberOfKnownEnemyBases() > 0 && (battleUnits
		// >= (1.5 * MINIMUM_NON_INITIAL_ARMY_TO_PUSH)
		// * MapExploration.getNumberOfKnownEnemyBases()))) {
		// weAreReadyToAttack = true;
		// }

		// // Check if enemy isn't attacking our base; if so, then go back.
		// if (weAreReadyToAttack) {
		// Unit bunker =
		// xvr.getUnitOfTypeNearestTo(UnitTypes.Protoss_Photon_Cannon,
		// xvr.getFirstBase());
		// if (bunker != null) {
		//
		// // Calculate enemy units near our bunker
		// int enemyUnits = xvr.getNumberUnitsInRadius(bunker.getX(),
		// bunker.getY(), 25, xvr.getEnemyUnits());
		// if (enemyUnits >= 5) {
		// return false;
		// }
		// }
		// }

		// return weAreReadyToAttack;
	}

	public static int calculateMinimumUnitsToAttack() {
		return getMinBattleUnits() + retreatsCounter * EXTRA_UNITS_PER_RETREAT
				+ (retreatsCounter >= 2 ? retreatsCounter * 2 : 0);
	}

	/**
	 * Decide if full attack makes sense or if we're already attacking decide
	 * whether to retreat, continue attack or to change target.
	 */
	public static void evaluateMassiveAttackOptions() {

		// Currently we are nor attacking, nor retreating.
		if (!isAnyAttackFormPending()) {
			decisionWhenNotAttacking();
		}

		// We are either attacking or retreating.
		if (isAnyAttackFormPending()) {
			decisionWhenAttacking();
		}
	}

	private static void decisionWhenNotAttacking() {

		// According to many different factors decide if we should attack
		// enemy.
		boolean shouldAttack = decideIfWeAreReadyToAttack();

		// If we should attack, change the status correspondingly.
		if (shouldAttack) {
			changeStateTo(STATE_NEW_ATTACK);
		} else {
			armyIsNotReadyToAttack();
		}
	}

	private static void decisionWhenAttacking() {

		// If our army is ready to attack the enemy...
		if (isNewAttackState()) {
			changeStateTo(STATE_ATTACK_PENDING);

			// We will try to define place for our army where to attack. It
			// probably will be center around a crucial building like Command
			// Center. But what we really need is the point where to go, not the
			// unit. As long as the point is defined we can attack the enemy.

			// If we don't have defined point where to attack it means we
			// haven't yet decided where to go. So it's the war's very start.
			// Define this assault point now. It would be reasonable to relate
			// it to a particular unit.
			// if (!isPointWhereToAttackDefined()) {
			StrategyManager.defineInitialAttackTarget();
			// }
		}

		// Attack is pending, it's quite "regular" situation.
		if (isAttackPending()) {

			// Now we surely have defined our point where to attack, but it can
			// be so, that the unit which was the target has been destroyed
			// (e.g. just a second ago), so we're standing in the middle of
			// wasteland.
			// In this case define next target.
			// if (!isSomethingToAttackDefined()) {
			defineNextTarget();
			// }

			// Check again if continue attack or to retreat.
			boolean shouldAttack = decideIfWeAreReadyToAttack();
			if (!shouldAttack) {
				retreatsCounter++;
				changeStateTo(STATE_RETREAT);
			}
		}

		// If we should retreat... fly you fools!
		if (isRetreatNecessary()) {
			retreat();
		}
	}

	public static void forceRedefinitionOfNextTarget() {
		_attackPoint = null;
		_attackTargetUnit = null;
		defineNextTarget();
	}

	private static void defineNextTarget() {
		Unit target = TargetHandling.getImportantEnemyUnitTargetIfPossibleFor(
				ArmyPlacing.getArmyCenterPoint(), true, true);
		Collection<Unit> enemyBuildings = xvr.layCongTrinhDoiThu();

		for (Iterator<Unit> iterator = enemyBuildings.iterator(); iterator.hasNext();) {
			Unit unit = (Unit) iterator.next();
			if (unit.getType().isOnGeyser()) {
				iterator.remove();
			}
		}

		if (!TargetHandling.isProperTarget(target)) {
			target = TargetHandling.findTopPriorityTargetIfPossible(enemyBuildings);
		}
		if (!TargetHandling.isProperTarget(target)) {
			target = TargetHandling.findHighPriorityTargetIfPossible(enemyBuildings);
		}
		if (!TargetHandling.isProperTarget(target)) {
			target = TargetHandling.findNormalPriorityTargetIfPossible(enemyBuildings);
		}

		if (!TargetHandling.isProperTarget(target)) {
			Unit base = xvr.layCanCuGoc();
			if (base == null) {
				return;
			}
			target = xvr.layUnitGanNhatTuList(base.getX(), base.getY(), enemyBuildings);
		}

		// Update the target.
		if (target != null) {
			if (_attackTargetUnit != target) {
				changeNextTargetTo(target);
			} else {
				updateTargetPosition();
			}
		} else {
			_attackPoint = null;
			if (_attackTargetUnit != target && _attackTargetUnit == null) {
				Debug.message(xvr, "Next target is null... =/");
			}
		}

		// System.out.println("_attackTargetUnit = " +
		// _attackTargetUnit.toStringShort());
		// System.out.println("_attackPoint = " + _attackPoint);
		// System.out.println("isProperTarget(target) = " +
		// TargetHandling.isProperTarget(target));
		// System.out.println();
	}

	private static void updateTargetPosition() {
		Point point = new Point(_attackTargetUnit.getX(), _attackTargetUnit.getY());
		_attackPoint = point;
	}

	private static void retreat() {
		changeStateTo(STATE_PEACE);
	}

	private static void changeStateTo(int newState) {
		currentState = newState;
		if (currentState == STATE_PEACE || currentState == STATE_NEW_ATTACK) {
			armyIsNotReadyToAttack();
		}
	}

	public static boolean isAnyAttackFormPending() {
		return currentState != STATE_PEACE;
	}

	private static boolean isNewAttackState() {
		return currentState == STATE_NEW_ATTACK;
	}

	public static boolean isAttackPending() {
		return currentState == STATE_ATTACK_PENDING;
	}

	public static boolean isRetreatNecessary() {
		return currentState == STATE_RETREAT;
	}

	public static boolean isSomethingToAttackDefined() {
		// return _attackUnitNeighbourhood != null
		// && _attackUnitNeighbourhood.isExists();
		return _attackTargetUnit != null && !_attackTargetUnit.getType().isOnGeyser();
	}

	private static void armyIsNotReadyToAttack() {
		_attackPoint = null;
		_attackTargetUnit = null;
	}

	private static void defineInitialAttackTarget() {
		// Unit buildingToAttack = MapExploration.getNearestEnemyBase();
		Unit buildingToAttack = MapExploration.getNearestEnemyBuilding();

		// We know some building of CPU that we can attack.
		if (buildingToAttack != null) {
			changeNextTargetTo(buildingToAttack);
		}

		// No building to attack found, safely decide not to attack.
		else {
			changeStateTo(STATE_PEACE);
		}
	}

	private static void changeNextTargetTo(Unit attackTarget) {
		if (attackTarget == null) {
			Debug.message(xvr, "ERROR! ATTACK TARGET UNKNOWN!");
			return;
		}
		// Debug.message(xvr, "Next to attack: "
		// + attackTarget.getType().getName());

		_attackTargetUnit = attackTarget;
		updateTargetPosition();
	}

	public static Unit getTargetUnit() {
		return _attackTargetUnit;
	}

	public static Point getTargetPoint() {
		return _attackPoint;
	}

	private static void waitUntilMinBattleUnits() {
		int now = xvr.getTimeSecond();
		if (now - _lastTimeWaitCalled > 100) {
			_lastTimeWaitCalled = now;

			// if (minBattleUnits < minUnits) {
			// minBattleUnits += minUnits;
			// }

			retreatsCounter++;
			forcePeace();
		}

	}

	public static int getMinBattleUnits() {
		return _minBattleUnits;
	}

	public static void forcePeace() {
		changeStateTo(STATE_PEACE);
	}

	public static void waitForMoreUnits() {
		waitUntilMinBattleUnits();
	}

}

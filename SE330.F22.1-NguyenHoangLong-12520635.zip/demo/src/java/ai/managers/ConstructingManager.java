package ai.managers;

import ai.handling.constructing.Constructing;

public class ConstructingManager {

	public static void act() {
		Constructing.act();
	}

}

package ai.managers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import jnibwapi.model.Unit;
import jnibwapi.types.UnitType;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.army.ArmyPlacing;
import ai.handling.army.StrengthEvaluator;
import ai.handling.army.TargetHandling;
import ai.handling.map.MapExploration;
import ai.handling.units.CallForHelp;
import ai.handling.units.UnitsActions;
import ai.protoss.ProtossArbiter;
import ai.protoss.ProtossArchon;
import ai.protoss.ProtossDarkTemplar;
import ai.protoss.ProtossHighTemplar;
import ai.protoss.ProtossNexus;
import ai.protoss.ProtossObserver;
import ai.protoss.ProtossReaver;
import ai.utils.RUtilities;

public class UnitManager {

	public static final UnitTypes WORKER = UnitTypes.Protoss_Probe;
	public static final UnitTypes BASE = UnitTypes.Protoss_Nexus;
	public static final UnitTypes GATEWAY = UnitTypes.Protoss_Gateway;

	private static XVR xvr = XVR.getInstance();

	private static int _unitCounter = 0;
	
	public static void act(){
		Unit base = xvr.layCanCuGoc();
		if(base == null){
			return;
		}
		
		for(Unit unit : xvr.layUnitsNonWorker()){
			UnitType type = unit.getType();
			if(type.equals(UnitManager.WORKER)){
				continue;
			}
			
			if(type.isReaver() || type.isHighTemplar() || type.isObserver()){
				handleUnitBehaviour(unit);
				continue;
			}
			
			if(type.isDragoon() && unit.isStartingAttack()){
				continue;
			}
			
			actTryAttackingCloseEnemyUnits(unit);
			
			if(type.isDarkTemplar()){
				continue;
			}
			
			avoidHiddenUnitsIfNecessary(unit);
			
			handleUnitBehaviour(unit);
		}
		_unitCounter = 0;
		CallForHelp.clearOldOnes();
	}
	
	public static void act(Unit unit){
		UnitType unitType = UnitType.getUnitTypeByID(unit.getTypeID());
		if(unitType == null){
			return;
		}
		
		if(unitType.isFlyer()){
			if(UnitsActions.chayKhoiQuanOrTruDich(unit, false, true, true)){
				return;
			}
		}
		
		if(unitType.isBuilding()){
			BuildingManager.act(unit);
		}
		
		else if(unitType.getID() == UnitTypes.Protoss_Observer.ordinal()){
			ProtossObserver.act(unit);
			return;
		}
		
		else if(unit.getTypeID() == UnitTypes.Protoss_Dark_Templar.ordinal()){
			ProtossDarkTemplar.act(unit);
			return;
		}
		
		else{
			if(unit.getCallForHelpMission() != null){
				actWhenOnCallForHelpMission(unit);
			}
			
			else{
				if (StrategyManager.isAttackPending()) {
					actWhenMassiveAttackIsPending(unit);
				}

				else {
					actWhenNoMassiveAttack(unit);
				}
			}
			_unitCounter++;
		}
		
		if (unitType.getID() == UnitTypes.Protoss_Reaver.ordinal()) {
			ProtossReaver.act(unit);
		}

		// High Templar
		else if (unit.getTypeID() == UnitTypes.Protoss_High_Templar.ordinal()) {
			ProtossHighTemplar.act(unit);
			return;
		}

		// Arbiter
		else if (unit.getTypeID() == UnitTypes.Protoss_Arbiter.ordinal()) {
			ProtossArbiter.act(unit);
			return;
		}
	}
	
	private static void handleAntiStuck(Unit unit){
		boolean shouldFightBack = false;

		if (unit.getType().isWorker()) {
			return;
		}

		if (unit.isStuck() || unit.isUnderAttack() || unit.isMoving()) {
			Unit nearestEnemy = xvr.layDichThuGanNhatTrongBanKinh(unit, 1);
			shouldFightBack = nearestEnemy != null && nearestEnemy.isDetected();

			if (shouldFightBack
					|| unit.isStuck()
					|| (unit.isMoving() && xvr.layUnitsTrongBanKinh(unit, 1, xvr.layUnitsNonWorker())
							.size() >= 2) || unit.getGroundWeaponCooldown() == 0) {
				actTryAttackingCloseEnemyUnits(unit);
			}
		}

		else if (unit.getGroundWeaponCooldown() == 0 && unit.isUnderAttack()) {
			if (shouldFightBack) {
				actTryAttackingCloseEnemyUnits(unit);
			}
		}	
	}
	
	public static void apDungStrengthEvaluatorLenTatCaUnits() {
		for (Unit unit : xvr.layUnitsNonBuilding()) {
			UnitType type = unit.getType();
			if (type.equals(UnitManager.WORKER)) {
				continue;
			}

			if (type.isDarkTemplar()) {
				continue;
			}

			if (type.isHighTemplar() || type.isObserver()) {
				continue;
			}

			if (!type.isReaver()) {
				decideSkirmishIfToFightOrRetreat(unit);
			}

			handleAntiStuck(unit);
		}
	}
	
	private static void handleUnitBehaviour(Unit unit) {
		UnitType type = unit.getType();

		boolean extraCondition = false;
		if (type.getID() == UnitTypes.Protoss_Archon.ordinal()) {
			extraCondition = ProtossArchon.isSeriouslyWounded(unit);
		}

		if (extraCondition || unit.getHitPoints() <= 30
				|| unit.getShields() <= type.getMaxShields() / 2) {

			if (isInSuicideShouldFightPosition(unit)) {
				return;
			}

			if (xvr.demLoaiUnitsTrongBanKinh(UnitTypes.Terran_Siege_Tank_Siege_Mode, 15, unit,
					false) > 0) {
				return;
			}

			if (unit.distanceTo(xvr.layCanCuGoc()) < 17) {
				return;
			}
			
			if (StrategyManager.isAttackPending()) {
				return;
			}

			UnitsActions.actKhiMauVaGiapThap(unit, false);
		}
	}
	
	private static boolean isInSuicideShouldFightPosition(Unit unit) {
		if (!unit.getType().isDarkTemplar()) {
			return false;
		}

		// Only if we're only unit in this region it makes sense to die.
		int alliesNearby = -1 + xvr.demUnitsTrongBanKinh(unit, 5, true);
		if (alliesNearby <= 0) {
			Unit enemy = xvr.layTruMatDatDichThu(unit.getX(), unit.getY());
			if (xvr.layKhoangCachGiua(enemy, unit) <= 3) {
				return true;
			}
		}

		return false;
	}
	
	private static void avoidHiddenUnitsIfNecessary(Unit unit) {
		Unit hiddenEnemyUnitNearby = MapExploration.getHiddenEnemyUnitNearbyTo(unit);
		if (hiddenEnemyUnitNearby != null && unit.isDetected()
				&& !hiddenEnemyUnitNearby.isDetected()) {
			UnitsActions.diChuyenKhoiUnit(unit, hiddenEnemyUnitNearby, 9);
		}
	}
	
	private static void avoidSeriousSpellEffectsIfNecessary(Unit unit) {
		if (unit.isUnderStorm() || unit.isUnderDisruptionWeb()) {
			if (unit.isMoving()) {
				return;
			}
			UnitsActions.diChuyen(unit, unit.getX() + 5 * 32 * (-1 * RUtilities.rand(0, 1)),
					unit.getY() + 5 * 32 * (-1 * RUtilities.rand(0, 1)));
		}
	}
	
	private static void decideSkirmishIfToFightOrRetreat(Unit unit) {
		Unit firstBase = xvr.layCanCuGoc();
		UnitType type = unit.getType();
		if (firstBase == null) {
			return;
		}

		if (!unit.isAttacking() || xvr.layKhoangCachSimple(unit, firstBase) <= 15) {
			return;
		}
		
		if (unit.getType().isDarkTemplar() || unit.getType().isObserver()) {
			if (!unit.isDetected()) {
				return;
			}
		}

		if (type.isDragoon() || type.isReaver()) {
			if (unit.isStartingAttack()) {
				return;
			}
			Unit enemyNear = xvr.layUnitGanNhatTuList(unit, xvr.layUnitsDoiThuVisible());
			if (unit != null && enemyNear != null && xvr.layKhoangCachGiua(unit, enemyNear) <= 3) {
				return;
			}
		}

		if (xvr.layUnitsTrongBanKinh(UnitTypes.Terran_Siege_Tank_Siege_Mode, 20, unit, false)
				.size() > 0) {
			return;
		}

		if (xvr.layUnitsTrongBanKinh(UnitTypes.Terran_Bunker, 3, unit, false).size() > 0) {
			return;
		}

		if (xvr.layUnitsTrongBanKinh(UnitTypes.Protoss_Photon_Cannon, 3, unit, false).size() > 0) {
			return;
		}

		if (unit.distanceTo(xvr.layCanCuGoc()) <= 19) {
			return;
		}

		if (xvr.layKhoangCachGiua(xvr.layUnitGanNhatTuList(unit, ProtossNexus.getBases()), unit) <= 10) {
			return;
		}

		if (xvr.layUnitsTrongBanKinh(UnitTypes.Protoss_Photon_Cannon, 4, unit, false).size() > 0) {
			return;
		}

		if (xvr.layUnitsTrongBanKinh(UnitTypes.Protoss_Photon_Cannon, 4, unit, true).size() > 0) {
			return;
		}

		if (xvr.layUnitsTrongBanKinh(UnitTypes.Zerg_Sunken_Colony, 3, unit, false).size() > 0) {
			return;
		}

		if (xvr.layUnitsTrongBanKinh(UnitTypes.Protoss_Probe, 10, unit, false).size() > 2) {
			return;
		}

		if (!StrengthEvaluator.isStrengthRatioFavorableFor(unit)) {
			UnitsActions.diChuyen(unit, xvr.layCanCuGoc());
		}
	}
	
	private static void actTryAttackingCloseEnemyUnits(Unit unit) {
		if (unit.getType().isObserver()) {
			return;
		}

		boolean groundAttackCapable = unit.canAttackGroundUnits();
		boolean airAttackCapable = unit.canAttackAirUnits();
		Unit importantEnemyUnitNearby = null;
		Unit enemyToAttack = null;

		Collection<Unit> enemyWorkers = xvr.layEnemyWorkersTrongBanKinh(5, unit);
		if (enemyWorkers != null) {
			for (Unit worker : enemyWorkers) {
				if (worker.isRepairing()) {
					importantEnemyUnitNearby = worker;
					break;
				}
			}

			if (importantEnemyUnitNearby != null) {
				UnitsActions.tanCongUnitDich(unit, enemyToAttack);
				return;
			}
		}

		Unit enemyWorker = xvr.layEnemyWorkerTrongBanKinh(2, unit);
		if (enemyWorker != null) {
			importantEnemyUnitNearby = enemyWorker;
			if (xvr.layKhoangCachGiua(xvr.layCanCuGoc(), importantEnemyUnitNearby) > 30
					|| xvr.getTimeSecond() > 600) {
				UnitsActions.tanCongUnitDich(unit, enemyToAttack);
				return;
			}
		}

		if (XVR.doithuTerran() && xvr.getTimeSecond() > 600) {
			if ((unit.getShields() < 15 || (unit.getShields() < 40 && unit.getHitPoints() < 40))) {
				return;
			}
		}

		importantEnemyUnitNearby = TargetHandling.getImportantEnemyUnitTargetIfPossibleFor(unit,
				groundAttackCapable, airAttackCapable);

		ArrayList<Unit> enemyUnits = xvr
				.layUnitsDoiThuVisible(groundAttackCapable, airAttackCapable);

		if (importantEnemyUnitNearby != null && importantEnemyUnitNearby.isDetected()) {
			if (!importantEnemyUnitNearby.getType().isTerranMine()
					|| (unit.getType().getGroundWeapon().getMaxRange() / 32) >= 2)
				enemyToAttack = importantEnemyUnitNearby;
		}

		else {
			enemyToAttack = xvr.layUnitGanNhatTuList(unit, enemyUnits);
		}
		
		if (enemyToAttack != null && !enemyToAttack.isDetected()) {
			enemyToAttack = null;
		}

		if (enemyToAttack != null
				&& (enemyToAttack.getType().isWorker() && xvr.getTimeSecond() < 600 && xvr
						.layKhoangCachGiua(enemyToAttack, xvr.layCanCuGoc()) < 30)) {
			enemyToAttack = null;

			for (Iterator<Unit> iterator = enemyUnits.iterator(); iterator.hasNext();) {
				Unit enemyUnit = (Unit) iterator.next();
				if (enemyUnit.getType().isWorker()
						&& xvr.layKhoangCachGiua(enemyToAttack, xvr.layCanCuGoc()) < 25) {
					iterator.remove();
				}
			}

			enemyToAttack = xvr.layUnitGanNhatTuList(unit, enemyUnits);
		}

		if (enemyToAttack != null && enemyToAttack.isDetected()) {
			if (isUnitInPositionToAlwaysAttack(unit)) {
				UnitsActions.tanCongUnitDich(unit, enemyToAttack);
				return;
			}

			Unit nearestEnemy = xvr.layUnitGanNhatTuList(unit,
					xvr.layUnitsDoiThuVisible(groundAttackCapable, airAttackCapable));

			if (nearestEnemy != null && xvr.layKhoangCachGiua(unit, nearestEnemy) <= 1) {
				return;
			}

			else {
				if (!StrengthEvaluator.isStrengthRatioFavorableFor(unit)
						&& unit.distanceTo(xvr.layCanCuGoc()) > 25) {
					return;
				}

				int distance = (int) xvr.layKhoangCachSimple(unit, enemyToAttack);
				if (distance < TargetHandling.MAX_DIST) {
					if (XVR.doithuTerran() && xvr.getTimeSecond() < 500) {
						if (enemyToAttack.getType().isBunker()) {
							enemyWorker = xvr.layEnemyWorkerTrongBanKinh(12, unit);
							if (enemyWorker != null) {
								importantEnemyUnitNearby = enemyWorker;
								UnitsActions.tanCongUnitDich(unit, enemyToAttack);
								return;
							}
							return;
						}
					}
					UnitsActions.tanCong(unit, enemyToAttack);
				}
			}
		}
	}
	
	private static boolean isUnitInPositionToAlwaysAttack(Unit unit) {
		boolean ourPhotonCannonIsNear = xvr.layUnitsTrongBanKinh(
				UnitTypes.Protoss_Photon_Cannon, 4, unit, true).size() > 0;
		boolean baseInDanger = (xvr.layKhoangCachGiua(
				xvr.layUnitGanNhatTuList(unit, ProtossNexus.getBases()), unit) <= 7);

		return ourPhotonCannonIsNear || baseInDanger;
	}
	
	private static void actWhenOnCallForHelpMission(Unit unit) {
		Unit caller = unit.getCallForHelpMission().getCaller();

		if (xvr.layKhoangCachGiua(unit, caller) <= 3) {
			unit.getCallForHelpMission().unitArrivedToHelp(unit);
		}

		else {
			if (StrengthEvaluator.isStrengthRatioFavorableFor(unit)) {
				UnitsActions.tanCong(unit, caller.getX(), caller.getY());
			}
		}
	}
	
	private static boolean actMakeDecisionSomeoneCalledForHelp(Unit unit) {
		for (CallForHelp call : CallForHelp.getThoseInNeedOfHelp()) {
			boolean willAcceptCallForHelp = false;

			if (call.isCritical()) {
				willAcceptCallForHelp = true;
			}

			else if (xvr.layKhoangCachGiua(call.getCaller(), unit) < 30) {
				willAcceptCallForHelp = true;
			}

			if (willAcceptCallForHelp) {
				call.unitHasAcceptedIt(unit);
				return true;
			}
		}
		return false;
	}
	
	private static void actWhenNoMassiveAttack(Unit unit) {
		if (shouldUnitBeExplorer(unit)) {
			UnitsActions.danTraiNgauNhien(unit);
		} else {
			if (isUnitAttackingSomeone(unit)) {
				return;
			}

			boolean isOnCallForHelpMission = false;
			if (CallForHelp.isAnyCallForHelp()) {
				boolean accepted = actMakeDecisionSomeoneCalledForHelp(unit);
				if (!isOnCallForHelpMission && accepted) {
					isOnCallForHelpMission = true;
				}
			}

			if (!isOnCallForHelpMission) {
				ArmyPlacing.goToSafePlaceIfNotAlreadyThere(unit);
			}
		}
	}
	
	private static boolean shouldUnitBeExplorer(Unit unit) {
		return (_unitCounter == 0 || _unitCounter == 1 || _unitCounter == 7)
				|| unit.getTypeID() == UnitTypes.Protoss_Dark_Templar.ordinal();
	}
	
	private static void actWhenMassiveAttackIsPending(Unit unit) {

		if (StrategyManager.isSomethingToAttackDefined()) {
			if (isUnitAttackingSomeone(unit)) {
				return;
			}

			if (StrategyManager.getTargetPoint() != null) {
				if (!isUnitAttackingSomeone(unit)) {
					UnitsActions.tanCong(unit, StrategyManager.getTargetPoint().x,
							StrategyManager.getTargetPoint().y);
				}
				if (isUnitFullyIdle(unit)) {
					UnitsActions.danTraiNgauNhien(unit);
				}
			} else {
				UnitsActions.danTraiNgauNhien(unit);
			}
		}

		else {
			UnitsActions.danTraiNgauNhien(unit);
		}

		if (!StrengthEvaluator.isStrengthRatioFavorableFor(unit)) {
			UnitsActions.diChuyenveCanCuChinh(unit);
		}
	}
	
	private static boolean isUnitFullyIdle(Unit unit) {
		return !unit.isAttacking() && !unit.isMoving() && !unit.isUnderAttack() && unit.isIdle();
	}

	private static boolean isUnitAttackingSomeone(Unit unit) {
		return unit.getOrderTargetID() != -1 || unit.getTargetUnitID() != -1;
	}

	public static void avoidSeriousSpellEffectsIfNecessary() {
		for (Unit unit : xvr.getBwapi().getMyUnits()) {
			avoidSeriousSpellEffectsIfNecessary(unit);
		}
	}
	
}

package ai.managers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import jnibwapi.model.Unit;
import jnibwapi.types.UnitType;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.Debug;
import ai.core.XVR;
import ai.handling.army.StrengthEvaluator;
import ai.handling.map.Explorer;
import ai.handling.map.MapPoint;
import ai.handling.units.UnitsActions;
import ai.protoss.ProtossNexus;
import ai.utils.RUtilities;

public class WorkerManager {

	public static final int GUY_TO_CHASE_OTHERS_INDEX = 1;
	public static final int EXPLORER_INDEX = 6;
	public static final int DEFEND_BASE_RADIUS = 23;

	private static XVR xvr = XVR.getInstance();

	private static int _counter;


	public static void act() {

		ArrayList<Unit> workers = xvr.layUnitsOfType(UnitManager.WORKER);
		_counter = 0;
		for (Unit worker : workers) {
			if (_counter != EXPLORER_INDEX) {
				WorkerManager.act(worker);
			} else {
				Explorer.explore(worker);
			}

			_counter++;
		}
	}

	private static void defendBase(Unit worker) {

		if (_counter == GUY_TO_CHASE_OTHERS_INDEX) {
			Unit enemyWorkerNearMainBase = xvr.layEnemyWorkerTrongBanKinh(38, xvr.layCanCuGoc());
			UnitsActions.tanCongUnitDich(worker, enemyWorkerNearMainBase);
			return;
		}

		Unit enemyToFight = xvr.layDichThuGanNhatTrongBanKinh(xvr.layCanCuGoc(), DEFEND_BASE_RADIUS);
		if (enemyToFight == null) {
			return;
		}

		boolean isEnemyWorker = enemyToFight.isWorker();
		double distToEnemy = worker.distanceTo(enemyToFight);
		UnitType type = enemyToFight.getType();
		boolean isCriticalUnit = type.isLurker() || type.isTank() || type.isReaver();


		if (!isEnemyWorker && !enemyToFight.getType().isZergling()) {
			int numberOfEnemies = xvr.layUnitsDichTrongBanKinh(8, worker).size();
			if (isCriticalUnit || numberOfEnemies > 2) {
				Unit safeCannon = xvr.layUnitOfTypeGanNhat(UnitTypes.Protoss_Photon_Cannon,
						xvr.layCanCuMoiNhat());
				if (safeCannon != null) {
					UnitsActions.diChuyen(worker, safeCannon);
					return;
				} else {
					UnitsActions.diChuyenKhoiUnit(worker, enemyToFight, 5);
					return;
				}
			}
		}

		boolean shouldThisWorkerConsiderAttack = distToEnemy > 0 && distToEnemy < 17
				&& !worker.isAttacking() && enemyToFight.isDetected();
		boolean isTargetDangerous = !isEnemyWorker
				|| (isEnemyWorker && (enemyToFight.isConstructing()));
		boolean isTargetExtremelyDangerous = isEnemyWorker && enemyToFight.isConstructing()
				&& distToEnemy < 22;
		boolean isEnemyWorkerAttackingUs = isEnemyWorker && enemyToFight.isAttacking()
				&& distToEnemy <= 2;
		if ((shouldThisWorkerConsiderAttack && (isTargetDangerous || isEnemyWorkerAttackingUs) || isTargetExtremelyDangerous)
				&& distToEnemy < DEFEND_BASE_RADIUS) {
		UnitsActions.tanCong(worker, enemyToFight);
			return;
		}
		
		Unit enemyBuildingNearBase = xvr.layUnitGanNhatTuList(xvr.layCanCuGoc(),
				xvr.layCongTrinhDoiThu());
		if (enemyBuildingNearBase != null) {
			double distToBuilding = xvr.layKhoangCachGiua(xvr.layCanCuGoc(),
					enemyBuildingNearBase);
			if (distToBuilding > 0 && distToBuilding <= DEFEND_BASE_RADIUS
					&& enemyBuildingNearBase.getType().isBuilding()) {
				Debug.message(xvr, "Attack building: " + enemyBuildingNearBase.getName());
				UnitsActions.tanCongUnitDich(worker, enemyBuildingNearBase);
				return;
			}
		}
	}

	public static void act(Unit unit) {
		if (unit.equals(Explorer.getExplorer())) {
			return;
		}

		defendBase(unit);

		if (unit.isAttacking() && unit.distanceTo(xvr.layCanCuGoc()) < 17) {
			return;
		}

		if (unit.isAttacking() && unit.distanceTo(xvr.layCanCuGoc()) < 17) {
			return;
		}

		int distToMainBase = xvr.layKhoangCachSimple(unit, xvr.layCanCuGoc());
		if (unit.isAttacking()
				&& distToMainBase >= 7
				|| (unit.isConstructing() && unit.getShields() < 20 && StrengthEvaluator
						.isStrengthRatioCriticalFor(unit))) {
			UnitsActions.diChuyen(unit, xvr.layCanCuGoc());
			return;
		}

		if (unit.isUnderAttack()) {

			Unit nearestEnemy = xvr.layUnitGanNhatTuList(unit, xvr.getBwapi().getEnemyUnits());
			if (nearestEnemy != null) {
				if (xvr.layKhoangCachSimple(unit, xvr.layCanCuGoc()) <= 9 && !unit.isConstructing()) {
					UnitsActions.tanCongUnitDich(unit, nearestEnemy);
					return;
				}
			}

			MapPoint goTo = null;

			Unit defensiveBuildings = xvr.layUnitOfTypeGanNhat(UnitTypes.Protoss_Photon_Cannon,
					unit);
			if (defensiveBuildings != null) {
				goTo = defensiveBuildings;
			} else {
				goTo = xvr.layCanCuGoc();
			}

			if (goTo != null) {
				if (xvr.layKhoangCachSimple(unit, goTo) >= 15) {
					UnitsActions.diChuyen(unit, goTo.getX(), goTo.getY());
				} else {
					UnitsActions.diChuyen(unit, goTo.getX() + 5 - RUtilities.rand(0, 12), goTo.getY()
							+ 5 - RUtilities.rand(0, 12));
					UnitsActions.hoTro(unit, false);
				}
			}
		}

		// Act with idle worker
		if (unit.isIdle() && !unit.isGatheringGas() && !unit.isGatheringMinerals()
				&& !unit.isAttacking()) {

			// Find the nearest base for this SCV
			Unit nearestBase = ProtossNexus.getNearestBaseForUnit(unit);

			// If base exists try to gather resources
			if (nearestBase != null) {
				gatherResources(unit, nearestBase);
				return;
			}
		}

		// Act with unit that is possibly stuck e.g. by just built Protoss
		// building, yeah it happens this shit.
		else if (unit.isConstructing() && !unit.isMoving()) {
			UnitsActions.diChuyen(unit, ProtossNexus.getNearestBaseForUnit(unit));
			return;
		}

		// // If unit is building something check if there's no duplicate
		// // constructions going on
		// else if (unit.isConstructing()) {
		// Constructing.removeDuplicateConstructionsPending(unit);
		// }
	}

	public static void gatherResources(Unit worker, Unit nearestBase) {
		boolean existsAssimilatorNearBase = ProtossNexus
				.isExistingCompletedAssimilatorNearBase(nearestBase);

		// if (UnitCounter.getNumberOfUnits(UnitTypes.Protoss_Assimilator) > 0)
		// {
		// System.out.println("ASSIM " + nearestBase.toStringLocation() + ": "
		// + existsAssimilatorNearBase + " "
		// + ProtossNexus.getNumberofGasGatherersForBase(nearestBase));
		// }
		if (existsAssimilatorNearBase
				&& ProtossNexus.getNumberofGasGatherersForBase(nearestBase) < ProtossNexus.WORKERS_PER_GEYSER) {
			gatherGas(worker, nearestBase);
		} else {
			gatherMinerals(worker, nearestBase);
		}
	}

	private static void gatherGas(Unit worker, Unit base) {
		Unit onGeyser = xvr.layUnitOfTypeGanNhat(UnitTypes.Protoss_Assimilator, base);
		if (onGeyser != null) {
			xvr.getBwapi().rightClick(worker.getID(), onGeyser.getID());
		}
	}

	private static void gatherMinerals(Unit gathererToAssign, Unit nearestBase) {
		Unit mineral = getOptimalMineralForGatherer(gathererToAssign, nearestBase);
		if (mineral != null) {
			xvr.getBwapi().rightClick(gathererToAssign.getID(), mineral.getID());
		}
	}

	public static void forceGatherMinerals(Unit gathererToAssign, Unit mineral) {
		if (gathererToAssign.isCarryingMinerals()) {
			Unit nearBase = ProtossNexus.getNearestBaseForUnit(gathererToAssign);
			xvr.getBwapi().rightClick(gathererToAssign.getID(), nearBase.getID());
			return;
		} else if (gathererToAssign.isCarryingGas()) {
			Unit nearBase = ProtossNexus.getNearestBaseForUnit(gathererToAssign);
			xvr.getBwapi().rightClick(gathererToAssign.getID(), nearBase.getID());
			return;
		}

		if (mineral != null) {
			xvr.getBwapi().rightClick(gathererToAssign.getID(), mineral.getID());
		}
	}

	public static void forceGatherGas(Unit gathererToAssign, Unit nearestBase) {
		Unit onGeyser = ProtossNexus.getExistingCompletedAssimilatorNearBase(nearestBase);

		if (gathererToAssign.isCarryingMinerals()) {
			Unit nearBase = ProtossNexus.getNearestBaseForUnit(gathererToAssign);
			xvr.getBwapi().rightClick(gathererToAssign.getID(), nearBase.getID());
			return;
		} else if (gathererToAssign.isCarryingGas()) {
			Unit nearBase = ProtossNexus.getNearestBaseForUnit(gathererToAssign);
			xvr.getBwapi().rightClick(gathererToAssign.getID(), nearBase.getID());
			return;
		}

		if (onGeyser != null) {
			xvr.getBwapi().rightClick(gathererToAssign.getID(), onGeyser.getID());
		}
	}

	private static Unit getOptimalMineralForGatherer(Unit gathererToAssign, Unit nearestBase) {

		// Get the minerals that are closes to the base.
		ArrayList<Unit> minerals = ProtossNexus.getMineralsNearBase(nearestBase);
		int counter = 0;
		while (minerals.isEmpty()) {
			minerals = ProtossNexus.getMineralsNearBase(nearestBase, 15 + 10 * counter++);
		}

		// if (minerals.isEmpty()) {
		// // minerals = xvr.getMineralsUnits();
		// minerals = xvr
		// .getUnitsInRadius(nearestBase, 17 + (UnitCounter
		// .getNumberOfUnits(UnitManager.BASE) - 1) * 13, xvr
		// .getMineralsUnits());
		// }

		// Get workers
		ArrayList<Unit> workers = ProtossNexus.getWorkersNearBase(nearestBase);

		// Build mapping of number of worker to mineral
		HashMap<Unit, Integer> workersAtMineral = new HashMap<Unit, Integer>();
		for (Unit worker : workers) {
			// System.out.println();
			// System.out.println("scv.getTargetUnitID() = " +
			// scv.getTargetUnitID());
			// System.out.println("scv.getOrderTargetID() = " +
			// scv.getOrderTargetID());
			// System.out.println("scv.isGatheringMinerals() = " +
			// scv.isGatheringMinerals());
			// System.out.println("scv.getLastCommand() = " +
			// scv.getLastCommand());
			if (worker.isGatheringMinerals()) {
				Unit mineral = Unit.getByID(worker.getTargetUnitID());
				// System.out.println(mineral);
				// }
				// if (scv.isGatheringMinerals()) {

				if (workersAtMineral.containsKey(mineral)) {
					workersAtMineral.put(mineral, workersAtMineral.get(mineral) + 1);
				} else {
					workersAtMineral.put(mineral, 1);
				}
			}
		}

		// Get minimal value of gatherers assigned to one mineral
		int minimumGatherersAssigned = workersAtMineral.isEmpty() ? 0 : 9999;
		for (Integer value : workersAtMineral.values()) {
			if (minimumGatherersAssigned > value) {
				minimumGatherersAssigned = value;
			}
		}

		// Get the nearest mineral which has minimumGatherersAssigned
		Collections.shuffle(minerals);
		for (Unit mineral : minerals) {
			if (!workersAtMineral.containsKey(mineral)
					|| workersAtMineral.get(mineral) <= minimumGatherersAssigned) {
				return mineral;
			}
		}
		return minerals.isEmpty() ? null : (Unit) RUtilities.getRandomListElement(minerals);
	}

	public static Unit findNearestWorkerTo(int x, int y) {
		Unit base = xvr.layUnitOfTypeGanNhat(UnitManager.BASE, x, y);
		if (base == null) {
			return null;
		}

		// return xvr.layUnitOfTypeGanNhat(UnitTypes.Protoss_SCV,
		// xvr.layCanCuGoc()());

		double nearestDistance = 999999;
		Unit nearestUnit = null;

		for (Unit otherUnit : xvr.layUnitsOfType(UnitManager.WORKER)) {
			if (!otherUnit.isCompleted()
					|| (!otherUnit.isGatheringMinerals() && !otherUnit.isGatheringGas())
					|| otherUnit.isConstructing()) {
				continue;
			}

			double distance = xvr.layKhoangCachGiua(otherUnit, base);
			if (distance < nearestDistance) {
				nearestDistance = distance;
				nearestUnit = otherUnit;
			}
		}

		return nearestUnit;
	}

	public static Unit findNearestWorkerTo(Unit building) {
		return findNearestWorkerTo(building.getX(), building.getY());
	}

	public static Unit findNearestRepairerTo(Unit unit) {
		double nearestDistance = 999999;
		Unit nearestUnit = null;

		for (Unit otherUnit : xvr.layUnitsOfType(UnitManager.WORKER)) {
			if (!otherUnit.isCompleted() || otherUnit.isRepairing() || otherUnit.isConstructing()) {
				continue;
			}

			double distance = xvr.layKhoangCachGiua(otherUnit, unit);
			if (distance < nearestDistance) {
				nearestDistance = distance;
				nearestUnit = otherUnit;
			}
		}

		return nearestUnit;
	}

}

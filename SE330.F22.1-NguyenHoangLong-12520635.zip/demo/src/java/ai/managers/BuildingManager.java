package ai.managers;

import jnibwapi.model.Unit;
import jnibwapi.types.UnitType;
import ai.core.XVR;
import ai.handling.units.UnitsActions;

public class BuildingManager {

	private static XVR xvr = XVR.getInstance();

	public static void act(Unit building) {
		UnitType buildingType = UnitType.getUnitTypeByID(building.getTypeID());
		if (buildingType == null) { 
		}

		if (building.isUnderAttack()) {
			UnitsActions.hoTro(building, true);
		}

		checkIfShouldCancelConstruction(building, buildingType);
	}

	private static void checkIfShouldCancelConstruction(Unit building,
			UnitType buildingType) {
		if (building.isUnderAttack() && (!building.isCompleted())) {
			System.out.println("BUILDING ATTACKED");
			boolean shouldCancelConstruction = false;
			if (building.getHitPoints() < 0.4 * buildingType.getMaxHitPoints()) {
				shouldCancelConstruction = true;
			}

			if (buildingType.isBase()) {

				shouldCancelConstruction = true;
			}

			if (shouldCancelConstruction) {
				System.out.println("TEST CANCEL BASE BUT WILL PROBBALY FAIL");
				xvr.getBwapi().cancelConstruction(building.getID());
			}
		}
	}
	
}

package ai.managers;

import jnibwapi.model.Unit;
import jnibwapi.types.TechType.TechTypes;
import jnibwapi.types.UnitType.UnitTypes;
import jnibwapi.types.UpgradeType.UpgradeTypes;
import ai.core.XVR;
import ai.handling.units.UnitCounter;
import ai.protoss.ProtossArbiterTribunal;
import ai.protoss.ProtossCitadelOfAdun;
import ai.protoss.ProtossCyberneticsCore;
import ai.protoss.ProtossForge;
import ai.protoss.ProtossObservatory;
import ai.protoss.ProtossRoboticsSupportBay;
import ai.protoss.ProtossTemplarArchives;

public class TechnologyManager {

	public static final TechTypes HALLUCINATION = TechTypes.Hallucination;
	public static final TechTypes PSIONIC_STORM = TechTypes.Psionic_Storm;
	public static final TechTypes STASIS_FIELD = TechTypes.Stasis_Field;

	private static XVR xvr = XVR.getInstance();

	public static void act() {
		UpgradeTypes upgrade;
		TechTypes technology;

		int zealots = UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Zealot);
		int dragoons = UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Dragoon);
		int infantry = zealots + dragoons;

		upgrade = UpgradeTypes.Protoss_Plasma_Shields;
		if ((infantry >= 8 || xvr.duTaiNguyen(300, 300))
				&& isUpgradePossible(upgrade)) {
			tryToUpgrade(ProtossForge.getOneNotBusy(), upgrade);
		}

		// Leg enhancement
		upgrade = UpgradeTypes.Leg_Enhancements;
		if (zealots >= 5 && isUpgradePossible(upgrade)) {
			tryToUpgrade(ProtossCitadelOfAdun.getOneNotBusy(), upgrade);
		}

		// Singularity charge
		upgrade = UpgradeTypes.Singularity_Charge;
		if (dragoons >= 2 && isUpgradePossible(upgrade)) {
			tryToUpgrade(ProtossCyberneticsCore.getOneNotBusy(), upgrade);
		}

		// Protoss ground weapon
		upgrade = UpgradeTypes.Protoss_Ground_Weapons;
		if (zealots >= 4 && xvr.duTaiNguyen(150 * getTechLevelOf(upgrade), 150)
				&& isUpgradePossible(upgrade)) {
			tryToUpgrade(ProtossForge.getOneNotBusy(), upgrade);
		}

		int gasInfantry = UnitCounter
				.laySoLuongUnits(UnitTypes.Protoss_Dragoon)
				+ UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Dark_Templar);

		// Observer speed
		upgrade = UpgradeTypes.Gravitic_Boosters;
		if (gasInfantry >= 9
				&& xvr.duTaiNguyen(400)
				&& isUpgradePossible(upgrade)
				&& UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Observer) >= 2) {
			tryToUpgrade(ProtossObservatory.getOneNotBusy(), upgrade);
		}

		technology = PSIONIC_STORM;
		if (gasInfantry >= 10
				&& UnitCounter
						.coNhaHoanThanh(UnitTypes.Protoss_Templar_Archives)
				&& xvr.duTaiNguyen(200) && isResearchPossible(technology)) {

			tryToResearch(ProtossTemplarArchives.getOneNotBusy(), technology);
		}

		if (UnitCounter.laySoLuongUnits(UnitManager.BASE) <= 1
				|| gasInfantry < 8) {
			return;
		}

		// Observer range
		upgrade = UpgradeTypes.Sensor_Array;
		if (infantry >= 15 && xvr.duTaiNguyen(500) && isUpgradePossible(upgrade)) {
			tryToUpgrade(ProtossObservatory.getOneNotBusy(), upgrade);
		}

		// Protoss ground armor
		upgrade = UpgradeTypes.Protoss_Ground_Armor;
		if (zealots >= 5 && xvr.duTaiNguyen(150 * getTechLevelOf(upgrade), 150)
				&& isUpgradePossible(upgrade)) {
			tryToUpgrade(ProtossForge.getOneNotBusy(), upgrade);
		}

		// Scarab damage
		upgrade = UpgradeTypes.Scarab_Damage;
		if (UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Reaver) >= 2
				&& UnitCounter.coNha(ProtossRoboticsSupportBay
						.getBuildingType()) && isUpgradePossible(upgrade)) {
			tryToUpgrade(ProtossRoboticsSupportBay.getOneNotBusy(), upgrade);
		}

		// Protoss stasis field
		technology = STASIS_FIELD;
		if (UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Arbiter) >= 1
				&& UnitCounter
						.coNhaHoanThanh(UnitTypes.Protoss_Arbiter_Tribunal)
				&& xvr.duTaiNguyen(200) && isResearchPossible(technology)) {
			tryToResearch(ProtossArbiterTribunal.getOneNotBusy(), technology);
		}
	}

	private static int getTechLevelOf(UpgradeTypes technology) {
		return XVR.NGUOICHOI.upgradeLevel(technology.getID());
	}

	private static boolean isUpgradePossible(UpgradeTypes upgrade) {
		return isNotUpgraded(upgrade) && canUpgrade(upgrade);
	}

	private static boolean isNotUpgraded(UpgradeTypes tech) {
		return !XVR.NGUOICHOI.hasResearched(tech.ordinal());
	}

	private static boolean canUpgrade(UpgradeTypes tech) {
		return xvr.getBwapi().canUpgrade(tech.ordinal());
	}

	private static boolean isResearchPossible(TechTypes technology) {
		return isNotResearched(technology) && canResearch(technology);
	}

	private static boolean isNotResearched(TechTypes tech) {
		return !XVR.NGUOICHOI.hasResearched(tech.ordinal());
	}

	private static boolean canResearch(TechTypes tech) {
		return xvr.getBwapi().canResearch(tech.ordinal());
	}

	private static void tryToUpgrade(Unit building, UpgradeTypes upgrade) {
		if (building != null) {
			// Debug.message(xvr, "Researching " + upgrade.toString());
			xvr.getBwapi().upgrade(building.getID(), upgrade.ordinal());
			// if (!building.isBuildingNotBusy()) {
			// knownTechs.put(upgrade, true);
			// }
		}
	}

	private static void tryToResearch(Unit building, TechTypes technology) {
		if (building != null) {
			// Debug.message(xvr, "Researching " + technology.toString());
			xvr.getBwapi().research(building.getID(), technology.ordinal());
			// if (!building.isBuildingNotBusy()) {
			// knownTechs.put(upgrade, true);
			// }
		}
	}

	public static boolean isResearched(TechTypes tech) {
		return !isNotResearched(tech);
	}

}

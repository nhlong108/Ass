package ai.protoss;

import java.util.ArrayList;

import jnibwapi.model.Unit;
import ai.core.XVR;
import ai.handling.army.TargetHandling;
import ai.handling.units.UnitsActions;
import ai.managers.TechnologyManager;

public class ProtossArbiter {

	private static XVR xvr = XVR.getInstance();

	public static void act(Unit unit) {

		if (unit.getShields() <= 15) {

			UnitsActions.actKhiMauVaGiapThap(unit, true);
			return;
		}

		if (UnitsActions.chayKhoiQuanOrTruDich(
				unit, false, true, true) || unit.isUnderAttack()) {
			return;
		}

		tryUsingStasisField(unit);
	}

	private static void tryUsingStasisField(Unit unit) {
		if (unit.getEnergy() >= 100) {
			Unit target = null;

			// Try to find top priority target.
			ArrayList<Unit> enemies = TargetHandling.getTopPriorityTargetsNear(
					unit, 20);

			if (!enemies.isEmpty()) {
				for (Unit possibleTarget : enemies) {
					if (!possibleTarget.isStasised()
							&& xvr.demUnitsTrongBanKinh(possibleTarget, 3, true) == 0) {
						target = possibleTarget;
						break;
					}
				}
			}

			if (!enemies.isEmpty()) {
				enemies = xvr.layUnitsTrongBanKinh(unit, 15,
						xvr.layArmyUnitDoiThu());
				for (Unit possibleTarget : enemies) {
					if (!possibleTarget.isStasised()) {
						target = possibleTarget;
						break;
					}
				}
			}

			if (target != null) {
				UnitsActions.useTech(unit, TechnologyManager.STASIS_FIELD,
						target);
			}
		}
	}

}

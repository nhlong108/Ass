package ai.protoss;

import java.util.ArrayList;

import jnibwapi.model.Unit;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.constructing.Constructing;
import ai.handling.constructing.ShouldBuildCache;
import ai.handling.units.UnitCounter;
import ai.managers.BotStrategyManager;
import ai.managers.UnitManager;

public class ProtossGateway {

	public static UnitTypes ZEALOT = UnitTypes.Protoss_Zealot;
	public static UnitTypes DRAGOON = UnitTypes.Protoss_Dragoon;
	public static UnitTypes DARK_TEMPLAR = UnitTypes.Protoss_Dark_Templar;
	public static UnitTypes HIGH_TEMPLAR = UnitTypes.Protoss_High_Templar;

	private static boolean isPlanAntiAirActive = false;

	public static int MIN_UNITS_FOR_DIFF_BUILDING = 20;

	public static boolean LIMIT_ZEALOTS = false;

	private static int zealotBuildRatio = 5;
	private static int dragoonBuildRatio = 50;
	private static int darkTemplarBuildRatio = 30;

	private static final int MINIMAL_HIGH_TEMPLARS = 2;

	private static final UnitTypes buildingType = UnitTypes.Protoss_Gateway;
	private static XVR xvr = XVR.getInstance();

	public static boolean shouldBuild() {
		if (UnitCounter.coPylonHoanThanh()) {
			int gateways = UnitCounter.laySoLuongUnits(buildingType);
			int bases = UnitCounter.laySoLuongUnitsHoanThanh(UnitManager.BASE);

			int raceBonus = XVR.doithuTerran() ? 1 : 0;
			if (ProtossNexus.shouldBuild() && gateways >= (1 + raceBonus + 2 * bases)) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
				return false;
			}

			if (BotStrategyManager.isExpandWithCannons()) {
				int cannons = UnitCounter
						.laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Photon_Cannon);
				if ((cannons >= ProtossPhotonCannon.MAX_CANNON_STACK || xvr.duTaiNguyen(300))
						&& gateways <= 2 && xvr.duTaiNguyen(155)) {
					ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
					return true;
				}
			}

			if (BotStrategyManager.isExpandWithGateways()) {
				if (gateways <= 3 && (isMajorityOfGatewaysTrainingUnits()) && xvr.duTaiNguyen(134)) {
					if (gateways < 2 || UnitCounter.LaySoLuongUnitsBoBinh() > 0) {
						ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
						return true;
					}
				} else {
					if (!UnitCounter.coNha(UnitTypes.Protoss_Cybernetics_Core)
							|| !UnitCounter.coNha(UnitTypes.Protoss_Citadel_of_Adun)) {
						ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
						return false;
					}
				}
			}

			if (bases <= 1) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
				return false;
			}

			if (gateways >= 3 && xvr.duTaiNguyen(140)) {
				if (isMajorityOfGatewaysTrainingUnits()) {
					ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
					return true;
				}
			}

			// 3 barracks or more
			if (gateways >= 3 && (gateways <= 5 || xvr.duTaiNguyen(520))) {
				if (isMajorityOfGatewaysTrainingUnits()) {
					ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
					return true;
				}
			}
			if (gateways >= 2 && bases >= 2
					&& UnitCounter.coNha(UnitTypes.Protoss_Observatory)
					&& UnitCounter.coNha(UnitTypes.Protoss_Citadel_of_Adun)) {
				int HQs = UnitCounter.laySoLuongUnits(UnitManager.BASE);
				if ((double) gateways / HQs <= 2 && xvr.duTaiNguyen(560)) {
					if (isMajorityOfGatewaysTrainingUnits()) {
						ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
						return true;
					}
				}
			}
		}

		if (xvr.duTaiNguyen(1500)) {
			if (isMajorityOfGatewaysTrainingUnits()) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
				return true;
			}
		}

		ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
		return false;
	}

	private static boolean isMajorityOfGatewaysTrainingUnits() {
		ArrayList<Unit> allObjects = xvr.layUnitsOfType(buildingType);
		int all = allObjects.size();
		int busy = 0;
		for (Unit gateway : allObjects) {
			if (gateway.isTraining()) {
				busy++;
			}
		}

		double threshold = (Math.min(0.8, 0.7 + all * 0.05));
		return ((double) busy / all) >= threshold || all <= 2;
	}

	public static ArrayList<Unit> getAllObjects() {
		return xvr.layUnitsOfTypeHoanThanh(buildingType);
	}

	public static void enemyIsProtoss() {
	}

	public static void enemyIsTerran() {
		darkTemplarBuildRatio /= 7;
	}

	public static void enemyIsZerg() {
	}

	public static void buildIfNecessary() {
		if (shouldBuild()) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			Constructing.construct(xvr, buildingType);
		}
		ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
	}

	public static void act(Unit barracks) {
		int[] buildingQueueDetails = Constructing.shouldBuildAnyBuilding();
		int freeMinerals = xvr.layKimCuong();
		int freeGas = xvr.layGas();
		if (buildingQueueDetails != null) {
			freeMinerals -= buildingQueueDetails[0];
			freeGas -= buildingQueueDetails[1];
		}

		boolean shouldAlwaysBuild = xvr.duTaiNguyen(100)
				&& UnitCounter.laySoLuongUnitsThamChien() <= MIN_UNITS_FOR_DIFF_BUILDING;
		if (shouldAlwaysBuild || buildingQueueDetails == null || freeMinerals >= 100) {
			if (barracks.getTrainingQueueSize() == 0) {
				xvr.buildUnit(barracks, defineUnitToBuild(freeMinerals, freeGas));
			}
		}
	}

	private static UnitTypes defineUnitToBuild(int freeMinerals, int freeGas) {
		int zealots = UnitCounter.laySoLuongUnits(ZEALOT);
		int forceFreeGas = 0;
		int darkTemplarGasBonus = 0;
		int dragoons = UnitCounter.laySoLuongUnits(DRAGOON);
		if (!UnitCounter.coNha(ProtossObservatory.getBuildingtype())) {
			forceFreeGas = Math.min(200, dragoons * 50);
			if (UnitCounter.laySoLuongUnits(DARK_TEMPLAR) < 2) {
				darkTemplarGasBonus = forceFreeGas;
			}
		}

		boolean dragoonResearched = UnitCounter
				.coNhaHoanThanh(UnitTypes.Protoss_Cybernetics_Core);
		boolean dragoonAllowed = dragoonResearched
				&& (freeMinerals >= 125 && (freeGas - forceFreeGas) >= 50);
		boolean darkTemplarAllowed = UnitCounter
				.coNhaHoanThanh(UnitTypes.Protoss_Templar_Archives)
				&& (freeMinerals >= 125 && (freeGas - forceFreeGas + darkTemplarGasBonus) >= 100);
		boolean highTemplarAllowed = darkTemplarAllowed
				&& (freeMinerals >= 50 && (freeGas - forceFreeGas) >= 200);

		UnitTypes typeToBuild = ZEALOT;

		double totalRatio = zealotBuildRatio + (dragoonAllowed ? dragoonBuildRatio : 0)
				+ (darkTemplarAllowed ? darkTemplarBuildRatio : 0);
		double totalInfantry = UnitCounter.LaySoLuongUnitsBoBinh() + 1;


		if (darkTemplarAllowed) {
			int darkTemplars = UnitCounter.laySoLuongUnits(DARK_TEMPLAR);
			int highTemplars = UnitCounter.laySoLuongUnits(HIGH_TEMPLAR);

			if (highTemplarAllowed
					&& ((darkTemplars >= 5 || darkTemplarBuildRatio < 10) && highTemplars < 2 || freeGas > 1000)) {
				return HIGH_TEMPLAR;
			}

			double darkTemplarPercent = (double) darkTemplars / totalInfantry;
			if (darkTemplarPercent < darkTemplarBuildRatio / totalRatio) {
				return DARK_TEMPLAR;
			}
		}

		if (dragoons < 3 && dragoonResearched && xvr.duTaiNguyen(125, 50)) {
			return DRAGOON;
		}
		if (dragoonAllowed) {
			double dragoonPercent = (double) dragoons / totalInfantry;
			if (dragoonPercent < dragoonBuildRatio / totalRatio) {
				return DRAGOON;
			}
		}

		// HIGH TEMPLAR
		if (highTemplarAllowed
				&& UnitCounter.laySoLuongUnits(HIGH_TEMPLAR) < MINIMAL_HIGH_TEMPLARS) {
			return HIGH_TEMPLAR;
		}

		// ZEALOT
		if (BotStrategyManager.isExpandWithCannons()) {
			if (zealots >= 3 && !xvr.duTaiNguyen(1000)) {
				return null;
			}
		}
		if (zealots >= 8 + dragoons) {
			return null;
		}

		double zealotPercent = zealots / totalInfantry;
		if (zealotPercent < zealotBuildRatio / totalRatio || LIMIT_ZEALOTS) {
			return ZEALOT;
		}

		return typeToBuild;
	}

	public static UnitTypes getBuildingType() {
		return buildingType;
	}

	public static void changePlanToAntiAir() {
		if (isPlanAntiAirActive) {
			return;
		}

		isPlanAntiAirActive = true;
		zealotBuildRatio = 10;
		dragoonBuildRatio = 70;
		darkTemplarBuildRatio = 10;
	}

	public static boolean isPlanAntiAirActive() {
		return isPlanAntiAirActive;
	}

}

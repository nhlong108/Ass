package ai.protoss;

import java.util.ArrayList;

import jnibwapi.model.ChokePoint;
import jnibwapi.model.Unit;
import jnibwapi.types.UnitType;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.constructing.Constructing;
import ai.handling.constructing.ShouldBuildCache;
import ai.handling.map.MapExploration;
import ai.handling.map.MapPoint;
import ai.handling.map.MapPointInstance;
import ai.handling.units.UnitCounter;
import ai.managers.BotStrategyManager;
import ai.managers.UnitManager;

public class ProtossPhotonCannon {

	private static final UnitTypes buildingType = UnitTypes.Protoss_Photon_Cannon;
	private static XVR xvr = XVR.getInstance();

	private static final double MAX_DIST_FROM_CHOKE_POINT_MODIFIER = 1.8;
	public static final int MAX_CANNON_STACK = 5;

	private static MapPoint _placeToReinforceWithCannon = null;

	public static boolean shouldBuild() {
		if (UnitCounter.coNha(UnitTypes.Protoss_Forge)) {
			int maxCannonStack = calculateMaxCannonStack();

			int cannons = UnitCounter.laySoLuongUnits(buildingType);
			int pylons = UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Pylon);

			if (pylons == 1) {
				if (!xvr.duTaiNguyen(300)) {
					return false;
				}
			}

			if (shouldBuildNearMainNexus()) {
				return true;
			}

			if (cannons <= maxCannonStack && ProtossPylon.calculateExistingPylonsStrength() >= 1.35
					&& calculateExistingCannonsStrength() < maxCannonStack) {
				return true;
			}

			for (MapPoint base : getPlacesToReinforce()) {
				if (UnitCounter.laySoLuongUnits(UnitManager.BASE) == 1) {
					if (shouldBuildFor((MapPoint) base)) {
						return true;
					}
				}
			}

			MapPoint tileForNextBase = ProtossNexus.getTileForNextBase(false);
			if (shouldBuildFor(tileForNextBase)) {
				if (xvr.demLoaiUnitsTrongBanKinh(UnitTypes.Protoss_Pylon, 12, tileForNextBase,
						true) > 0) {
					return true;
				}
			}
		}
		return false;
	}

	private static boolean shouldBuildNearMainNexus() {
		int cannons = UnitCounter.laySoLuongUnits(buildingType);
		int cannonsNearMainBase = xvr.demLoaiUnitsTrongBanKinh(
				UnitTypes.Protoss_Photon_Cannon, 7, xvr.layCanCuGoc(), true);
		if (cannons >= ProtossPhotonCannon.MAX_CANNON_STACK
				&& UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Gateway) >= 2
				&& cannonsNearMainBase == 0) {
			return true;
		}
		return false;
	}

	private static double calculateExistingCannonsStrength() {
		double result = 0;
		UnitType type = UnitType.getUnitTypeByID(UnitTypes.Protoss_Photon_Cannon.ordinal());
		int maxHitPoints = type.getMaxShields() + type.getMaxHitPoints();

		for (Unit cannon : xvr.layUnitsOfType(buildingType)) {
			double cannonTotalHP = (double) (cannon.getShields() + cannon.getHitPoints())
					/ maxHitPoints;
			if (!cannon.isCompleted()) {
				cannonTotalHP = Math.sqrt(cannonTotalHP);
			}
			result += cannonTotalHP;
		}

		return result;
	}

	private static boolean shouldBuildFor(MapPoint base) {
		if (base == null) {
			return false;
		}
		if (base.equals(xvr.layCanCuGoc())) {
			return false;
		}

		ChokePoint chokePoint = MapExploration.getImportantChokePointNear(base);

		if (shouldBuildFor(chokePoint)) {
			_placeToReinforceWithCannon = chokePoint;
			return true;
		} else {
			return false;
		}
	}

	public static void buildIfNecessary() {
		if (shouldBuild()) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			for (MapPoint base : getPlacesToReinforce()) {
				tryToBuildFor(base);
			}
		}
		ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
	}

	private static ArrayList<MapPoint> getPlacesToReinforce() {
		ArrayList<MapPoint> placesToReinforce = new ArrayList<>();

		placesToReinforce.add(ProtossNexus.getSecondBaseLocation());

		ArrayList<Unit> bases = ProtossNexus.getBases();
		for (int i = bases.size() - 1; i >= 0; i--) {
			Unit base = bases.get(i);
			ChokePoint chokePoint = MapExploration.getImportantChokePointNear(base);
			placesToReinforce.add(chokePoint);
		}

		return placesToReinforce;
	}

	private static void tryToBuildFor(MapPoint base) {
		if (shouldBuildFor(base)) {
			Constructing.construct(xvr, buildingType);
		}
	}

	private static boolean shouldBuildFor(ChokePoint chokePoint) {
		if (chokePoint.isDisabled()) {
			return false;
		}

		int numberOfCannonsNearby = calculateCannonsNearby(chokePoint);

		int bonus = 0;
		if (xvr.layKhoangCachGiua(ProtossNexus.getSecondBaseLocation(), chokePoint) < 14) {
			bonus = 1;
		}

		if (numberOfCannonsNearby < calculateMaxCannonStack() + bonus) {
			return true;
		}

		else {
			return false;
		}
	}

	public static int calculateMaxCannonStack() {
		return BotStrategyManager.isExpandWithCannons() ? MAX_CANNON_STACK : (UnitCounter
				.laySoLuongUnitsThamChien() >= 8 ? 1 : MAX_CANNON_STACK);
	}

	private static int calculateCannonsNearby(MapPoint mapPoint) {
		int radius;

		ChokePoint choke = null;
		if (mapPoint instanceof ChokePoint) {
			choke = (ChokePoint) mapPoint;
			radius = (int) choke.getRadius() / 32;
		} else {
			radius = 8;
		}

		int searchInDistance = (int) (1.5 * MAX_DIST_FROM_CHOKE_POINT_MODIFIER * radius);
		if (searchInDistance < 9) {
			searchInDistance = 9;
		}

		ArrayList<Unit> cannonsNearby = xvr.layUnitsTrongBanKinh(buildingType,
				searchInDistance, mapPoint, true);

		double result = 0;
		double maxCannonHP = 200;
		for (Unit cannon : cannonsNearby) {

			result += (cannon.getHitPoints() + cannon.getShields()) / maxCannonHP;
		}

		return (int) result;
	}

	private static MapPoint findProperBuildTile(MapPoint mapPoint, boolean requiresPower) {

		MapPointInstance initialBuildTile = new MapPointInstance(mapPoint.getX(), mapPoint.getY());

		Unit workerUnit = xvr.layWorkerNgauNhien();

		int minimumDistance = 1;
		int numberOfCannonsNearby = calculateCannonsNearby(mapPoint);
		if (mapPoint instanceof ChokePoint) {
			ChokePoint choke = (ChokePoint) mapPoint;
			if (choke.getRadius() / 32 >= 8) {
				minimumDistance = 3;
			}
		}
		int maximumDistance = minimumDistance + (10 / Math.max(1, numberOfCannonsNearby));

		MapPoint properBuildTile = Constructing.getLegitTileToBuildNear(workerUnit, buildingType,
				initialBuildTile, minimumDistance, maximumDistance, requiresPower);

		return properBuildTile;
	}

	public static MapPoint findTileForCannon() {
		MapPoint tileForCannon = null;

		if (shouldBuildNearMainNexus()) {
			tileForCannon = findBuildTileNearMainNexus();
		} else {
			if (_placeToReinforceWithCannon == null) {
				_placeToReinforceWithCannon = MapExploration
						.getNearestChokePointFor(getInitialPlaceToReinforce());
			}

			tileForCannon = findProperBuildTile(_placeToReinforceWithCannon, true);
		}
		if (tileForCannon != null) {
			return tileForCannon;
		}

		MapPoint tileForNextBase = ProtossNexus.getTileForNextBase(false);
		if (shouldBuildFor(tileForNextBase)) {
			tileForCannon = findProperBuildTile(tileForNextBase, true);
			if (tileForCannon != null) {
				return tileForCannon;
			}
		}

		return null;
	}

	private static MapPoint findBuildTileNearMainNexus() {
		Unit firstBase = xvr.layCanCuGoc();
		MapPoint point = firstBase;

		MapPoint tileForCannon = Constructing.getLegitTileToBuildNear(xvr.layWorkerNgauNhien(),
				buildingType, point, 0, 10, true);


		if (tileForCannon != null) {
			return tileForCannon;
		}
		return null;
	}

	private static MapPoint getInitialPlaceToReinforce() {
		return ProtossNexus.getSecondBaseLocation();
	}

	public static UnitTypes getBuildingType() {
		return buildingType;
	}

}

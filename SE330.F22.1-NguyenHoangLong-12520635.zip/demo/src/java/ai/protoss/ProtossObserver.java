package ai.protoss;

import java.util.ArrayList;
import java.util.HashMap;

import jnibwapi.model.Unit;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.army.ArmyPlacing;
import ai.handling.map.MapPoint;
import ai.handling.map.MapPointInstance;
import ai.handling.units.UnitsActions;
import ai.handling.units.UnitCounter;
import ai.managers.UnitManager;

public class ProtossObserver {

	private static final int MIN_DIST_BETWEEN_OBSERVERS = 6;

	private static final UnitTypes OBSERVER = UnitTypes.Protoss_Observer;
	private static XVR xvr = XVR.getInstance();

	private static final HashMap<Unit, MapPoint> observersToPoints = new HashMap<Unit, MapPoint>();

	public static void tryToScanPoint(int x, int y) {
		Unit observer = getNearestFreeObserverTo(x, y);
		if (observer != null) {
			assignObserverToScan(observer, new MapPointInstance(x, y));
			UnitsActions.diChuyen(observer, x, y);
		}
	}

	public static void tryToScanUnit(Unit enemy) {
		if (enemy == null || enemy.getType().isTerranMine()
				|| enemy.getType().isObserver()) {
			return;
		}

		Unit observer = getNearestFreeObserverTo(enemy);
		if (observer != null) {

			if (!isEnemyUnitAlreadyBeingScanned(enemy)) {
				assignObserverToScan(observer, enemy);
				UnitsActions.diChuyen(observer, enemy);
			}
		}
	}

	private static void markEnemyUnitAsNoLongerScanned(Unit enemy) {

		Unit observerKey = null;
		for (Unit observer : observersToPoints.keySet()) {
			if (observersToPoints.get(observer).equals(enemy)) {
				observerKey = observer;
				break;
			}
		}

		observersToPoints.remove(observerKey);
	}

	private static boolean isEnemyUnitAlreadyBeingScanned(Unit enemy) {
		return observersToPoints.values().contains(enemy);
	}

	private static void assignObserverToScan(Unit observer,
			MapPoint pointOrUnitToScan) {
		observersToPoints.put(observer, pointOrUnitToScan);
	}

	private static Unit getNearestFreeObserverTo(int x, int y) {
		return getNearestFreeObserverTo(new MapPointInstance(x, y));
	}

	private static Unit getNearestFreeObserverTo(
			MapPoint sortByDistanceToThisPoint) {
		for (Unit observer : xvr.layUnitsTrongBanKinh(sortByDistanceToThisPoint,
				300, xvr.layUnitsOfType(OBSERVER))) {
			if (observer.isCompleted()
					&& isObserverFreeFromScanMissions(observer)) {
				return observer;
			}
		}
		return null;
	}

	private static boolean isObserverFreeFromScanMissions(Unit observer) {
		return !observersToPoints.containsKey(observer);
	}

	public static void hiddenUnitDetected(Unit unit) {
		if (unit.isEnemy() && (unit.isHidden() || !unit.isDetected())) {
			if (UnitCounter.laySoLuongUnits(OBSERVER) > 0) {
				tryToScanUnit(unit);
			}
		}
	}

	public static void act(Unit observer) {

		if (UnitsActions.chayKhoiQuanOrTruDich(
				observer, false, false, true)) {
			return;
		}
		if (isObserverSupposedToScanSomePoint(observer)) {
			actWhenScanningSomePoint(observer);
		} else if (isIndividualTaskAssigned(observer)) {
			actIndividual(observer);
		} else {
			actNormally(observer);
		}

		trySpreadingOutIfObserversTooClose(observer);
	}

	private static void actWhenScanningSomePoint(Unit observer) {
		MapPoint mapPointToScan = observersToPoints.get(observer);

		if (mapPointToScan instanceof Unit) {
			Unit enemyToScan = (Unit) mapPointToScan;
			if (!enemyToScan.isHidden()
					|| xvr.layKhoangCachSimple(observer, enemyToScan) <= 3) {
				markEnemyUnitAsNoLongerScanned(enemyToScan);
				return;
			}
		}

		UnitsActions.diChuyen(observer, mapPointToScan);
	}

	private static boolean isObserverSupposedToScanSomePoint(Unit observer) {
		return observersToPoints.containsKey(observer);
	}

	private static void trySpreadingOutIfObserversTooClose(Unit observer) {
		ArrayList<Unit> observersNearby = xvr.layUnitsTrongBanKinh(
				OBSERVER, MIN_DIST_BETWEEN_OBSERVERS, observer, true);
		observersNearby.remove(observer);

		if (!observersNearby.isEmpty()) {
			UnitsActions.diChuyenKhoiUnit(observer,
					observersNearby.get(0), MIN_DIST_BETWEEN_OBSERVERS);
		}
	}

	private static boolean isIndividualTaskAssigned(Unit observer) {
		return getIndexOfObserver(observer) <= 2;
	}

	private static int getIndexOfObserver(Unit observer) {
		return xvr.layUnitsOfType(OBSERVER).indexOf(observer);
	}

	private static void actNormally(Unit observer) {
		if (observer.isMoving()) {
			return;
		}

		tryProtectingNewestBaseIfMakesSense(observer);
	}

	private static void actIndividual(Unit observer) {
		int observerIndex = getIndexOfObserver(observer);

		ArrayList<Unit> zealots = xvr.layUnitsOfType(UnitTypes.Protoss_Zealot);

		if (observerIndex == 0) {
			Unit unit1 = null;
			if (zealots.size() > 2) {
				unit1 = zealots.get(2);
				UnitsActions.diChuyen(observer, unit1);
				return;
			}
		}

		else if (observerIndex == 1) {
			Unit unit1 = null;
			if (!zealots.isEmpty()) {
				unit1 = zealots.get(0);
				UnitsActions.diChuyen(observer, unit1);
				return;
			}
		} else if (observerIndex == 2) {
			Unit unit2 = null;
			ArrayList<Unit> dragoons = xvr
					.layUnitsOfType(UnitTypes.Protoss_Dragoon);
			if (!dragoons.isEmpty()) {
				unit2 = dragoons.get(0);
				UnitsActions.diChuyen(observer, unit2);
				return;
			} else if (!zealots.isEmpty()) {
				unit2 = zealots.get(zealots.size() - 1);
				UnitsActions.diChuyen(observer, unit2);
				return;
			}

		} else {
			UnitsActions.diChuyen(observer, ArmyPlacing.getArmyCenterPoint());
		}

		actNormally(observer);
	}


	private static void tryProtectingNewestBaseIfMakesSense(Unit observer) {

		Unit newestBase = UnitCounter.laySoLuongUnits(UnitManager.BASE) > 1 ? xvr
				.layCanCuMoiNhat() : null;
		if (newestBase != null) {

			int observersNearBase = xvr.laySoLuongQuanTrongBanKinh(
					newestBase.getX(), newestBase.getY(), 20,
					xvr.layUnitsOfType(OBSERVER));

			if (observersNearBase == 0) {
				UnitsActions.diChuyen(observer, newestBase);
			}

			else if (observersNearBase == 1) {
				Unit observerNearBase = xvr.layUnitOfTypeGanNhat(OBSERVER,
						newestBase);

				if (observer.equals(observerNearBase)) {

				} else {
					goToRandomChokePoint(observer);
				}
			}

			else {
				goToRandomChokePoint(observer);
			}
		}

		else {
			goToRandomChokePoint(observer);
		}
	}

	private static void goToRandomChokePoint(Unit observer) {
		UnitsActions.goToRandomChokePoint(observer);
	}

}

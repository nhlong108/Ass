package ai.protoss;

import java.util.ArrayList;
import java.util.HashMap;

import jnibwapi.model.BaseLocation;
import jnibwapi.model.Map;
import jnibwapi.model.Unit;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.constructing.Constructing;
import ai.handling.constructing.ShouldBuildCache;
import ai.handling.map.MapPoint;
import ai.handling.units.UnitCounter;
import ai.managers.BotStrategyManager;
import ai.managers.StrategyManager;
import ai.managers.UnitManager;
import ai.managers.WorkerManager;
import ai.utils.RUtilities;

public class ProtossNexus {

	private static XVR xvr = XVR.getInstance();

	public static final int MAX_WORKERS = 65;

	private static int MAX_DIST_OF_MINERAL_FROM_BASE = 12;
	private static final int ARMY_UNITS_PER_NEW_BASE = 10;
	private static final int MIN_WORKERS = 19;
	public static final int WORKERS_PER_GEYSER = 4;

	private static MapPoint _secondBase = null;
	private static MapPoint _cachedNextBaseTile = null;

	private static final UnitTypes buildingType = UnitTypes.Protoss_Nexus;

	public static void buildIfNecessary() {
		if (shouldBuild()) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			Constructing.construct(xvr, buildingType);
		}
		ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
	}

	public static boolean shouldBuild() {
		int bases = UnitCounter.laySoLuongUnits(buildingType);
		int gateways = UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Gateway);
		int battleUnits = UnitCounter.laySoLuongUnitsThamChien();

		if (xvr.duTaiNguyen(750)) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			return true;
		}

		if (xvr.getTimeSecond() >= 380 && bases == 1
				&& !Constructing.weAreBuilding(UnitManager.BASE)) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			return true;
		}

		if (bases >= 2 && battleUnits <= bases * 9 && !xvr.duTaiNguyen(700)) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
			return false;
		}

		if (battleUnits < StrategyManager.getMinBattleUnits() + 2) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
			return false;
		}

		int quickUnitsThreshold = BotStrategyManager.isExpandWithCannons() ? 4 : 13;

		if (battleUnits >= quickUnitsThreshold && xvr.duTaiNguyen(350) || xvr.duTaiNguyen(500)) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			return true;
		}

		// FORCE quick expansion if we're rich
		if (xvr.duTaiNguyen(330)) {
			if (gateways >= 3 && battleUnits >= (BotStrategyManager.isExpandWithCannons() ? 7 : 15)
					&& !XVR.doithuTerran()) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
				return true;
			}

			// int thresholdBattleUnits = xvr.getENEMY().isProtoss() ? 9 : 5;
			int thresholdBattleUnits = ProtossGateway.MIN_UNITS_FOR_DIFF_BUILDING - 4;
			if (battleUnits < thresholdBattleUnits || !xvr.duTaiNguyen(350)) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
				return false;
			} else {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
				return true;
			}
		}
		if (xvr.duTaiNguyen(410)) {
			if (battleUnits < 8) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
				return false;
			} else {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
				return true;
			}
		}

		// Initially, we must wait to have at least 3 barracks to build first
		// base.
		if (bases == 1) {
			if (UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Gateway) <= 2
					&& !xvr.duTaiNguyen(500)) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
				return false;
			}
		}

		// More than one base
		else {

			// But if we already have another base...
			if ((bases * ARMY_UNITS_PER_NEW_BASE > battleUnits && !xvr.duTaiNguyen(550))) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
				return false;
			}
		}

		ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
		return true;
	}

	public static void act() {
		for (Unit base : xvr.layUnitsOfTypeHoanThanh(buildingType)) {
			ProtossNexus.act(base);
		}
	}

	public static void act(Unit base) {

		checkNumberOfGasWorkersAt(base);

		checkNumberOfWorkersOverallAtBase(base);
		
		checkIfRemoveZeroMineralsCrystal(base);
	}

	private static void checkNumberOfWorkersOverallAtBase(Unit base) {
		if (shouldBuildWorkers(base)) {
			if (base.getTrainingQueueSize() == 0) {
				xvr.buildUnit(base, UnitManager.WORKER);
			}
		}

		else {

		}
	}

	private static void checkNumberOfGasWorkersAt(Unit base) {
		if (!ProtossNexus.isExistingCompletedAssimilatorNearBase(base)) {
			return;
		}

		int gasGatherersForBase = getNumberofGasGatherersForBase(base);
		if (gasGatherersForBase > WORKERS_PER_GEYSER) {
			int overLimitWorkers = gasGatherersForBase - WORKERS_PER_GEYSER;

			if (xvr.layUnitOfTypeGanNhat(UnitTypes.Protoss_Assimilator, base).getResources() < 40) {
				overLimitWorkers = gasGatherersForBase - 1;
			}

			// We can send workers only if there's another base
			if (overLimitWorkers > 0) {
				haveOverLimitGasWorkers(base, overLimitWorkers);
			}
		} else {
			int numRequiredWorkers = WORKERS_PER_GEYSER - gasGatherersForBase;
			int optimalMineralWorkersAtBase = getOptimalMineralGatherersAtBase(base)
					- WORKERS_PER_GEYSER;
			double mineralWorkersToOptimalRatio = (double) getNumberOfMineralGatherersForBase(base)
					/ optimalMineralWorkersAtBase;
			if (mineralWorkersToOptimalRatio < 0.5) {
				numRequiredWorkers--;
			}
			if (mineralWorkersToOptimalRatio < 0.6) {
				numRequiredWorkers--;
			}
			if (mineralWorkersToOptimalRatio < 0.7) {
				numRequiredWorkers--;
			}
			if (numRequiredWorkers <= 0) {
				numRequiredWorkers = 1;
			}

			ArrayList<Unit> gatherers = getMineralWorkersNearBase(base);
			for (int i = 0; i < numRequiredWorkers && i < gatherers.size(); i++) {
				Unit gathererToAssign = gatherers.get(i);
				WorkerManager.gatherResources(gathererToAssign, base);
			}
		}
	}

	private static void haveOverLimitGasWorkers(Unit base, int overLimitWorkers) {
		ArrayList<Unit> gatherers = getGasWorkersNearBase(base);
		ArrayList<Unit> mineralsInNeihgborhood = xvr.layUnitsTrongBanKinh(
				UnitTypes.Resource_Mineral_Field, 25, base, false);
		if (!mineralsInNeihgborhood.isEmpty()) {
			for (Unit worker : gatherers) {
				WorkerManager.gatherResources(worker, base);
			}
		}
	}

	private static void checkIfRemoveZeroMineralsCrystal(Unit base) {
		final int SEARCH_IN_RADIUS = 30;
		final int ACT_IF_AT_LEAST_N_WORKERS = 20;
		if (UnitCounter.laySoLuongUnits(UnitManager.WORKER) < ACT_IF_AT_LEAST_N_WORKERS) {
			return;
		}

		ArrayList<Unit> workers = xvr.layWorkers();
		ArrayList<Unit> mineralWorkersNearBase = new ArrayList<>();
		for (Unit worker : workers) {
			if (worker.isGatheringMinerals() && !worker.isConstructing()
					&& xvr.layKhoangCachGiua(base, worker) <= SEARCH_IN_RADIUS) {
				mineralWorkersNearBase.add(worker);
			}
		}

		if (mineralWorkersNearBase.size() >= ACT_IF_AT_LEAST_N_WORKERS) {
			ArrayList<Unit> mineralsAroundTheBase = xvr.layUnitsTrongBanKinh(
					UnitTypes.Resource_Mineral_Field, SEARCH_IN_RADIUS, base, false);

			for (Unit mineral : mineralsAroundTheBase) {
				if (mineral.getResources() == 0 && !mineral.isBeingGathered()) {

					int max = 1;
					Unit unitToUse = mineralWorkersNearBase.get(RUtilities.rand(0, max));

					WorkerManager.forceGatherMinerals(unitToUse, mineral);
				}
			}
		}
	}

	public static MapPoint getTileForNextBase(boolean forceNewSolution) {

		if (_cachedNextBaseTile != null && !forceNewSolution) {
			return _cachedNextBaseTile;
		}

		BaseLocation nearestFreeBaseLocation = getNearestFreeBaseLocation();

		if (nearestFreeBaseLocation != null) {
			MapPoint point = nearestFreeBaseLocation;

			_cachedNextBaseTile = Constructing.getLegitTileToBuildNear(xvr.layWorkerNgauNhien(),
					buildingType, point, 0, 30, false);

		} else {
			System.out.println("Error! No place for next base!");
			_cachedNextBaseTile = null;
		}

		return _cachedNextBaseTile;
	}

	private static BaseLocation getNearestFreeBaseLocation() {
		Unit expansionCenter = xvr.layCanCuGoc();
		if (expansionCenter == null) {
			return null;
		}
		Map map = xvr.getBwapi().getMap();
		BaseLocation nearestFreeBaseLocation = null;
		double nearestDistance = 999999;
		for (BaseLocation location : xvr.getBwapi().getMap().getBaseLocations()) {

			// If there's already a base there don't build. Check for both our
			// and enemy bases.
			if (existsBaseNear(location.getX(), location.getY())) {
				// || !xvr.getBwapi().isVisible(location)
				continue;
			}

			// Check if the new base is connected to the main base by land.
			// Region newBaseRegion = xvr.getBwapi().getMap()
			// .getRegion(location.getX(), location.getY());
			// if (!map.isConnected(location, expansionCenter)) {
			// continue;
			// }

			// Look for for the closest base and remember it.
			double distance = map.getGroundDistance(location, expansionCenter) / 32;
			if (distance < 0) { // -1 means there's no path
				continue;
			}

			// double distance = xvr.layKhoangCachGiua(location.getX(),
			// location.getY(), mainBase.getX(), mainBase.getY());
			if (distance < nearestDistance) {
				nearestDistance = distance;
				nearestFreeBaseLocation = location;
			}
		}

		return nearestFreeBaseLocation;
	}

	private static boolean existsBaseNear(int x, int y) {


		for (Unit unit : xvr.layUnitsTrongBanKinh(x, y, 14)) {
			if (unit.getType().isBase()) {
				return true;
			}
		}

		return false;
	}

	private static boolean shouldBuildWorkers(Unit base) {
		int workers = UnitCounter.laySoLuongUnits(UnitManager.WORKER);
		int pylons = UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Pylon);
		boolean weAreBuildingPylon = Constructing.weAreBuilding(UnitTypes.Protoss_Pylon);

		if (workers >= MAX_WORKERS) {
			return false;
		}

		if (workers == 8 && (pylons == 0 || !weAreBuildingPylon) && !xvr.duTaiNguyen(150)) {
			return false;

		}
		if (BotStrategyManager.isExpandWithCannons()) {
			if (pylons == 2) {
				if (!Constructing.weAreBuilding(UnitTypes.Protoss_Photon_Cannon)
						&& !xvr.duTaiNguyen(200) && workers >= 20) {
					return false;
				} else {
					return xvr.duTaiNguyen(184);
				}
			}
		}

		if (workers < MIN_WORKERS) {
			return true;
		}

		int bases = UnitCounter.laySoLuongUnits(UnitManager.BASE);
		int cannons = UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Photon_Cannon);

		if (workers > bases * 25) {
			return false;
		}

		if (BotStrategyManager.isExpandWithCannons()) {
			if (workers >= MIN_WORKERS && cannons < 2) {
				return false;
			}
		}

		int workersNearBase = getNumberOfWorkersNearBase(base);
		double existingToOptimalRatio = (double) workersNearBase
				/ getOptimalMineralGatherersAtBase(base);

		int gateways = UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Gateway);
		if (UnitCounter.laySoLuongUnits(buildingType) == 1 && gateways <= 3) {
			if (existingToOptimalRatio > 0.5 + 0.12 * gateways) {
				return false;
			}
		}

		int[] shouldBuildAnyBuilding = Constructing.shouldBuildAnyBuilding();
		if (shouldBuildAnyBuilding != null) {

			if (!xvr.duTaiNguyen(shouldBuildAnyBuilding[0] + 100) && existingToOptimalRatio > 0.4) {
				return false;
			}
		}

		return (existingToOptimalRatio < 1 ? true : false);
	}

	private static int getNumberOfWorkersNearBase(Unit base) {
		return xvr.demLoaiUnitsTrongBanKinh(UnitManager.WORKER, 15, base.getX(), base.getY(),
				true);
	}

	public static int getOptimalMineralGatherersAtBase(Unit base) {
		int numberOfMineralsNearbyBase = xvr.demKimCuongTrongBanKinh(12, base.getX(), base.getY());
		return (int) (2.59 * numberOfMineralsNearbyBase) + WORKERS_PER_GEYSER;
	}

	public static Unit getNearestBaseForUnit(MapPoint point) {
		double nearestDistance = 9999999;
		Unit nearestBase = null;

		for (Unit base : xvr.layUnitsOfTypeHoanThanh(buildingType)) {
			double distance = xvr.layKhoangCachGiua(base, point);
			if (distance < nearestDistance) {
				distance = nearestDistance;
				nearestBase = base;
			}
		}

		return nearestBase;
	}

	public static Unit getNearestMineralGathererForUnit(Unit base) {
		double nearestDistance = 9999999;
		Unit nearestBase = null;

		for (Unit scv : xvr.layWorkers()) {
			if (scv.isGatheringMinerals()) {
				double distance = xvr.layKhoangCachGiua(scv, base);
				if (distance < nearestDistance) {
					distance = nearestDistance;
					nearestBase = scv;
				}
			}
		}

		return nearestBase;
	}

	public static int getNumberofGasGatherersForBase(Unit base) {
		int result = 0;
		int MAX_DISTANCE = 10;

		for (Unit worker : xvr.layWorkers()) {
			if (worker.isGatheringGas()) {
				double distance = xvr.layKhoangCachGiua(worker, base);
				if (distance < MAX_DISTANCE) {
					result++;
				}
			}
		}

		return result;
	}

	public static int getNumberOfMineralGatherersForBase(Unit base) {
		int result = 0;
		int MAX_DISTANCE = 12;

		for (Unit worker : xvr.layWorkers()) {
			if (worker.isGatheringMinerals()) {
				double distance = xvr.layKhoangCachGiua(worker, base);
				if (distance < MAX_DISTANCE) {
					result++;
				}
			}
		}

		return result;
	}

	public static ArrayList<Unit> getMineralsNearBase(Unit base) {
		return getMineralsNearBase(base, MAX_DIST_OF_MINERAL_FROM_BASE);
	}

	public static ArrayList<Unit> getMineralsNearBase(Unit base, int maxDist) {
		HashMap<Unit, Double> minerals = new HashMap<Unit, Double>();

		for (Unit mineral : xvr.layUnitsKimCuong()) {
			double distance = xvr.layKhoangCachGiua(mineral, base);
			if (distance < 0) {
				continue;
			}

			if (distance <= maxDist && mineral.getResources() > 1) {
				minerals.put(mineral, distance);
			}
		}

		ArrayList<Unit> sortedList = new ArrayList<Unit>();
		sortedList.addAll(RUtilities.sortByValue(minerals, true).keySet());
		return sortedList;
	}

	public static ArrayList<Unit> getWorkersNearBase(Unit nearestBase) {
		ArrayList<Unit> units = new ArrayList<Unit>();
		for (Unit worker : xvr.layWorkers()) {
			if (xvr.layKhoangCachGiua(nearestBase, worker) < 20) {
				units.add(worker);
			}
		}
		return units;
	}

	public static ArrayList<Unit> getMineralWorkersNearBase(Unit nearestBase) {
		ArrayList<Unit> units = new ArrayList<Unit>();
		for (Unit worker : xvr.layWorkers()) {
			if (worker.isGatheringMinerals() && xvr.layKhoangCachGiua(nearestBase, worker) < 20) {
				units.add(worker);
			}
		}
		return units;
	}

	public static ArrayList<Unit> getGasWorkersNearBase(Unit nearestBase) {
		ArrayList<Unit> units = new ArrayList<Unit>();
		for (Unit worker : xvr.layWorkers()) {
			if (worker.isGatheringGas() && xvr.layKhoangCachGiua(nearestBase, worker) < 12) {
				units.add(worker);
			}
		}
		return units;
	}

	public static void initialMineralGathering() {
		ArrayList<Unit> minerals = getMineralsNearBase(xvr.layCanCuGoc());

		int counter = 0;
		for (Unit unit : getWorkersNearBase(xvr.layCanCuGoc())) {
			WorkerManager.forceGatherMinerals(unit, minerals.get(counter));

			counter++;
		}
	}

	public static ArrayList<Unit> getBases() {
		return xvr.layUnitsOfType(UnitTypes.Protoss_Nexus);
	}

	public static UnitTypes getBuildingtype() {
		return buildingType;
	}

	public static boolean isExistingCompletedAssimilatorNearBase(Unit nearestBase) {
		ArrayList<Unit> inRadius = xvr.layUnitsTrongBanKinh(
				ProtossAssimilator.getBuildingtype(), 12, nearestBase, true);

		if (!inRadius.isEmpty() && inRadius.get(0).isCompleted()
				&& inRadius.get(0).getResources() > 50) {
			return true;
		} else {
			return false;
		}
	}

	public static Unit getExistingCompletedAssimilatorNearBase(Unit nearestBase) {
		ArrayList<Unit> inRadius = xvr.layUnitsTrongBanKinh(
				ProtossAssimilator.getBuildingtype(), 12, nearestBase, true);

		if (!inRadius.isEmpty() && inRadius.get(0).isCompleted()
				&& inRadius.get(0).getResources() > 50) {
			return inRadius.get(0);
		} else {
			return null;
		}
	}

	public static Unit getRandomBase() {
		ArrayList<Unit> bases = getBases();
		if (bases.isEmpty()) {
			return null;
		}
		return (Unit) RUtilities.randomElement(bases);
	}

	public static MapPoint getSecondBaseLocation() {
		if (_secondBase != null) {
			return _secondBase;
		} else {
			_secondBase = ProtossNexus.getTileForNextBase(true);
			return _secondBase;
		}
	}

	public static void updateNextBaseToExpand() {
		getTileForNextBase(true);
	}

}

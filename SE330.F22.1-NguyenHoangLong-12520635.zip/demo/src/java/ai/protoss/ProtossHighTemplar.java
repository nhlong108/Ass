package ai.protoss;

import java.util.ArrayList;

import jnibwapi.model.Unit;
import jnibwapi.types.TechType.TechTypes;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.army.TargetHandling;
import ai.handling.units.UnitsActions;
import ai.handling.units.UnitCounter;
import ai.managers.TechnologyManager;

public class ProtossHighTemplar {

	private static final int MINIMAL_ARCHONS = 5;

	private static final UnitTypes HIGH_TEMPLAR = UnitTypes.Protoss_High_Templar;
	private static final UnitTypes ARCHON = UnitTypes.Protoss_Archon;

	private static XVR xvr = XVR.getInstance();

	public static void act(Unit highTemplar) {

		if (highTemplar.getShields() <= 25) {
			UnitsActions.actKhiMauVaGiapThap(highTemplar, true);
			return;
		}

		if (tryWarpingArchon(highTemplar)) {
			return;
		}

		boolean shouldRun = highTemplar.isUnderAttack();
		if (!shouldRun && xvr.coDichTrongBanKinh(highTemplar, 6)) {
			shouldRun = true;
		}

		if (shouldRun) {
			UnitsActions.diChuyen(highTemplar, xvr.layCanCuMoiNhat());
		}

		if (highTemplar.getEnergy() >= 75) {
			tryUsingPsionicStorm(highTemplar);
		}
	}

	private static void tryUsingPsionicStorm(Unit highTemplar) {
		if (highTemplar.getEnergy() >= 75) {
			Unit unitToStrike = null;

			ArrayList<Unit> topPriorityTargets = TargetHandling
					.getTopPriorityTargetsNear(highTemplar, 13);
			if (!topPriorityTargets.isEmpty()) {
				for (Unit possibleTarget : topPriorityTargets) {
					if (!possibleTarget.isUnderStorm()
							&& !possibleTarget.isStasised()) {
						unitToStrike = possibleTarget;
						break;
					}
				}
			}

			if (unitToStrike == null) {

				ArrayList<Unit> enemies = xvr.layUnitsTrongBanKinh(highTemplar, 13,
						xvr.layArmyUnitDoiThu());
				for (Unit possibleTarget : enemies) {
					if (xvr.demUnitsTrongBanKinh(possibleTarget, 3, xvr
							.getBwapi().getEnemyUnits()) >= 4) {
						unitToStrike = possibleTarget;
						break;
					}

					if (!possibleTarget.isUnderStorm()
							&& !possibleTarget.isStasised()) {
						if (xvr.demUnitsTrongBanKinh(possibleTarget, 4, xvr
								.getBwapi().getEnemyUnits()) >= 2
								|| highTemplar.getEnergy() >= 150) {
							unitToStrike = possibleTarget;
							break;
						}
					}
				}
			}
			if (unitToStrike != null) {
				UnitsActions.useTech(highTemplar,
						TechnologyManager.PSIONIC_STORM, unitToStrike);
			}
		}
	}

	private static void tryUsingHallucination(Unit highTemplar) {
		if (highTemplar.getEnergy() >= 100) {
			Unit sheepDolly = null;

			if (sheepDolly == null
					|| xvr.layKhoangCachSimple(highTemplar, sheepDolly) > 20) {
				sheepDolly = xvr.layUnitOfTypeGanNhat(ARCHON, highTemplar);
			}

			if (sheepDolly == null
					|| xvr.layKhoangCachSimple(highTemplar, sheepDolly) > 20) {
				sheepDolly = xvr.layUnitOfTypeGanNhat(
						UnitTypes.Protoss_Dragoon, highTemplar);
			}

			if (sheepDolly == null
					|| xvr.layKhoangCachSimple(highTemplar, sheepDolly) > 20) {
				ArrayList<Unit> ourUnits = xvr
						.layUnitsOfType(UnitTypes.Protoss_Zealot);
				sheepDolly = xvr.layUnitGanNhatTuList(highTemplar, ourUnits);
			}

			if (sheepDolly != null) {
				UnitsActions.useTech(highTemplar,
						TechnologyManager.HALLUCINATION, sheepDolly);
			}
		}
	}

	private static boolean tryWarpingArchon(Unit highTemplar) {
		if (UnitCounter.laySoLuongUnits(HIGH_TEMPLAR) >= 2) {

			if (UnitCounter.laySoLuongUnits(ARCHON) < MINIMAL_ARCHONS) {
				Unit otherHighTemplar = getOtherHighTemplarNear(highTemplar);

				if (otherHighTemplar == null) {
					return false;
				}
				if (highTemplar.getEnergy() >= 100) {
					tryUsingHallucination(highTemplar);
				} else if (otherHighTemplar.getEnergy() >= 100) {
					tryUsingHallucination(otherHighTemplar);
				}
				else {
					if (otherHighTemplar != null) {
						xvr.getBwapi().useTech(highTemplar.getID(),
								TechTypes.Archon_Warp.ordinal(),
								otherHighTemplar.getID());
						return true;
					}
				}
			}
		}

		return false;
	}

	private static Unit getOtherHighTemplarNear(Unit highTemplar) {
		ArrayList<Unit> otherTemplars = xvr.layUnitsTrongBanKinh(highTemplar, 30,
				xvr.layUnitsOfType(HIGH_TEMPLAR));
		otherTemplars.remove(highTemplar);

		for (Unit otherUnit : otherTemplars) {
			if (otherUnit.getEnergy() < 140
					|| !TechnologyManager
							.isResearched(TechnologyManager.PSIONIC_STORM)) {
				return otherUnit;
			}
		}

		return null;
	}

}

package ai.protoss;

import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.constructing.Constructing;
import ai.handling.constructing.ShouldBuildCache;
import ai.handling.units.UnitCounter;
import ai.managers.BotStrategyManager;
import ai.managers.UnitManager;

public class ProtossAssimilator {

	private static XVR xvr = XVR.getInstance();

	private static final UnitTypes buildingType = UnitTypes.Protoss_Assimilator;

	public static boolean shouldBuild() {
		int minGateways = BotStrategyManager.isExpandWithCannons() ? 3 : 4;

		if (UnitCounter.laySoLuongUnitsHoanThanh(UnitTypes.Protoss_Forge) == 0
				&& UnitCounter
						.laySoLuongUnits(UnitTypes.Protoss_Photon_Cannon) == 0) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			return false;
		}

		if (!Constructing.weAreBuilding(buildingType)
				&& UnitCounter.laySoLuongUnits(buildingType) < UnitCounter
						.laySoLuongUnitsHoanThanh(UnitManager.BASE)
				&& (UnitCounter
						.coNha(UnitTypes.Protoss_Cybernetics_Core) || ProtossGateway.LIMIT_ZEALOTS)) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			return true;
		}

		if (!Constructing.weAreBuilding(buildingType)
				&& (UnitCounter
						.coNha(UnitTypes.Protoss_Cybernetics_Core)
						|| UnitCounter.laySoLuongUnits(UnitManager.GATEWAY) >= minGateways || xvr
							.duTaiNguyen(700))
				&& UnitCounter.laySoLuongUnits(buildingType) < UnitCounter
						.laySoLuongUnitsHoanThanh(UnitManager.BASE)) {
			if (UnitCounter.laySoLuongUnitsThamChien() >= ProtossGateway.MIN_UNITS_FOR_DIFF_BUILDING) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
				return true;
			}
		}

		if (UnitCounter.laySoLuongUnits(buildingType) < UnitCounter
				.laySoLuongUnitsHoanThanh(UnitManager.BASE)
				&& xvr.duTaiNguyen(750)) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			return true;
		}

		ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
		return false;
	}

	public static void buildIfNecessary() {
		if (shouldBuild()) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			Constructing.construct(xvr, buildingType);
		}
		ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
	}

	public static UnitTypes getBuildingtype() {
		return buildingType;
	}

}

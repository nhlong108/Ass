package ai.protoss;

import java.util.ArrayList;

import jnibwapi.model.Unit;
import ai.core.XVR;
import ai.handling.map.MapExploration;
import ai.handling.map.MapPoint;
import ai.handling.units.UnitsActions;
import ai.managers.StrategyManager;
import ai.utils.RUtilities;

public class ProtossDarkTemplar {

	private static XVR xvr = XVR.getInstance();

	public static void act(Unit unit) {
		int alliedUnitsNearby = xvr.demUnitsTrongBanKinh(unit, 10, true);


		boolean shouldConsiderRunningAway = true;

		if (StrategyManager.isAttackPending()) {
			if (alliedUnitsNearby >= 4) {
				shouldConsiderRunningAway = false;
			}
		}
		
		if (shouldConsiderRunningAway
				&& UnitsActions
						.chayKhoiQuanOrTruDich(
								unit, true, true, false)) {
			return;
		}

		if ((unit.isAttacking() || unit.isMoving()) && !unit.isUnderAttack()) {
			return;
		}

		MapPoint pointToHarass = defineNeighborhoodToHarass(unit);

		ArrayList<MapPoint> pointForHarassmentNearEnemy = new ArrayList<>();
		pointForHarassmentNearEnemy.addAll(MapExploration.getBaseLocationsNear(
				pointToHarass, 30));
		pointForHarassmentNearEnemy.addAll(MapExploration.getChokePointsNear(
				pointToHarass, 30));

		MapPoint goTo = null;
		if (!pointForHarassmentNearEnemy.isEmpty()) {

			goTo = (MapPoint) RUtilities
					.getRandomListElement(pointForHarassmentNearEnemy);
		}

		else {
			goTo = MapExploration.getNearestUnknownPointFor(unit.getX(),
					unit.getY(), true);
			if (goTo != null
					&& xvr.getBwapi()
							.getMap()
							.isConnected(unit, goTo.getX() / 32,
									goTo.getY() / 32)) {
			}
		}


		UnitsActions.tanCong(unit, goTo.getX(), goTo.getY());
	}

	private static MapPoint defineNeighborhoodToHarass(Unit unit) {

		MapPoint pointToHarass = MapExploration.getRandomKnownEnemyBase();

		if (pointToHarass == null) {
			pointToHarass = MapExploration.getNearestEnemyBuilding();
		}

		if (pointToHarass == null) {
			pointToHarass = MapExploration.getRandomChokePoint();
		}

		return pointToHarass;
	}

}

package ai.protoss;

import java.util.ArrayList;
import java.util.Iterator;

import jnibwapi.model.ChokePoint;
import jnibwapi.model.Unit;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.constructing.Constructing;
import ai.handling.constructing.ShouldBuildCache;
import ai.handling.map.MapExploration;
import ai.handling.map.MapPoint;
import ai.handling.map.MapPointInstance;
import ai.handling.units.UnitCounter;
import ai.managers.BotStrategyManager;
import ai.managers.UnitManager;
import ai.utils.RUtilities;

public class ProtossPylon {

	private static int INITIAL_PYLON_MIN_DIST_FROM_BASE = 5;
	private static int INITIAL_PYLON_MAX_DIST_FROM_BASE = 18;
	private static int PYLON_FROM_PYLON_MIN_DISTANCE = 8;
	private static int PYLON_FROM_PYLON_MAX_DISTANCE = 20;

	private static final UnitTypes buildingType = UnitTypes.Protoss_Pylon;
	private static XVR xvr = XVR.getInstance();

	public static void buildIfNecessary() {
		if (xvr.duTaiNguyen(100)) {
			if (shouldBuild()) {
				Constructing.construct(xvr, buildingType);
			}
		}
	}

	public static boolean shouldBuild() {
		int free = xvr.laySoQuanFree();
		int total = xvr.layTongSoQuan();
		int pylons = UnitCounter.laySoLuongUnits(buildingType);
		int workers = UnitCounter.laySoLuongUnits(UnitManager.WORKER);
		int forges = UnitCounter.laySoLuongUnits(UnitTypes.Protoss_Forge);

		// ### VERSION ### Expansion with cannons
		if (BotStrategyManager.isExpandWithCannons()) {
			if (pylons == 0 && (workers >= 7 || xvr.duTaiNguyen(87))) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
				return true;
			}
		}

		if (BotStrategyManager.isExpandWithCannons()) {
			if (pylons == 1
					&& ((forges == 1 && xvr.duTaiNguyen(54)) || (forges == 0 && xvr
							.duTaiNguyen(194)))) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
				return true;
			}
		} else {
			if (pylons == 1
					&& ((forges == 1 && xvr.duTaiNguyen(54)) || (forges == 0 && xvr
							.duTaiNguyen(216)))) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
				return true;
			}
		}

		if (total == 200) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
			return false;
		}

		if (ProtossPylon
				.findTileNearPylonForNewBuilding(UnitTypes.Protoss_Gateway) == null) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			return true;
		}

		if (total < 80 && Constructing.weAreBuilding(buildingType)) {
			if (!(total >= 10 && total <= 20 && free == 0)) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
				return false;
			}
		}

		boolean shouldBuild = ((pylons == 0 && total <= 9 && free <= 3)
				|| (total >= 10 && total <= 17 && free <= 4 && pylons <= 1)
				|| (total >= 18 && total <= 25 && free <= 7)
				|| (total > 25 && total <= 45 && free <= 11)
				|| (total > 45 && free <= 16) || (total > 90 && total < 200 && free <= 20));

		ShouldBuildCache.cacheShouldBuildInfo(buildingType, shouldBuild);
		return shouldBuild;
	}

	public static double calculateExistingPylonsStrength() {
		double result = 0;

		for (Unit pylon : xvr.layUnitsOfType(buildingType)) {
			result += (double) (pylon.getShields() + pylon.getHitPoints()) / 600;
		}

		return result;
	}

	public static MapPoint findTileNearPylonForNewBuilding(UnitTypes typeToBuild) {
		if (!UnitCounter.coPylonHoanThanh()) {
			return null;
		}
		int pylons = UnitCounter.laySoLuongPylon();

		Unit base = xvr.layCanCuGoc();
		if (base == null) {
			return null;
		}

		// if (UnitCounter.laySoLuongUnits(UnitManager.BASE) >= 3
		// && RUtilities.rand(0, 4) == 0) {
		// base = ProtossNexus.getRandomBase();
		// }

		int searchRadiusOfPylons = 14;
		if (pylons > 10 || pylons == 1) {
			searchRadiusOfPylons = 50;
		}

		for (Unit pylon : xvr.layUnitsTrongBanKinh(base, searchRadiusOfPylons,
				xvr.layUnitsOfType(buildingType))) {
			if (pylon != null) {

				int minDistFromPylon = 5;
				MapPoint tile = Constructing.getLegitTileToBuildNear(
						xvr.layWorkerNgauNhien(), typeToBuild, pylon,
						minDistFromPylon, 15, true);
				if (tile != null) {
					return tile;
				}
			}
		}
		return null;
	}

	public static MapPoint findTileForPylon() {
		Unit builder = Constructing.getRandomWorker();
		if (UnitCounter.coPylonHoanThanh()) {
			if (UnitCounter.laySoLuongPylon() == 1) {
				MapPoint tile = findTileForFirstPylonAtBase(builder,
						ProtossNexus.getSecondBaseLocation());
				if (tile != null) {
					return tile;
				}
			}
			return findTileForNextPylon(builder);
		}

		else {
			return findTileForFirstPylon(builder, xvr.layCanCuGoc());
		}
	}

	private static MapPoint findTileForNextPylon(Unit builder) {

		for (Unit base : xvr.layUnitsOfType(UnitManager.BASE)) {
			int nearbyPylons = xvr.demLoaiUnitsTrongBanKinh(buildingType,
					14, base.getX(), base.getY(), true);

			if (nearbyPylons == 0) {
				MapPoint buildTile = findTileForPylonNearby(base,
						INITIAL_PYLON_MIN_DIST_FROM_BASE,
						INITIAL_PYLON_MAX_DIST_FROM_BASE);
				if (buildTile != null) {
					return buildTile;
				}
			}
		}

		if ((UnitCounter.laySoLuongUnits(buildingType) >= 5 && RUtilities
				.rand(0, 5) == 0)
				|| (xvr.layTongSoQuan() > 55 && xvr.laySoQuanFree() <= 5)) {
			return findTileNearPylonForNewBuilding(buildingType);
		}

		// Either build randomly near base
		if (UnitCounter.laySoLuongPylon() >= 10 && RUtilities.rand(0, 3) == 0) {

			// Build normally, at random base.
			MapPoint buildTile = findTileForPylonNearby(
					ProtossNexus.getRandomBase(),
					INITIAL_PYLON_MIN_DIST_FROM_BASE,
					INITIAL_PYLON_MAX_DIST_FROM_BASE);
			if (buildTile != null) {
				return buildTile;
			}
		}
		Unit pylon = null;
		if (UnitCounter.laySoLuongPylon() > 5) {
			pylon = getRandomPylon();
		} else {
			ArrayList<Unit> pylonsNearMainBase = xvr
					.layUnitsTrongBanKinh(buildingType, 14,
							xvr.layCanCuGoc(), true);
			if (!pylonsNearMainBase.isEmpty()) {
				pylon = (Unit) RUtilities.getRandomElement(pylonsNearMainBase);
			}
			if (pylon == null) {
				pylon = getRandomPylon();
			}
		}
		
		MapPoint tile = findTileForPylonNearby(pylon,
				PYLON_FROM_PYLON_MIN_DISTANCE, PYLON_FROM_PYLON_MAX_DISTANCE);
		if (tile != null) {
			return tile;
		} else {
			return findTileNearPylonForNewBuilding(buildingType);
		}

	}

	private static Unit getRandomPylon() {
		ArrayList<Unit> pylons = getPylons();
		return (Unit) RUtilities.getRandomListElement(pylons);
	}

	private static MapPoint findTileForPylonNearby(MapPoint point, int minDist,
			int maxDist) {

		return findLegitTileForPylon(point, Constructing.getRandomWorker());
	}

	private static MapPoint findLegitTileForPylon(MapPoint buildNearToHere,
			Unit builder) {
		int tileX = buildNearToHere.getTx();
		int tileY = buildNearToHere.getTy();

		int currentDist = PYLON_FROM_PYLON_MIN_DISTANCE;
		while (currentDist <= PYLON_FROM_PYLON_MAX_DISTANCE) {
			for (int i = tileX - currentDist; i <= tileX + currentDist; i++) {
				for (int j = tileY - currentDist; j <= tileY + currentDist; j++) {
					int x = i * 32;
					int y = j * 32;
					if (Constructing.canBuildHere(builder, buildingType, i, j)
							&& xvr.layUnitsTrongBanKinh(buildingType,
									PYLON_FROM_PYLON_MIN_DISTANCE - 1, x, y,
									true).isEmpty()) {
						
						MapPointInstance point = new MapPointInstance(x, y);
						if (!Constructing.isTooNearMineralAndBase(point)) {

							if (!Constructing.isTooCloseToAnyChokePoint(point)) {
								return point;
							}
						}
					}
				}
			}

			currentDist++;
		}
		return null;
	}

	private static ArrayList<Unit> getPylons() {
		ArrayList<Unit> pylons = xvr.layUnitsOfType(UnitTypes.Protoss_Pylon);
		for (Iterator<Unit> iterator = pylons.iterator(); iterator.hasNext();) {
			Unit unit = (Unit) iterator.next();
			if (!unit.isCompleted()) {
				iterator.remove();
			}
		}
		return pylons;
	}

	private static MapPoint findTileForFirstPylonAtBase(Unit builder,
			MapPoint base) {
		if (base == null) {
			return null;
		}

		base = ProtossNexus.getSecondBaseLocation();
		if (base == null) {
			return null;
		}

		ChokePoint choke = MapExploration.getNearestChokePointFor(base);
		if (choke == null) {
			return null;
		}

		MapPointInstance location = MapPointInstance.getMiddlePointBetween(
				base, choke);

		return Constructing.getLegitTileToBuildNear(builder, buildingType,
				location, 0, 100, false);
	}

	private static MapPoint findTileForFirstPylon(Unit builder, Unit base) {
		if (base == null) {
			return null;
		}

		ChokePoint choke = MapExploration.getNearestChokePointFor(base);
		MapPointInstance location = new MapPointInstance(
				(2 * base.getX() + choke.getCenterX()) / 3,
				(2 * base.getY() + choke.getCenterY()) / 3);

		return Constructing.getLegitTileToBuildNear(builder, buildingType,
				location, 0, 100, false);
	}

	public static UnitTypes getBuildingType() {
		return buildingType;
	}

}

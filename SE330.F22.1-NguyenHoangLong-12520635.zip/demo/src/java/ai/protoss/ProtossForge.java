package ai.protoss;

import jnibwapi.model.Unit;
import jnibwapi.types.UnitType.UnitTypes;
import ai.core.XVR;
import ai.handling.constructing.Constructing;
import ai.handling.constructing.ShouldBuildCache;
import ai.handling.map.MapExploration;
import ai.handling.units.UnitCounter;
import ai.managers.BotStrategyManager;

public class ProtossForge {

	private static final UnitTypes buildingType = UnitTypes.Protoss_Forge;
	private static XVR xvr = XVR.getInstance();

	public static void buildIfNecessary() {
		if (shouldBuild()) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			Constructing.construct(xvr, buildingType);
		}
		ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
	}

	public static boolean shouldBuild() {
		int forges = UnitCounter.laySoLuongUnits(buildingType);
		int gateways = UnitCounter.laySoLuongUnits(ProtossGateway
				.getBuildingType());
		if (BotStrategyManager.isExpandWithCannons()) {
			if (forges == 0
					&& (ProtossPylon.calculateExistingPylonsStrength() >= 0.86 || xvr
							.duTaiNguyen(132))
					&& !Constructing.weAreBuilding(buildingType)) {
				MapExploration.disableChokePointsNearFirstBase();
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
				return true;
				// }
			}
		}

		if (BotStrategyManager.isExpandWithGateways()) {
			if (forges == 0 && gateways >= 3
					&& !Constructing.weAreBuilding(buildingType)) {
				if (UnitCounter.laySoLuongUnitsThamChien() >= 5) {
					ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
					return true;
				}
			}
		}

		if (forges == 1
				&& UnitCounter.laySoLuongUnits(ProtossGateway
						.getBuildingType()) >= 4 && xvr.duTaiNguyen(650)
				&& !Constructing.weAreBuilding(buildingType)) {
			if (UnitCounter.laySoLuongUnitsThamChien() >= 18) {
				ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
				return true;
			}
		}

		if (forges == 2 && xvr.duTaiNguyen(900)
				&& !Constructing.weAreBuilding(buildingType)) {
			ShouldBuildCache.cacheShouldBuildInfo(buildingType, true);
			return true;
		}

		ShouldBuildCache.cacheShouldBuildInfo(buildingType, false);
		return false;
	}

	public static Unit getOneNotBusy() {
		for (Unit unit : xvr.layUnitsOfType(buildingType)) {
			if (unit.isBuildingNotBusy()) {
				return unit;
			}
		}
		return null;
	}

	public static UnitTypes getBuildingType() {
		return buildingType;
	}

}

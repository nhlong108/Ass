package com.ex.jboss.service;

import org.jboss.system.ServiceMBean;
import org.jboss.system.ServiceMBeanSupport;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StartService extends ServiceMBeanSupport implements StartServiceMBean {
	private static final String DEFAULT_NAME = "META-INF/applicationContext.xml";
    private ConfigurableApplicationContext ctx;
    private String m_descriptorName = DEFAULT_NAME;
    private Class m_classToLoad = null;

    @Override
    protected void startService() throws Exception {
        super.startService();
        if (m_classToLoad == null) {
            ctx = new ClassPathXmlApplicationContext(m_descriptorName);
        } else {
        	ctx = new ClassPathXmlApplicationContext(m_descriptorName, m_classToLoad);
        }
    }
    @Override
    protected void stopService() throws Exception {
        ctx.close();
        ctx = null;
        super.stopService();
    }
}

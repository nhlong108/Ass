package com.ex.jboss.service;

import org.jboss.system.ServiceMBean;

public interface StartServiceMBean extends ServiceMBean{

}

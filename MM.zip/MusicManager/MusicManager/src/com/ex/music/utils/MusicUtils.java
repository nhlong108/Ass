package com.ex.music.utils;

import com.ex.music.api.SongVO;
import com.ex.music.model.Song;

public class MusicUtils {
	public static Song createFromSongVO(SongVO so){
		Song s = new Song();
		s.setId(so.getId());
		s.setTitle(so.getTitle());
		s.setArtist(so.getArtist());
		s.setYear(so.getYear());
		s.setType(so.getType());
		return s;
	}
	public static SongVO convertToSongVO(Song s){
		SongVO so = new SongVO();
		so.setId(s.getId());
		so.setTitle(s.getTitle());
		so.setArtist(s.getArtist());
		so.setYear(s.getYear());
		so.setType(s.getType());
		return so;
	}
}

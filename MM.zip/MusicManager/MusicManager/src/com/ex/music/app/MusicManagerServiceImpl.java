package com.ex.music.app;

import java.util.List;

import com.ex.music.api.*;
import com.ex.music.dao.MusicMangerDao;
import com.ex.music.utils.MusicUtils;

public class MusicManagerServiceImpl implements MusicManagerService{
	private MusicMangerDao m_musicMangerDao;
	public MusicManagerServiceImpl(MusicMangerDao musicMangerDao){
		m_musicMangerDao=musicMangerDao;
	}
	@Override
	public List<SongVO> requestGetList() {
		return m_musicMangerDao.getList();
	}
	@Override
	public int requestModify(SongVO s) {
		return m_musicMangerDao.update(MusicUtils.createFromSongVO(s));
	}
	@Override
	public int requestAdd(SongVO s) {
		return m_musicMangerDao.insert(MusicUtils.createFromSongVO(s));
	}
	public int requestDelete(SongVO s) {
		return m_musicMangerDao.detete(MusicUtils.createFromSongVO(s));
	}
	
	
}

package com.ex.music.dao;



import java.util.List;

import com.ex.music.model.Song;
import com.ex.music.api.*;

public interface MusicMangerDao {
	public List<SongVO> getList();
	public int insert(Song s);
	public int update(Song s);
	public int detete(Song s);
}

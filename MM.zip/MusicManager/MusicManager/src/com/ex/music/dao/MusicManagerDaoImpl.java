package com.ex.music.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateTemplate;
import com.ex.music.api.SongVO;
import com.ex.music.model.Song;
import com.ex.music.utils.MusicUtils;

public class MusicManagerDaoImpl implements MusicMangerDao {
	public static final int RET_OK=1;
	public static final int RET_ERROR=-1;
	//May cai khong can thiet thi bo di he, vi du thag sessionFacoty do, dau co xai
	private HibernateTemplate m_hibernateTemplate;
	public MusicManagerDaoImpl(HibernateTemplate template){
		
		m_hibernateTemplate = template;
	}
	private Session getSession(){
		
		return m_hibernateTemplate.getSessionFactory().openSession();
		
	}
	@Override
	public List<SongVO> getList() {
		ArrayList<SongVO> arr = new ArrayList<SongVO>(10);
		Query q=getSession().createQuery("from Song");
		if(q==null)
			return null;
		else{
			Iterator<Song> it = q.iterate();
			while(it.hasNext()){
				Song s=it.next();
				arr.add(MusicUtils.convertToSongVO(s));
			}
		}
		return arr;
		
	}
	@Override
	public int insert(Song s) {
		int ret=RET_OK;
		try{
			m_hibernateTemplate.save(s);
		}catch(HibernateException e){
			ret=RET_ERROR;
		}
		return ret;
	}
	@Override
	public int update(Song s) {
		int ret=RET_OK;
		try{
			m_hibernateTemplate.update(s);
		}catch(HibernateException e){
			ret=RET_ERROR;
		}
		return ret;
	}
	@Override
	public int detete(Song s) {
		int ret=RET_OK;
		try{
			m_hibernateTemplate.delete(s);
		}catch(HibernateException e){
			ret=RET_ERROR;
		}
		return ret;
	}
	public HibernateTemplate getHibernateTemplate() {
		return m_hibernateTemplate;
	}
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.m_hibernateTemplate = hibernateTemplate;
	}
	
	
	
}

package com.ex.music.api;

import java.io.Serializable;

public class SongVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String title;
	private String artist;
	private String year;
	private String type;
	public SongVO(){
		
	}
	public SongVO(Long id,String title,String artist,String year){
		this.id=id;
		this.title=title;
		this.artist=artist;
		this.year=year;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getYear(){
		return year;
	}
	public void setYear(String year){
		this.year=year;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}

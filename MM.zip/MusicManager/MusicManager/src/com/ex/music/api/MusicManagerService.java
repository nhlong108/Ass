package com.ex.music.api;


import java.util.List;

public interface MusicManagerService {
	public static final int RET_OK=1;
	public static final int RET_ERROR=-1;
	public List<SongVO> requestGetList();
	public int requestModify(SongVO s);
	public int requestAdd(SongVO s);
	public int requestDelete(SongVO s);
}

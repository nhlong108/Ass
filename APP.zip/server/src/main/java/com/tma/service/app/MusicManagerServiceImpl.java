package com.tma.service.app;

import java.util.List;

import com.tma.api.MusicManagerService;
import com.tma.api.SongVO;
import com.tma.service.dao.SongDao;
import com.tma.service.utils.MusicUtils;

public class MusicManagerServiceImpl implements MusicManagerService {
	private SongDao m_songDao;
	
	public MusicManagerServiceImpl(SongDao songDao) {
		m_songDao = songDao;
	}
	
	@Override
	public List<SongVO> getList(SongVO so) {
		return m_songDao.getList();
	}

	@Override
	public boolean invokeAdd(SongVO so) {
		return m_songDao.insert(MusicUtils.createfromSongVO(so));
	}

	@Override
	public boolean invokeDel(SongVO so) {
		return m_songDao.delete(MusicUtils.createfromSongVO(so));
	}

	@Override
	public boolean invokeMod(SongVO so) {
		return m_songDao.insert(MusicUtils.createfromSongVO(so));
	}
	
}

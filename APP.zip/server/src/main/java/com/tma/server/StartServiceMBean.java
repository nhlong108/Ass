package com.tma.server;

public interface StartServiceMBean {
	public void start();

	public void stop();
}

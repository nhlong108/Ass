package com.tma.server;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StartService implements StartServiceMBean {
	ApplicationContext m_context;

	public void start() {
		m_context = new ClassPathXmlApplicationContext("applicationContext.xml");
	}

	public void stop() {

	}
}

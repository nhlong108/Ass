package com.tma.api;

import java.util.List;

public interface MusicManagerService {
	List<SongVO> getList(SongVO so);

	boolean invokeAdd(SongVO so);

	boolean invokeDel(SongVO so);

	boolean invokeMod(SongVO so);
}

package com.tma.app.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.springframework.jmx.export.annotation.ManagedAttribute;

/*The Pojo class have the getters, setters
 * that describe the table SONG in the MUSIC database
 **/

@Entity
@Table(name = "SONG", uniqueConstraints = { @UniqueConstraint(columnNames = { "SONG_ID" }) })
public class Song {
	private Integer songId;
	private String songName;
	private String songSinger;
	private String songYear;

	private Set<Song> songs = new HashSet<Song>(0);

	public Song() {

	}

	public Song(Integer songId, String songName, String songSinger,
			String songYear) {
		this.songId = songId;
		this.songName = songName;
		this.songSinger = songSinger;
		this.songYear = songYear;
	}

	@ManagedAttribute
	@Id
	@Column(name = "SONG_ID")
	public Integer getSongId() {
		return songId;
	}

	public void setSongId(Integer songId) {
		this.songId = songId;
	}

	@ManagedAttribute
	@Column(name = "SONG_NAME", length = 255, nullable = false)
	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	@ManagedAttribute
	@Column(name = "SONG_SINGER", length = 255, nullable = false)
	public String getSongSinger() {
		return songSinger;
	}

	public void setSongSinger(String songSinger) {
		this.songSinger = songSinger;
	}

	@ManagedAttribute
	@Column(name = "SONG_YEAR", length = 5, nullable = false)
	public String getSongYear() {
		return songYear;
	}

	public void setSongYear(String songYear) {
		this.songYear = songYear;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "songId")
	public Set<Song> getSongs() {
		return songs;
	}

	public void setSongs(Set<Song> songs) {
		this.songs = songs;
	}
}
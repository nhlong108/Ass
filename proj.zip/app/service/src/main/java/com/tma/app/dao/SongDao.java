package com.tma.app.dao;

/*DAO interface
 * have the basic CRUD to retrieve date
 **/

public interface SongDao {
	public void addSong(String name, String singer, String year);

	public void delSong(Integer id);

	public void updateSong();

	public void getAllSong();
}

package com.tma.app.service;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicLong;

import javax.management.AttributeChangeNotification;
import javax.management.MBeanNotificationInfo;
import javax.management.NotificationBroadcasterSupport;
import javax.management.NotificationEmitter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tma.app.dao.SongDao;

/**
 * The bean class that implement the bean interface 
 * This bean class will include in the package to deploy by .sar on to wildfly 
 * The client will use the methods that implementation in this class via mbean proxy from wildfly
 * 
 */

public class App extends NotificationBroadcasterSupport implements AppMXBean,
		Serializable, NotificationEmitter {

	private static final long serialVersionUID = 1L;
	private final static Logger m_log = LoggerFactory.getLogger(App.class
			.getName());
	private AtomicLong m_count = new AtomicLong(0);
	private ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"Spring.xml");
	private SongDao sDao = appContext.getBean(SongDao.class);

	@Override
	public long getCount() {
		return m_count.get();
	}

	public void start() throws Exception {
		m_log.info(" >> MXPojoHelloWorld.start() invoked");
	}

	public void stop() throws Exception {
		m_log.info(" << MXPojoHelloWorld.stop()  invoked");
	}

	public void addSong(String songName, String songSinger, String songYear) {
		m_count.incrementAndGet();
		sDao.addSong(songName, songSinger, songYear);

	}

	public void findAllSongs() {
		m_count.incrementAndGet();
		sDao.getAllSong();
	}

	@Override
	public void delSong(Integer songId) {
		m_count.incrementAndGet();
		sDao.delSong(songId);
	}

	@Override
	public MBeanNotificationInfo[] getNotificationInfo() {
		String[] types = new String[] { AttributeChangeNotification.ATTRIBUTE_CHANGE };
		String name = AttributeChangeNotification.class.getName();
		String description = "An attribute of this MBean has changed";
		MBeanNotificationInfo info = new MBeanNotificationInfo(types, name,
				description);
		return new MBeanNotificationInfo[] { info };
	}

}
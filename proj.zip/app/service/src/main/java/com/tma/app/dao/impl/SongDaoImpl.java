package com.tma.app.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.tma.app.dao.SongDao;
import com.tma.app.entities.Song;
import com.tma.app.utils.HibernateUtils;
import com.tma.app.utils.SongUtils;

/*Implement DAO class
 * */

public class SongDaoImpl implements SongDao {

	private SessionFactory m_sessionFactory = HibernateUtils
			.getSessionFactory();

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.m_sessionFactory = sessionFactory;
	}

	@Override
	public void addSong(String name, String singer, String year) {
		Session session1 = m_sessionFactory.getCurrentSession();
		Song song = null;

		try {
			session1.getTransaction().begin();

			Integer maxSongId = SongUtils.getMaxSongId(session1); // get max of
																	// song ID
			Integer songId = maxSongId + 1; // auto increase the id by 1 to the
											// new song

			song = new Song();
			song.setSongId(songId);
			song.setSongName(name);
			song.setSongSinger(singer);
			song.setSongYear(year);

			session1.persist(song); // insert the song into database
			session1.getTransaction().commit(); //complete the transaction
		} catch (HibernateException e) {
			e.printStackTrace();
			session1.getTransaction().rollback();
		}
	}

	@Override
	public void updateSong() {

	}

	@Override
	public void delSong(Integer id) {
		Session session2 = m_sessionFactory.getCurrentSession();

		try {
			session2.getTransaction().begin();
			//implement the HQL that query into Song entity class to delete the song by ID
			String sql = "Delete " + Song.class.getName() + " s "
					+ " where s.songId =:id";	
			Query query = session2.createQuery(sql);
			query.setParameter("id", id);

			query.executeUpdate();
			session2.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session2.getTransaction().rollback();
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public void getAllSong() {
		Session session = m_sessionFactory.getCurrentSession();

		try {
			session.getTransaction().begin();
			//implement the HQL that query into Song entity class to select all the song
			String sql = "Select s from Song s " + "order by s.songId";

			Query query = session.createQuery(sql);

			List<Song> songs = query.list();

			for (Song s : songs) {
				System.out.println("Song: " + s.getSongId() + " : "
						+ s.getSongName() + " - " + s.getSongSinger() + " - "
						+ s.getSongYear());
			}

			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
	}
}
package com.tma.app.utils;

import org.hibernate.Query;
import org.hibernate.Session;

public class SongUtils {

	/*
	 * Method that return the current max id of Song. That so important to the
	 * method addSong, auto increase song_id base on max id of song
	 */

	public static Integer getMaxSongId(Session session) {
		String sql = "Select max(s.songId) from Song s";
		Query query = session.createQuery(sql);
		Integer value = (Integer) query.uniqueResult();
		if (value == null) {
			return 0;
		}
		return value;
	}
}
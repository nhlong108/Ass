package com.tma.app.service;

/*The Bean interface, it's the service interface that provide some methods that client want to use
 */

public interface AppMXBean {

	/**
	 * Read only attribute
	 */
	long getCount();

	/**
	 * Operation
	 */
	void addSong(String songName, String songSinger, String songYear);

	void delSong(Integer songId);

	void findAllSongs();

}

package com.tma.api;

import java.io.Serializable;

public class SongVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer songId;
	private String songName;
	private String songSinger;
	private String songYear;

	public SongVO() {

	}

	public SongVO(Integer songId, String songName, String songSinger, String songYear) {
		this.songId = songId;
		this.songName = songName;
		this.songSinger = songSinger;
		this.songYear = songYear;
	}

	public Integer getSongId() {
		return songId;
	}

	public void setSongId(Integer songId) {
		this.songId = songId;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public String getSongSinger() {
		return songSinger;
	}

	public void setSongSinger(String songSinger) {
		this.songSinger = songSinger;
	}

	public String getSongYear() {
		return songYear;
	}

	public void setSongYear(String songYear) {
		this.songYear = songYear;
	}
}

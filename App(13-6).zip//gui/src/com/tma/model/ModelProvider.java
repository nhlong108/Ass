package com.tma.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.management.JMX;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import com.tma.api.MusicManagerService;
import com.tma.api.SongVO;

public class ModelProvider {

	private static List<SongVO> songVO;
	private static MusicManagerService mbeanProxy;

	public static List<SongVO> getSongs() throws IOException, MalformedObjectNameException  {
		JMXServiceURL url = new JMXServiceURL(
				"service:jmx:rmi:///jndi/rmi://localhost:1095/SongDao");
		JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
		MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();
		ObjectName mbeanName = new ObjectName(
				"application.tma:service=MusicManagerServiceImpl");
		mbeanProxy = JMX.newMBeanProxy(mbsc, mbeanName,
				MusicManagerService.class, true);
		mbeanProxy.getAllSong();
		
		songVO = new ArrayList<SongVO>();
		for (SongVO s : mbeanProxy.getList()) {
			songVO.add(s);
		}
		return songVO;
	}
}

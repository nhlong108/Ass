package com.tma.gui;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;

/**
 * An action bar advisor is responsible for creating, adding, and disposing of
 * the actions added to a workbench window. Each window will be populated with
 * new actions.
 */
public class ApplicationActionBarAdvisor extends ActionBarAdvisor {

	IAction m_aboutAction;
	IAction m_newAction;
	IAction m_quitAction;

	public ApplicationActionBarAdvisor(IActionBarConfigurer configurer) {
		super(configurer);
	}

	protected void makeActions(IWorkbenchWindow window) {
		m_newAction = ActionFactory.NEW.create(window);
		m_quitAction = ActionFactory.QUIT.create(window);
		m_aboutAction = ActionFactory.ABOUT.create(window);
	}

	protected void fillMenuBar(IMenuManager menuBar) {
		MenuManager file = new MenuManager("&File");
		file.add(m_newAction);
		file.add(m_quitAction);
		menuBar.add(file);
		
		MenuManager help = new MenuManager("&Help");
		help.add(m_aboutAction);
		menuBar.add(help);
	}

}

package com.tma.service.dao;

import java.util.List;

import com.tma.api.SongVO;
import com.tma.service.entity.Song;

public interface SongDao {
	public List<SongVO> getList();

	public boolean insert(Song s);

	public boolean update(Song s);

	public boolean delete(Song s);
	
	public void getAllSong();
}

package com.tma.service.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.tma.api.SongVO;
import com.tma.service.entity.Song;
import com.tma.service.utils.MusicUtils;

public class SongDaoImpl implements SongDao {

	private SessionFactory m_factory;

	public SongDaoImpl(SessionFactory factory) {
		m_factory = factory;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SongVO> getList() {
		Session session = m_factory.openSession();
		Transaction tx = null;
		ArrayList<SongVO> arrl = new ArrayList<SongVO>();

		try {
			tx = session.beginTransaction();
			Query q = session.createQuery("from Song");

			Iterator<Song> it = q.iterate();
			while (it.hasNext()) {
				Song s = it.next();
				arrl.add(MusicUtils.convertToSongVO(s));
			}
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();
		} finally {
			session.close();
		}
		return arrl;
	}

	@Override
	public boolean insert(Song s) {
		Session session = m_factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(s);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();
		} finally {
			session.close();
		}
		return true;
	}

	@Override
	public boolean update(Song s) {
		Session session = m_factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.update(s);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();
		} finally {
			session.close();
		}
		return true;
	}

	@Override
	public boolean delete(Song s) {
		Session session = m_factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.delete(s);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();
		} finally {
			session.close();
		}
		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void getAllSong() {
		Session session = m_factory.openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			String sql = "Select s from Song s " + "order by s.songId";

			Query query = session.createQuery(sql);

			List<Song> songs = query.list();

			for (Song s : songs) {
				System.out.println("Song: " + s.getSongId() + " : "
						+ s.getSongName() + " - " + s.getSongSinger() + " - "
						+ s.getSongYear());
			}

			tx.commit();
		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
			}
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

}

package com.tma.service.utils;

import com.tma.api.SongVO;
import com.tma.service.entity.Song;

public class MusicUtils {
	public static Song createfromSongVO(SongVO so) {
		Song s = new Song();
		s.setSongId(so.getSongId());
		s.setSongName(so.getSongName());
		s.setSongSinger(so.getSongSinger());
		s.setSongYear(so.getSongYear());
		return s;
	}

	public static SongVO convertToSongVO(Song s) {
		SongVO so = new SongVO();
		so.setSongId(s.getSongId());
		so.setSongName(s.getSongName());
		so.setSongSinger(s.getSongSinger());
		so.setSongYear(s.getSongYear());
		return so;
	}
}
